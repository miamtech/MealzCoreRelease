#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class MealzcoreKotlinThrowable, MealzcoreMealz, MealzcoreSdkBuilder, MealzcoreMealzBasket, MealzcoreMealzCatalog, MealzcoreMealzEnvironment, MealzcoreMealzNotifications, MealzcoreMealzPayment, MealzcoreMealzRecipe, MealzcoreMealzUser, MealzcoreSupplierProduct, MealzcoreCatalogCategory, MealzcoreSupportedLanguage, MealzcoreAuthorization, MealzcoreMealzCoreInformation, MealzcoreKMMContext, MealzcoreMiamPreferencesContext, MealzcoreKotlinEnumCompanion, MealzcoreKotlinEnum<E>, MealzcoreOperatingSystem, MealzcoreKotlinArray<T>, MealzcoreExecutorHelperCompanion, MealzcoreMainExecutor, MealzcoreBasicUiState<__covariant T>, MealzcoreBasicUiStateEmpty, MealzcoreKotlinNothing, MealzcoreBasicUiStateError, MealzcoreBasicUiStateIdle, MealzcoreBasicUiStateLoading, MealzcoreBasicUiStateSuccess<T>, MealzcoreComponentUiState, MealzcoreActionStatus, MealzcoreActionType, MealzcoreBasketSummary, MealzcoreBasketEntry, MealzcoreIngredient, MealzcoreMealzTimer, MealzcoreMealzBasketAction, MealzcoreItem, MealzcoreRecipeInfos, MealzcoreBasket, MealzcoreRecipe, MealzcoreRecipePricing, MealzcoreSuggestionsCriteria, MealzcoreRecipeSort, MealzcoreRecipeFilter, MealzcoreBudgetRepositoryCompanion, MealzcoreSponsorBlock, MealzcoreStartTransferResponse, MealzcoreItemPrice, MealzcoreItemSelectorWithBasketEntryNavigationData, MealzcoreItemSelectorWithIngredientNavigationData, MealzcoreItemSelectorNavigationData, MealzcorePointOfSale, MealzcoreStore, MealzcorePointOfSaleRepositoryCompanion, MealzcoreRecipeRepositoryImpCompanion, MealzcoreRetailerRepositoryCompanion, MealzcoreRetailer, MealzcoreSupplier, MealzcoreAuthLessUser, MealzcoreMealzDI, MealzcoreSingletonPreferencesViewModel, MealzcoreRecipeRepositoryImp, MealzcoreRouteService, MealzcoreLogHandlerCompanion, MealzcoreLogHandlerLogLevels, MealzcoreMealzPage, MealzcoreMyBasketTab, MealzcoreRecipeDetailTab, MealzcoreSdkRequirement, MealzcoreI18nResolver, MealzcoreI18n, NSBundle, MealzcoreLocalisation, MealzcoreBasketI18N, MealzcoreBudgetI18N, MealzcoreCatalogI18N, MealzcoreCounterI18N, MealzcoreDateFormatI18N, MealzcoreErrorI18N, MealzcoreFavoritesI18N, MealzcoreFiltersI18N, MealzcoreIngredientI18N, MealzcoreItemSelectorI18N, MealzcoreMyBasketI18N, MealzcoreMyMealsI18N, MealzcoreMyProductsI18N, MealzcoreMyProductsProductI18N, MealzcoreMySpaceI18N, MealzcoreNavigationI18N, MealzcoreOrderHistoryI18N, MealzcorePreferencesI18N, MealzcorePriceI18N, MealzcoreRecipeI18N, MealzcoreRecipeDetailsI18N, MealzcoreRecipeDetailsProductI18N, MealzcoreSearchI18N, MealzcoreSponsorBannerI18N, MealzcoreSponsorDetailI18N, MealzcoreStoreLocatorButtonI18N, MealzcoreTagI18N, MealzcoreI18nCompanion, MealzcoreResourcesPluralsResource, MealzcoreResourcesStringResource, MealzcoreNoResourceThrowable, MealzcoreAlterQuantityBasketEntry, MealzcoreAttributesCompanion, MealzcoreAuthLessUserCompanion, MealzcoreRecordCompanion, MealzcoreKotlinx_serialization_jsonJsonElement, MealzcoreAttributes, MealzcoreRelationships, MealzcoreRecord, MealzcoreBasketCompanion, MealzcoreBasketAttributes, MealzcoreBasketRelationships, MealzcoreAttributesField, MealzcoreBasketStatus, MealzcoreBasketAttributesCompanion, MealzcoreBasketEntriesItemCompanion, MealzcoreBasketEntriesItem, MealzcoreBasketEntryCompanion, MealzcoreBasketEntryAttributes, MealzcoreBasketEntryRelationships, MealzcoreBasketEntryCompanionStates, MealzcoreDiscountType, MealzcoreBasketEntryAttributesCompanion, MealzcoreRelationshipListCompanion, MealzcoreRelationshipList, MealzcoreBasketEntryRelationshipListCompanion, MealzcoreBasketEntryRelationshipListSerializer, MealzcoreBasketEntryRelationshipList, MealzcoreRelationshipsCompanion, MealzcoreItemRelationshipList, MealzcoreItemRelationship, MealzcoreBasketEntryRelationshipsCompanion, MealzcoreBasketPriceCompanion, MealzcoreBasketPrice, MealzcoreBasketRelationshipsCompanion, MealzcoreBasketStatusCompanion, MealzcoreBasketStatusSerializer, MealzcoreCatalogFilterOptions, MealzcoreTagTypes, MealzcoreTag, MealzcoreCheckableTagCompanion, MealzcoreCheckableTag, MealzcoreIngredientCompanion, MealzcoreIngredientAttributes, MealzcoreIngredientRelationships, MealzcoreIngredientAttributesCompanion, MealzcoreIngredientListRelationshipCompanion, MealzcoreIngredientListSerializer, MealzcoreIngredientListRelationship, MealzcoreItemCompanion, MealzcoreItemAttributes, MealzcoreItemRelationships, MealzcoreItemAttributesCompanion, MealzcoreItemPriceCompanion, MealzcoreRelationshipCompanion, MealzcoreRelationship, MealzcoreItemRelationshipCompanion, MealzcoreItemRelationshipListCompanion, MealzcoreItemRelationshipListSerializer, MealzcoreItemRelationshipSerializer, MealzcoreItemRelationshipsCompanion, MealzcoreMealPlannerRecipe, MealzcoreMiamConfigCompanion, MealzcoreMiamConfig, MealzcorePackageCompanion, MealzcorePackage, MealzcorePackageAttributes, MealzcorePackageRelationships, MealzcorePackageSettings, MealzcorePackageAttributesCompanion, MealzcoreRecipeRelationshipList, MealzcorePackageRelationshipsCompanion, MealzcorePackageSettingsCompanion, MealzcorePointOfSaleAttributes, MealzcorePointOfSaleCompanion, MealzcorePointOfSaleAttributesCompanion, MealzcoreRecipeCompanion, MealzcoreRecipeAttributes, MealzcoreRecipeRelationships, MealzcoreRecipeLike, MealzcoreRecipeDifficulty, MealzcoreRecipeStep, MealzcoreRecipeAttributesCompanion, MealzcoreRecipeInfosCompanion, MealzcoreRecipeLikeCompanion, MealzcoreRecipeLikeAttributes, MealzcoreRecipeLikeRelationships, MealzcoreRecipeLikeAttributesCompanion, MealzcoreRecipeLikeRelationshipsCompanion, MealzcoreRecipePlanCompanion, MealzcoreRecipePlan, MealzcoreRecipePricingCompanion, MealzcoreRecipeRelationshipListCompanion, MealzcoreRecipeRelationshipListSerializer, MealzcoreSponsorListRelationship, MealzcoreRecipeStepListRelationship, MealzcoreTagListRelationship, MealzcoreRecipeRelationshipsCompanion, MealzcoreRecipeStepCompanion, MealzcoreRecipeStepAttributes, MealzcoreRecipeStepRelationships, MealzcoreRecipeStepAttributesCompanion, MealzcoreRecipeStepListListSerializer, MealzcoreRecipeStepListRelationshipCompanion, MealzcoreRecipeStepRelationshipsCompanion, MealzcoreRecordLink, MealzcoreRecordCounterWrapperCompanion, MealzcoreRecordCounterWrapper, MealzcoreRecordLinkCompanion, MealzcoreRecordWrapperCompanion, MealzcoreRecordWrapper, MealzcoreSponsorCompanion, MealzcoreSponsor, MealzcoreSponsorAttributes, MealzcoreSponsorRelationships, MealzcoreSponsorAttributesCompanion, MealzcoreSponsorBlockCompanion, MealzcoreSponsorBlockAttributes, MealzcoreSponsorBlockRelationships, MealzcoreSponsorBlockAttributesCompanion, MealzcoreSponsorBlockRelationshipName, MealzcoreSponsorBlockTypeRelationship, MealzcoreSponsorBlockRelationshipsCompanion, MealzcoreSponsorBlockTypeCompanion, MealzcoreSponsorBlockType, MealzcoreSponsorBlockTypeAttributes, MealzcoreSponsorBlockTypeRelationships, MealzcoreSponsorBlockTypeAttributesCompanion, MealzcoreSponsorBlockTypeRelationshipCompanion, MealzcoreSponsorBlockTypeSerializer, MealzcoreSponsorBlockTypesList, MealzcoreSponsorBlocksRelationshipsCompanion, MealzcoreSponsorBlocksSerializer, MealzcoreSponsorBlocksRelationships, MealzcoreSponsorListRelationshipCompanion, MealzcoreSponsorListSerializer, MealzcoreSponsorRelationshipName, MealzcoreSponsorRelationshipsCompanion, MealzcoreStartTransferResponseCompanion, MealzcoreStoreCompanion, MealzcoreSuggestionsCriteriaCompanion, MealzcoreSupplierCompanion, MealzcoreSupplierAttributes, MealzcoreSupplierRelationships, MealzcoreSupplierAttributesCompanion, MealzcoreSupplierNotificationWrapperCompanion, MealzcoreSupplierNotificationWrapper, MealzcoreTagCompanion, MealzcoreTagAttributes, MealzcoreTagRelationships, MealzcoreTagAttributesCompanion, MealzcoreTagListListSerializer, MealzcoreTagListRelationshipCompanion, MealzcoreBasketEntryFakeFactory, MealzcoreBasketFakeFactory, MealzcoreIngredientFakeFactory, MealzcoreItemFakeFactory, MealzcorePackageFakeFactory, MealzcorePointOfSaleFakeFactory, MealzcoreRecipeFakeFactory, MealzcoreRecipeLikeFakeFactory, MealzcoreRecipeStepFakeFactory, MealzcoreSponsorBlockFakeFactory, MealzcoreSponsorBlockTypeFakeFactory, MealzcoreSponsorFakeFactory, MealzcoreSupplierFakeFactory, MealzcoreTagFakeFactory, MealzcoreCustomDateSerializer, MealzcoreCustomDurationSerializer, MealzcoreDiscountTypeSerializer, MealzcoreRetailerCompanion, MealzcoreBasketNotification, MealzcoreBasketNotificationBasketConfirmed, MealzcoreBasketNotificationBasketInit, MealzcoreBasketNotificationBasketReloaded, MealzcoreBasketNotificationBasketReset, MealzcoreBasketNotificationBasketUpdated, MealzcoreBasketNotificationBasketUpdating, MealzcoreBasketNotificationComparatorIsReady, MealzcoreBasketNotificationComparatorIsReset, MealzcoreBasketNotificationEntriesAltered, MealzcoreBasketNotificationEntryAdded, MealzcoreBasketNotificationEntryItemReplaced, MealzcoreBasketNotificationEntryQuantityUpdated, MealzcoreBasketNotificationEntryRemoved, MealzcoreBasketNotificationRecipeCountChanged, MealzcoreBasketNotificationRecipesAdded, MealzcoreBasketNotificationRecipesRemoved, MealzcoreBasketNotificationRecipesUpdated, MealzcoreMealPlannerBasketPreviewNotification, MealzcoreMealPlannerBasketPreviewNotificationRecipeRowLoading, MealzcoreMealPlannerBasketPreviewNotificationRecipeRowReady, MealzcorePointOfSaleNotification, MealzcorePreferencesNotification, MealzcorePreferencesNotificationPreferencesLoaded, MealzcorePreferencesNotificationPreferencesUpdated, MealzcoreBasketEntryNotification, MealzcoreBasketEntryNotificationBasketEntryAdded, MealzcoreBasketEntryNotificationBasketEntryQtyUpdated, MealzcoreBasketEntryNotificationBasketEntryRemoved, MealzcoreBasketEntryNotificationBasketEntryReplaced, MealzcoreBasketEntryNotificationChildReady, MealzcoreBasketEntryNotificationGoToItemSelector, MealzcoreBasketEntryNotificationGoToItemSelectorForRecipe, MealzcoreAbstractNotifier<T1>, MealzcoreToasterNotification, MealzcoreToasterNotificationRecipeAdded, MealzcoreToasterNotificationRecipeLiked, MealzcoreUserNotification, MealzcoreUserNotificationTokenExpired, MealzcoreUserNotificationUserConnected, MealzcoreUserNotificationUserDisconnected, MealzcoreMealzImages, MealzcoreResourcesImageResource, MealzcoreAnalyticsPlausibleProps, MealzcoreAnalyticEvent, MealzcoreAnalyticsEvent, MealzcoreAnalyticsPlausiblePaths, MealzcoreAnalyticsInstance, MealzcoreRoute, MealzcoreDialogRoute, MealzcorePageRoute, MealzcoreRouteServiceAction, MealzcoreRouteServiceActionSetDialogRoute, MealzcoreRouteServiceActionSetInitialPageRoute, MealzcoreRouteServiceActionSetPageRoute, MealzcoreRouteServiceEffect, MealzcoreRouteServiceEffectRouteChanged, MealzcoreRouteServiceInstance, MealzcoreRouteServiceState, MealzcoreUserPreferencesCompanion, MealzcoreEnvironment, MealzcoreLikeEffect, MealzcoreLikeEffectDisliked, MealzcoreLikeEffectLiked, MealzcoreLikeStoreInstance, MealzcoreLikeStore, MealzcoreUserState, MealzcoreUserStoreImplCompanion, MealzcoreUserAction, MealzcoreAvailabilityState, MealzcoreBasketAction, MealzcoreBasketActionRefreshBasket, MealzcoreBasketActionRefreshBasketPrice, MealzcoreBasketActionResetBasket, MealzcoreBasketState, MealzcoreBasketComparisonItem, MealzcoreBasketComparator, MealzcoreBasketComparatorData, MealzcoreMealPlannerState, MealzcoreCoreConstants, MealzcoreKotlinUnit, MealzcoreTransferAffiliateBasketToSupplierUseCaseCompanion, MealzcoreAddRecipesByIdsToMealPlannerUseCaseInput, MealzcoreInitSupplierUseCaseInput, MealzcoreSetProfilingAllowedUseCaseCompanion, MealzcoreSetProfilingAllowedUseCase, MealzcoreSupportedLanguageCompanion, MealzcoreEnableRecipeLikeUseCaseCompanion, MealzcoreEnableRecipeLikeUseCase, MealzcoreUpdateUserAuthInfoUseCaseInput, MealzcoreSetForceStoreCallBackUseCaseInput, MealzcoreDoesRecipeExistUseCaseInput, MealzcoreFetchRecipeFromIdUseCaseInput, MealzcoreIsRecipeInBasketUseCaseInput, MealzcoreAddRecipeUseCaseInput, MealzcoreCanOrderRecipeUseCaseInput, MealzcoreUpdateRecipesUseCaseInput, MealzcoreRetailerInput, MealzcoreBasketEntryContractEvent, MealzcoreBasketEntryContractEventAddBasketEntry, MealzcoreBasketEntryContractEventInit, MealzcoreBasketEntryContractEventLockFromParent, MealzcoreBasketEntryContractEventReAddBasketEntry, MealzcoreBasketEntryContractEventRemoveBasketEntry, MealzcoreBasketEntryContractEventReplaceBasketEntry, MealzcoreBasketEntryContractEventUnLockFromParent, MealzcoreBasketEntryContractEventUpdateBasketEntryQty, MealzcoreBasketEntryContractState, MealzcoreBaseViewModel<Event, State, Effect>, MealzcoreBasketEntryNotifier, MealzcoreBasketEntryContractEffect, MealzcoreBasketEntryViewModel, MealzcoreBasketTagContractEvent, MealzcoreBasketTagContractEventSetRetailerProductId, MealzcoreBasketTagContractState, MealzcoreRouterOutletViewModel, MealzcoreBasketTagContractEffect, MealzcoreCatalogContent, MealzcoreCatalogContractEvent, MealzcoreCatalogContractEventGoBack, MealzcoreCatalogContractEventGoToFavorite, MealzcoreDialogContent, MealzcoreCatalogContractState, MealzcoreFilterViewModelCompanion, MealzcoreFilterContractState, MealzcoreFilterContractEvent, MealzcoreFilterContractEffect, MealzcoreFilterViewModel, MealzcoreCatalogViewModelCompanion, MealzcoreCatalogContractEffect, MealzcoreRecipesPageContractState, MealzcoreRecipesPageContractEvent, MealzcoreRecipesPageContractEffect, MealzcoreDynamicRecipeDetailContractEvent, MealzcoreDynamicRecipeDetailContractEventAddAllRemainingIngredients, MealzcoreDynamicRecipeDetailContractEventReset, MealzcoreDynamicRecipeDetailContractEventSetRecipeId, MealzcoreDynamicRecipeDetailContractEventUpdateGuests, MealzcoreDynamicRecipeDetailContractState, MealzcoreDynamicRecipeDetailFooterViewModel, MealzcoreDynamicRecipeDetailContractEffect, MealzcoreDynamicRecipeDetailFooterContractEvent, MealzcoreDynamicRecipeDetailFooterContractEventLockFromParent, MealzcoreDynamicRecipeDetailFooterContractEventOnTapContinueShopping, MealzcoreDynamicRecipeDetailFooterContractEventSetGuests, MealzcoreDynamicRecipeDetailFooterContractEventSetIngredientsStatus, MealzcoreDynamicRecipeDetailFooterContractEventSetRecipe, MealzcoreDynamicRecipeDetailFooterContractEventUnLockFromParent, MealzcoreIngredientStatus, MealzcoreDynamicRecipeDetailFooterContractState, MealzcoreDynamicRecipeDetailFooterContractEffect, MealzcoreIngredientStatusTypes, MealzcoreFactoryViewModelViewModelContainer<T>, MealzcoreFavoritePageContractEvent, MealzcoreFavoritePageContractEventLoadPage, MealzcoreFavoritePageContractState, MealzcoreFavoritePageViewModelCompanion, MealzcoreFavoritePageContractEffect, MealzcoreFilterContractEffectOnUpdate, MealzcoreFilterContractEventOnCostFilterChanged, MealzcoreFilterContractEventOnDifficultyChanged, MealzcoreFilterContractEventOnTimeFilterChanged, MealzcoreFilterEffect, MealzcoreFilterEffectOnUpdate, MealzcoreFilterInstance, MealzcoreFactoryViewModel<T>, MealzcoreFilterViewModelFactoryCompanion, MealzcoreItemSelectorContractEvent, MealzcoreItemSelectorContractEventInitStandalone, MealzcoreItemSelectorContractEventInitWithBasketEntry, MealzcoreItemSelectorContractEventInitWithIngredientId, MealzcoreItemSelectorContractEventReturnToDetail, MealzcoreItemSelectorContractEventSearch, MealzcoreItemSelectorContractEventSelectItem, MealzcoreItemSelectorContractState, MealzcoreItemSelectorEmptyStates, MealzcoreItemSelectorContractEffect, MealzcoreMealPlannerBasketPreviewContractState, MealzcoreMealPlannerBasketPreviewContractEvent, MealzcoreMealPlannerBasketPreviewContractEffect, MealzcoreDynamicRecipeDetailViewModel, MealzcoreRecipeRowState, MealzcoreMealPlannerFormContractState, MealzcoreMealPlannerFormContractEvent, MealzcoreMealPlannerFormContractEffect, MealzcoreMealPlannerMealsContractState, MealzcoreMealPlannerMealsContractEvent, MealzcoreMealPlannerMealsContractEffect, MealzcoreMealPlannerRecapContractState, MealzcoreMealPlannerRecapContractEvent, MealzcoreMealPlannerRecapContractEffect, MealzcoreRecipesPageViewModel, MealzcoreMyBasketContractState, MealzcoreMyBasketContractEvent, MealzcoreMyBasketContractEffect, MealzcoreMyMealContractState, MealzcoreMyMealContractEvent, MealzcoreMyMealContractEffect, MealzcoreMyMealRecipeContractState, MealzcoreMyMealRecipeContractEvent, MealzcoreMyMealRecipeContractEffect, MealzcoreMyMealButtonContractState, MealzcoreMyMealButtonContractEvent, MealzcoreMyMealButtonContractEffect, MealzcoreMyProductsContractState, MealzcoreMyProductsContractEvent, MealzcoreMyProductsContractEffect, MealzcoreMySpacePage, MealzcoreOrderHistoryContractEvent, MealzcoreOrderHistoryContractEventLoadPage, MealzcoreOrderHistoryContractEventSearch, MealzcoreOrderHistoryContractState, MealzcoreOrderHistoryContractEffect, MealzcorePreferencesContent, MealzcorePreferencesContractState, MealzcorePreferencesViewModelInstance, MealzcoreSingletonPreferencesViewModelCompanion, MealzcorePreferencesContractEvent, MealzcorePreferencesContractEffect, MealzcorePreferencesSearchContractState, MealzcorePreferencesSearchContractEvent, MealzcorePreferencesSearchContractEffect, MealzcorePricingContractState, MealzcorePricingContractEvent, MealzcorePricingContractEffect, MealzcoreQuantityFormatterDefault, MealzcoreRecipeContractEffect, MealzcoreRecipeContractEffectDisliked, MealzcoreRecipeContractEffectHideCard, MealzcoreRecipeContractEvent, MealzcoreRecipeContractEventError, MealzcoreRecipeContractEventFetchRecipeFromCriteria, MealzcoreRecipeContractEventFetchRecipeFromId, MealzcoreRecipeContractEventGoToDetail, MealzcoreRecipeContractEventGoToDetailWithPath, MealzcoreRecipeContractState, MealzcoreRecipeCarouselContractEvent, MealzcoreRecipeCarouselContractEventGetRecipeSuggestionsFromCriteria, MealzcoreRecipeCarouselContractEventGetRecipeSuggestionsFromId, MealzcoreRecipeCarouselContractState, MealzcoreRecipeCarouselContractEffect, MealzcoreRecipeDetailButtonContractState, MealzcoreRecipeDetailButtonContractEvent, MealzcoreRecipeDetailButtonContractEffect, MealzcoreRecipeLikeContractState, MealzcoreRecipeLikeContractEvent, MealzcoreRecipeLikeContractEffect, MealzcoreLikeButtonViewModelFactoryCompanion, MealzcoreLikeButtonViewModel, MealzcoreRouterContent, MealzcoreRouterOutletContractEvent, MealzcoreRecipeViewModel, MealzcoreRouterOutletContractEventGoToDetail, MealzcoreRouterOutletContractEventGoToHelper, MealzcoreRouterOutletContractEventGoToItemSelector, MealzcoreRouterOutletContractEventGoToPreview, MealzcoreRouterOutletContractEventGoToSponsor, MealzcoreRouterOutletContractEventOpenDialog, MealzcoreRouterOutletContractEventPrevious, MealzcoreRouterOutletContractState, MealzcoreRouterOutletContractEffect, MealzcoreSponsorDetailsContractState, MealzcoreSponsorDetailsContractEvent, MealzcoreSponsorDetailsContractEffect, MealzcoreSponsorDetailState, MealzcoreStoreLocatorButtonContractState, MealzcoreStoreLocatorButtonViewModelCompanion, MealzcoreStoreLocatorButtonContractEvent, MealzcoreStoreLocatorButtonContractEffect, MealzcoreOptionalConfigurationBuilder, MealzcoreSdkRequirementBuilder, MealzcoreSubscriptionConfigBuilder, MealzcoreBasketSubscriptionBuilder, MealzcoreKotlinx_serialization_jsonJson, MealzcoreKotlinException, MealzcoreKotlinRuntimeException, MealzcoreKotlinIllegalStateException, MealzcoreKotlinCancellationException, MealzcoreKotlinx_serialization_jsonJsonElementCompanion, MealzcoreKotlinx_serialization_coreSerializersModule, MealzcoreKotlinx_serialization_coreSerialKind, UIImage, MealzcoreKotlinx_serialization_jsonJsonDefault, MealzcoreKotlinx_serialization_jsonJsonConfiguration;

@protocol MealzcoreKotlinx_coroutines_coreFlowCollector, MealzcoreKotlinx_coroutines_coreFlow, MealzcoreClosable, MealzcoreKotlinx_coroutines_coreCoroutineScope, MealzcoreKotlinCoroutineContext, MealzcoreNotifier, MealzcoreKotlinx_coroutines_coreDeferred, MealzcoreKotlinComparable, MealzcoreKotlinx_coroutines_coreJob, MealzcoreIExecutorScope, MealzcoreKotlinx_coroutines_coreSharedFlow, MealzcoreKotlinx_coroutines_coreStateFlow, MealzcoreAction, MealzcoreBasketSubscriber, MealzcoreUserStore, MealzcoreRecipeRepository, MealzcoreRecipeDataSource, MealzcoreAnalytics, MealzcoreKotlinSuspendFunction0, MealzcoreI18nResource, MealzcoreKotlinx_serialization_coreKSerializer, MealzcoreKotlinKClass, MealzcoreKotlinx_serialization_coreEncoder, MealzcoreKotlinx_serialization_coreSerialDescriptor, MealzcoreKotlinx_serialization_coreSerializationStrategy, MealzcoreKotlinx_serialization_coreDecoder, MealzcoreKotlinx_serialization_coreDeserializationStrategy, MealzcoreKotlinx_coroutines_coreMutableSharedFlow, MealzcoreKotlinx_coroutines_coreCoroutineExceptionHandler, MealzcoreKotlinx_coroutines_coreMutableStateFlow, MealzcoreStore, MealzcoreEffect, MealzcoreState, MealzcoreUserPreferences, MealzcoreBasketPublisher, MealzcoreUseCase, MealzcoreBasketStore, MealzcoreBasketRepository, MealzcoreParameterisedUseCase, MealzcoreSupplierRepository, MealzcoreAvailabilityStore, MealzcorePointOfSaleRepository, MealzcoreUserRepository, MealzcoreUiEffect, MealzcoreUiEvent, MealzcoreUiState, MealzcoreMealPlannerStore, MealzcoreRedirectOnStoreIfRequiredCallback, MealzcoreSponsorDetailViewModel, MealzcoreResourcesStringDesc, MealzcoreKotlinCoroutineContextElement, MealzcoreKotlinCoroutineContextKey, MealzcoreKotlinx_coroutines_coreSelectClause1, MealzcoreKotlinx_coroutines_coreChildHandle, MealzcoreKotlinx_coroutines_coreChildJob, MealzcoreKotlinx_coroutines_coreDisposableHandle, MealzcoreKotlinSequence, MealzcoreKotlinx_coroutines_coreSelectClause0, MealzcoreKotlinIterator, MealzcoreKotlinFunction, MealzcoreKotlinKDeclarationContainer, MealzcoreKotlinKAnnotatedElement, MealzcoreKotlinKClassifier, MealzcoreKotlinx_serialization_coreCompositeEncoder, MealzcoreKotlinAnnotation, MealzcoreKotlinx_serialization_coreCompositeDecoder, MealzcoreKotlinx_serialization_coreSerialFormat, MealzcoreKotlinx_serialization_coreStringFormat, MealzcoreKotlinx_coroutines_coreSelectInstance, MealzcoreKotlinx_coroutines_coreSelectClause, MealzcoreKotlinx_coroutines_coreParentJob, MealzcoreKotlinx_serialization_coreSerializersModuleCollector, MealzcoreKotlinx_serialization_jsonJsonNamingStrategy;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface MealzcoreBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface MealzcoreBase (MealzcoreBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface MealzcoreMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface MealzcoreMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorMealzcoreKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface MealzcoreNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface MealzcoreByte : MealzcoreNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface MealzcoreUByte : MealzcoreNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface MealzcoreShort : MealzcoreNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface MealzcoreUShort : MealzcoreNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface MealzcoreInt : MealzcoreNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface MealzcoreUInt : MealzcoreNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface MealzcoreLong : MealzcoreNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface MealzcoreULong : MealzcoreNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface MealzcoreFloat : MealzcoreNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface MealzcoreDouble : MealzcoreNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface MealzcoreBoolean : MealzcoreNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol MealzcoreKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<MealzcoreKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FlowWrapper")))
@interface MealzcoreFlowWrapper<T> : MealzcoreBase <MealzcoreKotlinx_coroutines_coreFlow>
- (instancetype)initWithFlow:(id<MealzcoreKotlinx_coroutines_coreFlow>)flow __attribute__((swift_name("init(flow:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<MealzcoreKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
- (id<MealzcoreClosable>)collectCoroutineScope:(id<MealzcoreKotlinx_coroutines_coreCoroutineScope>)coroutineScope onEach:(void (^)(T _Nullable))onEach onThrow:(void (^ _Nullable)(MealzcoreKotlinThrowable *))onThrow __attribute__((swift_name("collect(coroutineScope:onEach:onThrow:)")));
- (id<MealzcoreClosable>)collectCoroutineScope:(id<MealzcoreKotlinx_coroutines_coreCoroutineScope>)coroutineScope coroutineContext:(id<MealzcoreKotlinCoroutineContext>)coroutineContext onEach:(void (^ _Nullable)(T _Nullable))onEach onComplete:(void (^ _Nullable)(void))onComplete onThrow:(void (^ _Nullable)(MealzcoreKotlinThrowable *))onThrow __attribute__((swift_name("collect(coroutineScope:coroutineContext:onEach:onComplete:onThrow:)")));
@end

__attribute__((swift_name("KMMContext")))
@interface MealzcoreKMMContext : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Mealz")))
@interface MealzcoreMealz : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mealz __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealz *shared __attribute__((swift_name("shared")));
- (void)CoreInit:(void (^)(MealzcoreSdkBuilder *))init __attribute__((swift_name("Core(init:)")));
@property (readonly) MealzcoreMealzBasket *basket __attribute__((swift_name("basket")));
@property (readonly) MealzcoreMealzCatalog *catalog __attribute__((swift_name("catalog")));
@property (readonly) MealzcoreMealzEnvironment *environment __attribute__((swift_name("environment")));
@property (readonly) MealzcoreMealzNotifications *notifications __attribute__((swift_name("notifications")));
@property (readonly) MealzcoreMealzPayment *payment __attribute__((swift_name("payment")));
@property (readonly) MealzcoreMealzRecipe *recipe __attribute__((swift_name("recipe")));
@property (readonly) MealzcoreMealzUser *user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Mealz.Basket")))
@interface MealzcoreMealzBasket : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)basket __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealzBasket *shared __attribute__((swift_name("shared")));
- (void)clear __attribute__((swift_name("clear()")));
- (int32_t)getRecipeCountInBasket __attribute__((swift_name("getRecipeCountInBasket()")));
- (void)handlePaymentTotalAmount:(double)totalAmount __attribute__((swift_name("handlePayment(totalAmount:)"))) __attribute__((deprecated("handlePayment has been replaced with payment.paymentFinished")));
- (void)onBasketTransferredUrl:(NSString *)url __attribute__((swift_name("onBasketTransferred(url:)")));
- (void)sendBasketToMealzSupplierProducts:(NSArray<MealzcoreSupplierProduct *> *)supplierProducts __attribute__((swift_name("sendBasketToMealz(supplierProducts:)")));
- (void)setPriceBookPriceBookId:(NSString *)priceBookId __attribute__((swift_name("setPriceBook(priceBookId:)"))) __attribute__((deprecated("setPriceBook is not required since one POS have a unique priceBook")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Mealz.Catalog")))
@interface MealzcoreMealzCatalog : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)catalog __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealzCatalog *shared __attribute__((swift_name("shared")));
- (void)getCatalogCategoriesSetLocalCategories:(void (^)(NSArray<MealzcoreCatalogCategory *> *))setLocalCategories __attribute__((swift_name("getCatalogCategories(setLocalCategories:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Mealz.Environment")))
@interface MealzcoreMealzEnvironment : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)environment __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealzEnvironment *shared __attribute__((swift_name("shared")));
- (BOOL)isAvailable __attribute__((swift_name("isAvailable()")));
- (void)setAllowsSponsoredProductsIsAllowed:(BOOL)isAllowed __attribute__((swift_name("setAllowsSponsoredProducts(isAllowed:)")));
- (void)setAnalyticsTrackingIsEnable:(BOOL)isEnable __attribute__((swift_name("setAnalyticsTracking(isEnable:)")));
- (void)setForceStoreUpdateCallBackCallBack:(void (^)(NSString *))callBack __attribute__((swift_name("setForceStoreUpdateCallBack(callBack:)")));
- (void)setLanguageLanguage:(MealzcoreSupportedLanguage *)language __attribute__((swift_name("setLanguage(language:)")));
- (void)setShowTranslteKeyShow:(BOOL)show __attribute__((swift_name("setShowTranslteKey(show:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Mealz.Notifications")))
@interface MealzcoreMealzNotifications : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)notifications __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealzNotifications *shared __attribute__((swift_name("shared")));
@property (readonly) id<MealzcoreNotifier> analytics __attribute__((swift_name("analytics"))) __attribute__((deprecated("use analyticsEvent instead")));
@property (readonly) id<MealzcoreNotifier> analyticsEvent __attribute__((swift_name("analyticsEvent")));
@property (readonly) id<MealzcoreNotifier> availability __attribute__((swift_name("availability")));
@property (readonly) id<MealzcoreNotifier> basketSummary __attribute__((swift_name("basketSummary")));
@property (readonly) id<MealzcoreNotifier> pointOfSale __attribute__((swift_name("pointOfSale")));
@property (readonly) id<MealzcoreNotifier> preferences __attribute__((swift_name("preferences")));
@property id<MealzcoreNotifier> productsCount __attribute__((swift_name("productsCount")));
@property (readonly) id<MealzcoreNotifier> recipesCount __attribute__((swift_name("recipesCount")));
@property (readonly) id<MealzcoreNotifier> toaster __attribute__((swift_name("toaster")));
@property (readonly) id<MealzcoreNotifier> user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Mealz.Payment")))
@interface MealzcoreMealzPayment : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)payment __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealzPayment *shared __attribute__((swift_name("shared")));
- (void)paymentFinishedTotalAmount:(double)totalAmount totalProductCount:(MealzcoreInt * _Nullable)totalProductCount clientOrderId:(NSString * _Nullable)clientOrderId __attribute__((swift_name("paymentFinished(totalAmount:totalProductCount:clientOrderId:)")));
- (void)paymentStartedTotalAmount:(double)totalAmount totalProductCount:(MealzcoreInt * _Nullable)totalProductCount clientOrderId:(NSString * _Nullable)clientOrderId __attribute__((swift_name("paymentStarted(totalAmount:totalProductCount:clientOrderId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Mealz.Recipe")))
@interface MealzcoreMealzRecipe : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipe __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealzRecipe *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_coroutines_coreDeferred>)getPriceOrRedirectRecipeId:(NSString *)recipeId numberOfGuest:(int32_t)numberOfGuest __attribute__((swift_name("getPriceOrRedirect(recipeId:numberOfGuest:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Mealz.User")))
@interface MealzcoreMealzUser : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)user __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealzUser *shared __attribute__((swift_name("shared")));
- (void)refreshTokenToken:(NSString *)token __attribute__((swift_name("refreshToken(token:)")));
- (void)setEnableLikeIsEnable:(BOOL)isEnable __attribute__((swift_name("setEnableLike(isEnable:)")));
- (void)setProfilingAllowanceAllowance:(BOOL)allowance __attribute__((swift_name("setProfilingAllowance(allowance:)")));
- (void)setRetailerRetailerId:(NSString *)retailerId retailerName:(NSString *)retailerName __attribute__((swift_name("setRetailer(retailerId:retailerName:)")));
- (void)setSignInRedirectionOpenSignIn:(void (^)(void))openSignIn __attribute__((swift_name("setSignInRedirection(openSignIn:)")));
- (void)setStoreIdStoreId:(NSString *)storeId __attribute__((swift_name("setStoreId(storeId:)"))) __attribute__((deprecated("setStoreId is Async which may cause unwanted side effects. Use setStoreIdWithCallBack")));
- (void)setStoreIdWithCallBackStoreId:(NSString *)storeId callBack:(void (^ _Nullable)(void))callBack __attribute__((swift_name("setStoreIdWithCallBack(storeId:callBack:)")));
- (void)setStoreLocatorRedirectionOpenStoreLocator:(void (^)(void))openStoreLocator __attribute__((swift_name("setStoreLocatorRedirection(openStoreLocator:)")));
- (void)setStoreWithMealzIdStoreId:(NSString *)storeId __attribute__((swift_name("setStoreWithMealzId(storeId:)"))) __attribute__((deprecated("setStoreWithMealzId is Async which may cause unwanted side effects. Use setStoreWithMealzIdWithCallBack")));
- (void)setStoreWithMealzIdWithCallBackStoreId:(NSString *)storeId callBack:(void (^ _Nullable)(void))callBack __attribute__((swift_name("setStoreWithMealzIdWithCallBack(storeId:callBack:)")));
- (void)updateUserIdUserId:(NSString * _Nullable)userId authorization:(MealzcoreAuthorization *)authorization __attribute__((swift_name("updateUserId(userId:authorization:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealzCoreInformation")))
@interface MealzcoreMealzCoreInformation : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mealzCoreInformation __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealzCoreInformation *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *VERSION __attribute__((swift_name("VERSION")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MiamPreferencesContext")))
@interface MealzcoreMiamPreferencesContext : MealzcoreKMMContext
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (instancetype)miamPreferencesContext __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMiamPreferencesContext *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol MealzcoreKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface MealzcoreKotlinEnum<E> : MealzcoreBase <MealzcoreKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OperatingSystem")))
@interface MealzcoreOperatingSystem : MealzcoreKotlinEnum<MealzcoreOperatingSystem *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreOperatingSystem *android __attribute__((swift_name("android")));
@property (class, readonly) MealzcoreOperatingSystem *ios __attribute__((swift_name("ios")));
+ (MealzcoreKotlinArray<MealzcoreOperatingSystem *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreOperatingSystem *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("Closable")))
@protocol MealzcoreClosable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ExecutorHelper")))
@interface MealzcoreExecutorHelper : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreExecutorHelperCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ExecutorHelper.Companion")))
@interface MealzcoreExecutorHelperCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreExecutorHelperCompanion *shared __attribute__((swift_name("shared")));
- (void)cancelRunningJobJob:(id<MealzcoreKotlinx_coroutines_coreJob> _Nullable)job __attribute__((swift_name("cancelRunningJob(job:)")));
- (id<MealzcoreKotlinx_coroutines_coreJob>)emptyJob __attribute__((swift_name("emptyJob()")));
@end

__attribute__((swift_name("IExecutorScope")))
@protocol MealzcoreIExecutorScope
@required
- (void)attach __attribute__((swift_name("attach()")));
- (void)detach __attribute__((swift_name("detach()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol MealzcoreKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((swift_name("MainExecutor")))
@interface MealzcoreMainExecutor : MealzcoreBase <MealzcoreIExecutorScope, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)addListenerKey:(NSString *)key listener:(id<MealzcoreKotlinx_coroutines_coreJob>)listener __attribute__((swift_name("addListener(key:listener:)")));
- (void)attach __attribute__((swift_name("attach()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)collectFlow:(id<MealzcoreKotlinx_coroutines_coreFlow>)flow collect:(void (^)(id _Nullable))collect __attribute__((swift_name("collect(flow:collect:)")));
- (void)detach __attribute__((swift_name("detach()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)onErrorException:(MealzcoreKotlinThrowable *)exception __attribute__((swift_name("onError(exception:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((swift_name("Action")))
@protocol MealzcoreAction
@required
@end

__attribute__((swift_name("BaseViewModel")))
@interface MealzcoreBaseViewModel<Event, State, Effect> : MealzcoreMainExecutor
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (State)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(Event)event __attribute__((swift_name("handleEvent(event:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)setEffectBuilder:(Effect (^)(void))builder __attribute__((swift_name("setEffect(builder:)")));
- (void)setEventEvent:(Event)event __attribute__((swift_name("setEvent(event:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)setStateReduce:(State (^)(State))reduce __attribute__((swift_name("setState(reduce:)")));
@property (readonly) State currentState __attribute__((swift_name("currentState")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreFlow> effect __attribute__((swift_name("effect")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreSharedFlow> event __attribute__((swift_name("event")));
@property (readonly) State initialState __attribute__((swift_name("initialState")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreStateFlow> uiState __attribute__((swift_name("uiState")));
@end

__attribute__((swift_name("BasicUiState")))
@interface MealzcoreBasicUiState<__covariant T> : MealzcoreBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasicUiStateEmpty")))
@interface MealzcoreBasicUiStateEmpty : MealzcoreBasicUiState<MealzcoreKotlinNothing *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)empty __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasicUiStateEmpty *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasicUiStateError")))
@interface MealzcoreBasicUiStateError : MealzcoreBasicUiState<MealzcoreKotlinNothing *>
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasicUiStateError *)doCopyMessage:(NSString * _Nullable)message __attribute__((swift_name("doCopy(message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasicUiStateIdle")))
@interface MealzcoreBasicUiStateIdle : MealzcoreBasicUiState<MealzcoreKotlinNothing *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)idle __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasicUiStateIdle *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasicUiStateLoading")))
@interface MealzcoreBasicUiStateLoading : MealzcoreBasicUiState<MealzcoreKotlinNothing *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loading __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasicUiStateLoading *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasicUiStateSuccess")))
@interface MealzcoreBasicUiStateSuccess<T> : MealzcoreBasicUiState<T>
- (instancetype)initWithData:(T _Nullable)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasicUiStateSuccess<T> *)doCopyData:(T _Nullable)data __attribute__((swift_name("doCopy(data:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) T _Nullable data __attribute__((swift_name("data")));
@end

__attribute__((swift_name("Effect")))
@protocol MealzcoreEffect
@required
@end

__attribute__((swift_name("State")))
@protocol MealzcoreState
@required
@end

__attribute__((swift_name("Store")))
@protocol MealzcoreStore
@required
- (id<MealzcoreKotlinx_coroutines_coreJob>)dispatchAction:(id<MealzcoreAction>)action __attribute__((swift_name("dispatch(action:)")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreStateFlow> state __attribute__((swift_name("state")));
@end

__attribute__((swift_name("UiEffect")))
@protocol MealzcoreUiEffect
@required
@end

__attribute__((swift_name("UiEvent")))
@protocol MealzcoreUiEvent
@required
@end

__attribute__((swift_name("UiState")))
@protocol MealzcoreUiState
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ComponentUiState")))
@interface MealzcoreComponentUiState : MealzcoreKotlinEnum<MealzcoreComponentUiState *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreComponentUiState *success __attribute__((swift_name("success")));
@property (class, readonly) MealzcoreComponentUiState *error __attribute__((swift_name("error")));
@property (class, readonly) MealzcoreComponentUiState *loading __attribute__((swift_name("loading")));
@property (class, readonly) MealzcoreComponentUiState *empty __attribute__((swift_name("empty")));
@property (class, readonly) MealzcoreComponentUiState *idle __attribute__((swift_name("idle")));
@property (class, readonly) MealzcoreComponentUiState *locked __attribute__((swift_name("locked")));
+ (MealzcoreKotlinArray<MealzcoreComponentUiState *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreComponentUiState *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("ParameterisedUseCase")))
@protocol MealzcoreParameterisedUseCase
@required

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id _Nullable)invokeInput:(id _Nullable)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((swift_name("UseCase")))
@protocol MealzcoreUseCase
@required

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id _Nullable)invokeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke()"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ActionStatus")))
@interface MealzcoreActionStatus : MealzcoreKotlinEnum<MealzcoreActionStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreActionStatus *initialState __attribute__((swift_name("initialState")));
@property (class, readonly) MealzcoreActionStatus *sentToRetailer __attribute__((swift_name("sentToRetailer")));
@property (class, readonly) MealzcoreActionStatus *retailerProductMatch __attribute__((swift_name("retailerProductMatch")));
@property (class, readonly) MealzcoreActionStatus *addedToMealz __attribute__((swift_name("addedToMealz")));
@property (class, readonly) MealzcoreActionStatus *sentToRetailerAlreadyInMealz __attribute__((swift_name("sentToRetailerAlreadyInMealz")));
@property (class, readonly) MealzcoreActionStatus *alreadyAddedToMealz __attribute__((swift_name("alreadyAddedToMealz")));
+ (MealzcoreKotlinArray<MealzcoreActionStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreActionStatus *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ActionType")))
@interface MealzcoreActionType : MealzcoreKotlinEnum<MealzcoreActionType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreActionType *add __attribute__((swift_name("add")));
@property (class, readonly) MealzcoreActionType *remove __attribute__((swift_name("remove")));
@property (class, readonly) MealzcoreActionType *replace __attribute__((swift_name("replace")));
@property (class, readonly) MealzcoreActionType *update __attribute__((swift_name("update")));
@property (class, readonly) MealzcoreActionType *ignore __attribute__((swift_name("ignore")));
+ (MealzcoreKotlinArray<MealzcoreActionType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreActionType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketSummary")))
@interface MealzcoreBasketSummary : MealzcoreBase
- (instancetype)initWithAdded:(int32_t)added mutual:(int32_t)mutual outOfStock:(int32_t)outOfStock total:(int32_t)total __attribute__((swift_name("init(added:mutual:outOfStock:total:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketSummary *)doCopyAdded:(int32_t)added mutual:(int32_t)mutual outOfStock:(int32_t)outOfStock total:(int32_t)total __attribute__((swift_name("doCopy(added:mutual:outOfStock:total:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int32_t added __attribute__((swift_name("added")));
@property int32_t mutual __attribute__((swift_name("mutual")));
@property int32_t outOfStock __attribute__((swift_name("outOfStock")));
@property int32_t total __attribute__((swift_name("total")));
@end

__attribute__((swift_name("MealzBasketAction")))
@interface MealzcoreMealzBasketAction : MealzcoreMainExecutor
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property MealzcoreActionStatus *actionStatus __attribute__((swift_name("actionStatus")));
@property MealzcoreActionType *actionType __attribute__((swift_name("actionType")));
@property MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@property void (^ _Nullable callback)(MealzcoreBasketEntry *) __attribute__((swift_name("callback")));
@property (readonly) NSString *extId __attribute__((swift_name("extId")));
@property MealzcoreInt * _Nullable guests __attribute__((swift_name("guests")));
@property MealzcoreIngredient * _Nullable ingredient __attribute__((swift_name("ingredient")));
@property BOOL isTimeOut __attribute__((swift_name("isTimeOut")));
@property MealzcoreSupplierProduct * _Nullable retailerProduct __attribute__((swift_name("retailerProduct")));
@property MealzcoreMealzTimer *timer __attribute__((swift_name("timer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealzBasketActionAdd")))
@interface MealzcoreMealzBasketActionAdd : MealzcoreMealzBasketAction
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient *)ingredient guests:(int32_t)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(basketEntry:ingredient:guests:callback:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealzBasketActionAddRecipe")))
@interface MealzcoreMealzBasketActionAddRecipe : MealzcoreMealzBasketAction
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealzBasketActionIgnore")))
@interface MealzcoreMealzBasketActionIgnore : MealzcoreMealzBasketAction
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient *)ingredient callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(basketEntry:ingredient:callback:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((swift_name("MealzBasketActionRemove")))
@interface MealzcoreMealzBasketActionRemove : MealzcoreMealzBasketAction
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(basketEntry:callback:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((swift_name("MealzBasketActionRemoveRecipe")))
@interface MealzcoreMealzBasketActionRemoveRecipe : MealzcoreMealzBasketAction
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((swift_name("MealzBasketActionReplace")))
@interface MealzcoreMealzBasketActionReplace : MealzcoreMealzBasketAction
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient newItem:(MealzcoreItem *)newItem guests:(int32_t)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(basketEntry:ingredient:newItem:guests:callback:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) NSString *extId __attribute__((swift_name("extId")));
@property (getter=doNewItem) MealzcoreItem *newItem __attribute__((swift_name("newItem")));
@end

__attribute__((swift_name("MealzBasketActionTransferBasket")))
@interface MealzcoreMealzBasketActionTransferBasket : MealzcoreMealzBasketAction
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry newQuantity:(int32_t)newQuantity __attribute__((swift_name("init(basketEntry:newQuantity:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (getter=doNewQuantity) int32_t newQuantity __attribute__((swift_name("newQuantity")));
@end

__attribute__((swift_name("MealzBasketActionUpdate")))
@interface MealzcoreMealzBasketActionUpdate : MealzcoreMealzBasketAction
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry newQuantity:(int32_t)newQuantity callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(basketEntry:newQuantity:callback:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (getter=doNewQuantity) int32_t newQuantity __attribute__((swift_name("newQuantity")));
@end

__attribute__((swift_name("MealzBasketActionUpdateFromRecipe")))
@interface MealzcoreMealzBasketActionUpdateFromRecipe : MealzcoreMealzBasketAction
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry newQuantity:(int32_t)newQuantity __attribute__((swift_name("init(basketEntry:newQuantity:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (getter=doNewQuantity) int32_t newQuantity __attribute__((swift_name("newQuantity")));
@end

__attribute__((swift_name("MealzBasketActionUpdateFromRetailer")))
@interface MealzcoreMealzBasketActionUpdateFromRetailer : MealzcoreMealzBasketAction
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry newQuantity:(int32_t)newQuantity __attribute__((swift_name("init(basketEntry:newQuantity:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithActionType:(MealzcoreActionType *)actionType actionStatus:(MealzcoreActionStatus *)actionStatus basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient retailerProduct:(MealzcoreSupplierProduct * _Nullable)retailerProduct guests:(MealzcoreInt * _Nullable)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("init(actionType:actionStatus:basketEntry:ingredient:retailerProduct:guests:callback:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (getter=doNewQuantity) int32_t newQuantity __attribute__((swift_name("newQuantity")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealzBasketComparator")))
@interface MealzcoreMealzBasketComparator : MealzcoreMainExecutor
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)addProductsFromMealzBasketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient *)ingredient guests:(int32_t)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("addProductsFromMealz(basketEntry:ingredient:guests:callback:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)addRecipeFromMealzRecipes:(NSArray<MealzcoreRecipeInfos *> *)recipes completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("addRecipeFromMealz(recipes:completionHandler:)")));
- (void)confirmBasket __attribute__((swift_name("confirmBasket()")));
- (MealzcoreInt * _Nullable)getRetailerCartCountExtId:(NSString *)extId __attribute__((swift_name("getRetailerCartCount(extId:)")));
- (void)ignoreProductFromMealzBasketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient *)ingredient callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("ignoreProductFromMealz(basketEntry:ingredient:callback:)")));
- (void)processRetailerBasketRetailerBasket:(NSArray<MealzcoreSupplierProduct *> *)retailerBasket __attribute__((swift_name("processRetailerBasket(retailerBasket:)")));
- (void)reInitOnStoreChange __attribute__((swift_name("reInitOnStoreChange()")));
- (void)removeProductsFromMealzBasketEntry:(MealzcoreBasketEntry *)basketEntry callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("removeProductsFromMealz(basketEntry:callback:)")));
- (void)removeRecipeFromMealzRecipes:(NSArray<NSString *> *)recipes __attribute__((swift_name("removeRecipeFromMealz(recipes:)")));
- (void)removeRetailerProductsRetailerProduct:(NSArray<MealzcoreSupplierProduct *> *)retailerProduct __attribute__((swift_name("removeRetailerProducts(retailerProduct:)")));
- (void)replaceProductsFromMealzBasketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient * _Nullable)ingredient newItem:(MealzcoreItem *)newItem guests:(int32_t)guests callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("replaceProductsFromMealz(basketEntry:ingredient:newItem:guests:callback:)")));
- (void)resetBasket __attribute__((swift_name("resetBasket()")));
- (void)setInitialBasketInitialProducts:(NSArray<MealzcoreSupplierProduct *> *)initialProducts __attribute__((swift_name("setInitialBasket(initialProducts:)")));
- (void)setMealzProductMealzProduct:(NSArray<MealzcoreBasketEntry *> *)mealzProduct __attribute__((swift_name("setMealzProduct(mealzProduct:)")));
- (void)transferBasketOldBasket:(MealzcoreBasket * _Nullable)oldBasket newBasket:(MealzcoreBasket *)newBasket __attribute__((swift_name("transferBasket(oldBasket:newBasket:)")));
- (void)updateProductQuantityBasketEntry:(MealzcoreBasketEntry *)basketEntry quantity:(int32_t)quantity callback:(void (^ _Nullable)(MealzcoreBasketEntry *))callback __attribute__((swift_name("updateProductQuantity(basketEntry:quantity:callback:)")));
- (void)updateRecipeGuestCountRecipeId:(NSString *)recipeId guestNumber:(int32_t)guestNumber ingredientIdAssociatedToSelectedItemId:(NSDictionary<NSString *, id> *)ingredientIdAssociatedToSelectedItemId unlockChildrenCallBack:(void (^)(void))unlockChildrenCallBack updateGuestInChildrenCallbacks:(void (^)(void))updateGuestInChildrenCallbacks __attribute__((swift_name("updateRecipeGuestCount(recipeId:guestNumber:ingredientIdAssociatedToSelectedItemId:unlockChildrenCallBack:updateGuestInChildrenCallbacks:)")));
@property id<MealzcoreBasketSubscriber> _Nullable basketSubscriber __attribute__((swift_name("basketSubscriber")));
@property MealzcoreBasketSummary *basketSummary __attribute__((swift_name("basketSummary")));
@property BOOL firstMealzBasketInitialised __attribute__((swift_name("firstMealzBasketInitialised")));
@property BOOL isInitialised __attribute__((swift_name("isInitialised")));
@property (readonly) void (^removeDebouncedWork)(void) __attribute__((swift_name("removeDebouncedWork")));
@property (readonly) int32_t retailerBasketProductCount __attribute__((swift_name("retailerBasketProductCount")));
@property (readonly) void (^sendToRetailerDebouncer)(void) __attribute__((swift_name("sendToRetailerDebouncer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Client")))
@interface MealzcoreClient : MealzcoreBase
- (instancetype)initWithUserStore:(id<MealzcoreUserStore>)userStore __attribute__((swift_name("init(userStore:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("RecipeDataSource")))
@protocol MealzcoreRecipeDataSource
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getLiteRecipeByExtIdListRecipeExtIdList:(NSArray<NSString *> *)recipeExtIdList pageSize:(int32_t)pageSize completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getLiteRecipeByExtIdList(recipeExtIdList:pageSize:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByExtIdExtId:(NSString *)extId included:(NSArray<NSString *> *)included completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByExtId(extId:included:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByExtIdLiteExtId:(NSString *)extId completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByExtIdLite(extId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByIdId:(NSString *)id included:(NSArray<NSString *> * _Nullable)included completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeById(id:included:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByIdForCatalogId:(NSString *)id included:(NSArray<NSString *> * _Nullable)included completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByIdForCatalog(id:included:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByIdLiteId:(NSString *)id completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByIdLite(id:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByIdsRecipesIds:(NSArray<NSString *> *)recipesIds included:(NSArray<NSString *> * _Nullable)included pageSize:(int32_t)pageSize completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByIds(recipesIds:included:pageSize:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByIdsChunkRecipesIds:(NSArray<NSString *> *)recipesIds included:(NSArray<NSString *> * _Nullable)included pageSize:(int32_t)pageSize completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByIdsChunk(recipesIds:included:pageSize:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeForBudgetConstraintPointOfSale:(NSString *)pointOfSale budget:(int32_t)budget guestCount:(int32_t)guestCount mealcount:(int32_t)mealcount completionHandler:(void (^)(NSArray<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeForBudgetConstraint(pointOfSale:budget:guestCount:mealcount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeNumberOfResultFilters:(NSDictionary<NSString *, NSString *> *)filters completionHandler:(void (^)(MealzcoreInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeNumberOfResult(filters:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeStickerPriceRecipeId:(NSString *)recipeId posId:(NSString *)posId serves:(int32_t)serves completionHandler:(void (^)(MealzcoreRecipePricing * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeStickerPrice(recipeId:posId:serves:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeSuggestionsSupplierId:(NSString *)supplierId size:(MealzcoreInt * _Nullable)size criteria:(MealzcoreSuggestionsCriteria *)criteria included:(NSArray<NSString *> *)included pointOfSale:(NSString *)pointOfSale guestCount:(int32_t)guestCount completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeSuggestions(supplierId:size:criteria:included:pointOfSale:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeWithAvailableIngredientsNumberOfResultFilters:(NSDictionary<NSString *, NSString *> *)filters posId:(NSString *)posId guestCount:(int32_t)guestCount completionHandler:(void (^)(MealzcoreInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeWithAvailableIngredientsNumberOfResult(filters:posId:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesFilters:(NSDictionary<NSString *, NSString *> *)filters included:(NSArray<NSString *> *)included pageSize:(int32_t)pageSize pageNumber:(int32_t)pageNumber sort:(MealzcoreRecipeSort *)sort completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipes(filters:included:pageSize:pageNumber:sort:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesBySearchSearchTerm:(NSString *)searchTerm showUnavailableRecipes:(BOOL)showUnavailableRecipes filters:(NSDictionary<NSString *, NSString *> *)filters included:(NSArray<NSString *> *)included pageSize:(int32_t)pageSize pageNumber:(int32_t)pageNumber pointOfSaleId:(NSString * _Nullable)pointOfSaleId sort:(MealzcoreRecipeSort *)sort guestCount:(int32_t)guestCount primordialOnly:(BOOL)primordialOnly completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesBySearch(searchTerm:showUnavailableRecipes:filters:included:pageSize:pageNumber:pointOfSaleId:sort:guestCount:primordialOnly:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesMaxCountForBudgetConstraintPointOfSale:(NSString *)pointOfSale budget:(int32_t)budget guestCount:(int32_t)guestCount completionHandler:(void (^)(MealzcoreInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesMaxCountForBudgetConstraint(pointOfSale:budget:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesWithPOSFilters:(NSDictionary<NSString *, NSString *> *)filters included:(NSArray<NSString *> *)included pageSize:(int32_t)pageSize pageNumber:(int32_t)pageNumber sort:(MealzcoreRecipeSort *)sort pointOfSale:(NSString *)pointOfSale guestCount:(int32_t)guestCount primordialOnly:(BOOL)primordialOnly completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesWithPOS(filters:included:pageSize:pageNumber:sort:pointOfSale:guestCount:primordialOnly:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeFilter")))
@interface MealzcoreRecipeFilter : MealzcoreKotlinEnum<MealzcoreRecipeFilter *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreRecipeFilter *packages __attribute__((swift_name("packages")));
@property (class, readonly) MealzcoreRecipeFilter *difficulty __attribute__((swift_name("difficulty")));
@property (class, readonly) MealzcoreRecipeFilter *cost __attribute__((swift_name("cost")));
@property (class, readonly) MealzcoreRecipeFilter *totalTime __attribute__((swift_name("totalTime")));
@property (class, readonly) MealzcoreRecipeFilter *liked __attribute__((swift_name("liked")));
@property (class, readonly) MealzcoreRecipeFilter *includeTags __attribute__((swift_name("includeTags")));
@property (class, readonly) MealzcoreRecipeFilter *excludeTags __attribute__((swift_name("excludeTags")));
@property (class, readonly) MealzcoreRecipeFilter *active __attribute__((swift_name("active")));
@property (class, readonly) MealzcoreRecipeFilter *discount __attribute__((swift_name("discount")));
+ (MealzcoreKotlinArray<MealzcoreRecipeFilter *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreRecipeFilter *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *filterName __attribute__((swift_name("filterName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BudgetRepository")))
@interface MealzcoreBudgetRepository : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreBudgetRepositoryCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BudgetRepository.Companion")))
@interface MealzcoreBudgetRepositoryCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBudgetRepositoryCompanion *shared __attribute__((swift_name("shared")));
@property double availableBudget __attribute__((swift_name("availableBudget")));
@property int32_t budget __attribute__((swift_name("budget")));
@property int32_t guestCount __attribute__((swift_name("guestCount")));
@property int32_t mealCount __attribute__((swift_name("mealCount")));
@end

__attribute__((swift_name("SponsorBlockRepository")))
@protocol MealzcoreSponsorBlockRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSponsorBlocksBySponsorIdSponsorId:(NSString *)sponsorId completionHandler:(void (^)(NSArray<MealzcoreSponsorBlock *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSponsorBlocksBySponsorId(sponsorId:completionHandler:)")));
@end

__attribute__((swift_name("BasketRepository")))
@protocol MealzcoreBasketRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)abortTransferWithCompletionHandler:(void (^)(MealzcoreBasket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("abortTransfer(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)addRecipesToBasketWithIngredientBasketId:(NSString *)basketId recipeInfos:(NSArray<MealzcoreRecipeInfos *> *)recipeInfos completionHandler:(void (^)(MealzcoreBasket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("addRecipesToBasketWithIngredient(basketId:recipeInfos:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)addRecipesToBasketWithoutIngredientBasketId:(NSString *)basketId recipeInfos:(NSArray<MealzcoreRecipeInfos *> *)recipeInfos completionHandler:(void (^)(MealzcoreBasket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("addRecipesToBasketWithoutIngredient(basketId:recipeInfos:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)confirmBasketWithCompletionHandler:(void (^)(MealzcoreBasket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("confirmBasket(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)fetchBasketHistoryPageSize:(int32_t)pageSize pageNumber:(int32_t)pageNumber completionHandler:(void (^)(NSArray<MealzcoreBasket *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("fetchBasketHistory(pageSize:pageNumber:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getBasketPriceWithCompletionHandler:(void (^)(MealzcoreDouble * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getBasketPrice(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCurrentBasketFromPosPosId:(NSString *)posId completionHandler:(void (^)(MealzcoreBasket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCurrentBasketFromPos(posId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeRecipesFromBasketBasketId:(NSString *)basketId recipeIds:(NSArray<NSString *> *)recipeIds completionHandler:(void (^)(MealzcoreBasket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("removeRecipesFromBasket(basketId:recipeIds:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)resetBasketWithCompletionHandler:(void (^)(MealzcoreBasket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("resetBasket(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)searchBasketHistorySearchText:(NSString *)searchText completionHandler:(void (^)(NSArray<MealzcoreBasket *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("searchBasketHistory(searchText:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startTransferWithCompletionHandler:(void (^)(MealzcoreStartTransferResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startTransfer(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)transferAffiliateBasketToSupplierPosId:(NSString *)posId basketToken:(NSString *)basketToken completionHandler:(void (^)(MealzcoreBasket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("transferAffiliateBasketToSupplier(posId:basketToken:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)transferAuthlessPosId:(NSString *)posId authlessUserId:(NSString *)authlessUserId completionHandler:(void (^)(MealzcoreBasket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("transferAuthless(posId:authlessUserId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateRecipesInBasketBasketId:(NSString *)basketId recipeInfos:(NSArray<MealzcoreRecipeInfos *> *)recipeInfos completionHandler:(void (^)(MealzcoreBasket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateRecipesInBasket(basketId:recipeInfos:completionHandler:)")));
@end

__attribute__((swift_name("BasketEntryRepository")))
@protocol MealzcoreBasketEntryRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)addProductToBasketBasketId:(NSString *)basketId item:(MealzcoreItem *)item completionHandler:(void (^)(MealzcoreBasketEntry * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("addProductToBasket(basketId:item:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)addRecipeProductToBasketBasketId:(NSString *)basketId basketEntry:(MealzcoreBasketEntry *)basketEntry ingredient:(MealzcoreIngredient *)ingredient guests:(int32_t)guests completionHandler:(void (^)(MealzcoreBasketEntry * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("addRecipeProductToBasket(basketId:basketEntry:ingredient:guests:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getBasketEntryForIngredientBasketId:(NSString *)basketId ingredientId:(NSString *)ingredientId selectedItemId:(MealzcoreInt * _Nullable)selectedItemId guests:(int32_t)guests completionHandler:(void (^)(MealzcoreBasketEntry * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getBasketEntryForIngredient(basketId:ingredientId:selectedItemId:guests:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeProductFromBasketBasketEntry:(MealzcoreBasketEntry *)basketEntry completionHandler:(void (^)(MealzcoreBasketEntry * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("removeProductFromBasket(basketEntry:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)removeRecipeProductFromBasketBasketId:(NSString *)basketId basketEntry:(MealzcoreBasketEntry *)basketEntry completionHandler:(void (^)(MealzcoreBasketEntry * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("removeRecipeProductFromBasket(basketId:basketEntry:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)replaceBasketEntryBasketEntryId:(NSString *)basketEntryId replacementItemId:(NSString *)replacementItemId completionHandler:(void (^)(MealzcoreBasketEntry * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("replaceBasketEntry(basketEntryId:replacementItemId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateBasketEntryBasketEntry:(MealzcoreBasketEntry *)basketEntry completionHandler:(void (^)(MealzcoreBasketEntry * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateBasketEntry(basketEntry:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateBasketEntryQuantityBasketEntry:(MealzcoreBasketEntry *)basketEntry completionHandler:(void (^)(MealzcoreBasketEntry * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateBasketEntryQuantity(basketEntry:completionHandler:)")));
@end

__attribute__((swift_name("ItemRepository")))
@protocol MealzcoreItemRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)fetchWithIngredientIdIngredientId:(NSString *)ingredientId completionHandler:(void (^)(NSArray<MealzcoreItem *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("fetchWithIngredientId(ingredientId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPriceItemId:(NSString *)itemId posId:(NSString *)posId completionHandler:(void (^)(MealzcoreItemPrice * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPrice(itemId:posId:completionHandler:)")));
- (void)resetLocalItemPrice __attribute__((swift_name("resetLocalItemPrice()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)searchSearch:(NSString *)search ingredientId:(NSString *)ingredientId completionHandler:(void (^)(NSArray<MealzcoreItem *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("search(search:ingredientId:completionHandler:)")));
@end

__attribute__((swift_name("ItemSelectorJourney")))
@protocol MealzcoreItemSelectorJourney
@required
- (MealzcoreItemSelectorWithBasketEntryNavigationData *)getItemSelectorWithBasketEntryJourneyBasketEntryId:(NSString *)basketEntryId __attribute__((swift_name("getItemSelectorWithBasketEntryJourney(basketEntryId:)")));
- (MealzcoreItemSelectorWithIngredientNavigationData *)getItemSelectorWithIngredientJourneyIngredientId:(NSString *)ingredientId __attribute__((swift_name("getItemSelectorWithIngredientJourney(ingredientId:)")));
- (void)saveItemSelectorJourneyData:(MealzcoreItemSelectorNavigationData *)data __attribute__((swift_name("saveItemSelectorJourney(data:)")));
@end

__attribute__((swift_name("PointOfSaleRepository")))
@protocol MealzcorePointOfSaleRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPosFromExtIdExtId:(NSString *)extId supplierId:(NSString * _Nullable)supplierId completionHandler:(void (^)(MealzcorePointOfSale * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPosFromExtId(extId:supplierId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPosFromIdMealzPosId:(NSString *)mealzPosId completionHandler:(void (^)(MealzcorePointOfSale * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPosFromId(mealzPosId:completionHandler:)")));
- (void)setStoreStore:(MealzcoreStore * _Nullable)store __attribute__((swift_name("setStore(store:)")));
@property void (^forceHostPos)(NSString *) __attribute__((swift_name("forceHostPos")));
@property void (^redirectToStoreLocator)(void) __attribute__((swift_name("redirectToStoreLocator")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PointOfSaleRepositoryCompanion")))
@interface MealzcorePointOfSaleRepositoryCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePointOfSaleRepositoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) BOOL isPointOfSaleSet __attribute__((swift_name("isPointOfSaleSet")));
@property NSString * _Nullable pointOfSaleAddress __attribute__((swift_name("pointOfSaleAddress")));
@property NSString * _Nullable pointOfSaleExternalId __attribute__((swift_name("pointOfSaleExternalId")));
@property NSString * _Nullable pointOfSaleMealzId __attribute__((swift_name("pointOfSaleMealzId")));
@property NSString * _Nullable pointOfSaleName __attribute__((swift_name("pointOfSaleName")));
@property MealzcoreStore * _Nullable store __attribute__((swift_name("store")));
@end

__attribute__((swift_name("GuestByRecipeRepository")))
@protocol MealzcoreGuestByRecipeRepository
@required
- (void)clear __attribute__((swift_name("clear()")));
- (MealzcoreInt * _Nullable)getGuestForRecipeOrNullRecipeId:(NSString *)recipeId __attribute__((swift_name("getGuestForRecipeOrNull(recipeId:)")));
- (void)setGuestFroRecipeRecipeId:(NSString *)recipeId guestCount:(int32_t)guestCount __attribute__((swift_name("setGuestFroRecipe(recipeId:guestCount:)")));
@end

__attribute__((swift_name("RecipeRepository")))
@protocol MealzcoreRecipeRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getLiteRecipeByExtIdListExtRecipeIdList:(NSArray<NSString *> *)extRecipeIdList completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getLiteRecipeByExtIdList(extRecipeIdList:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByExtIdRecipeExtId:(NSString *)recipeExtId included:(NSArray<NSString *> * _Nullable)included completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByExtId(recipeExtId:included:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByExtIdWithRelationsRecipeExtId:(NSString *)recipeExtId completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByExtIdWithRelations(recipeExtId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByIdRecipeId:(NSString *)recipeId included:(NSArray<NSString *> * _Nullable)included isFromCatalog:(BOOL)isFromCatalog completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeById(recipeId:included:isFromCatalog:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByIdWithRelationsRecipeId:(NSString *)recipeId completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByIdWithRelations(recipeId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeNumberOfResultFilters:(NSDictionary<NSString *, NSString *> *)filters completionHandler:(void (^)(MealzcoreInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeNumberOfResult(filters:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeStickerPriceRecipeId:(NSString *)recipeId posId:(NSString *)posId serves:(int32_t)serves completionHandler:(void (^)(MealzcoreRecipePricing * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeStickerPrice(recipeId:posId:serves:completionHandler:)")));
- (MealzcoreRecipePricing * _Nullable)getRecipeStickerPriceFromLocalDataRecipePricingKey:(NSString *)recipePricingKey __attribute__((swift_name("getRecipeStickerPriceFromLocalData(recipePricingKey:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeSuggestionSupplierId:(NSString *)supplierId criteria:(MealzcoreSuggestionsCriteria *)criteria pointOfSale:(NSString *)pointOfSale guestCount:(int32_t)guestCount completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeSuggestion(supplierId:criteria:pointOfSale:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeSuggestionsSupplierId:(NSString *)supplierId criteria:(MealzcoreSuggestionsCriteria *)criteria size:(int32_t)size pointOfSale:(NSString *)pointOfSale guestCount:(int32_t)guestCount completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeSuggestions(supplierId:criteria:size:pointOfSale:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeWithAvailableIngredientsNumberOfResultFilters:(NSDictionary<NSString *, NSString *> *)filters posId:(NSString *)posId guestCount:(int32_t)guestCount completionHandler:(void (^)(MealzcoreInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeWithAvailableIngredientsNumberOfResult(filters:posId:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesByIdsRecipeIds:(NSArray<NSString *> *)recipeIds included:(NSArray<NSString *> * _Nullable)included completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesByIds(recipeIds:included:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesForBudgetConstraintPointOfSale:(NSString *)pointOfSale budget:(int32_t)budget mealCount:(int32_t)mealCount guestCount:(int32_t)guestCount completionHandler:(void (^)(NSArray<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesForBudgetConstraint(pointOfSale:budget:mealCount:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesIdWithExtIdRecipeExtId:(NSString *)recipeExtId completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesIdWithExtId(recipeExtId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesMaxCountForBudgetConstraintPointOfSale:(NSString *)pointOfSale budget:(int32_t)budget guestCount:(int32_t)guestCount completionHandler:(void (^)(MealzcoreInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesMaxCountForBudgetConstraint(pointOfSale:budget:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)recipeExistsRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId completionHandler:(void (^)(MealzcoreBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("recipeExists(recipeId:isExtId:completionHandler:)")));
- (void)resetRecipePricing __attribute__((swift_name("resetRecipePricing()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeRepositoryImp")))
@interface MealzcoreRecipeRepositoryImp : MealzcoreBase <MealzcoreRecipeRepository>
- (instancetype)initWithRecipeDataSource:(id<MealzcoreRecipeDataSource>)recipeDataSource __attribute__((swift_name("init(recipeDataSource:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeRepositoryImpCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getLiteRecipeByExtIdListExtRecipeIdList:(NSArray<NSString *> *)extRecipeIdList completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getLiteRecipeByExtIdList(extRecipeIdList:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByExtIdRecipeExtId:(NSString *)recipeExtId included:(NSArray<NSString *> * _Nullable)included completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByExtId(recipeExtId:included:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByExtIdWithRelationsRecipeExtId:(NSString *)recipeExtId completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByExtIdWithRelations(recipeExtId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByIdRecipeId:(NSString *)recipeId included:(NSArray<NSString *> * _Nullable)included isFromCatalog:(BOOL)isFromCatalog completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeById(recipeId:included:isFromCatalog:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeByIdWithRelationsRecipeId:(NSString *)recipeId completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeByIdWithRelations(recipeId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeNumberOfResultFilters:(NSDictionary<NSString *, NSString *> *)filters completionHandler:(void (^)(MealzcoreInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeNumberOfResult(filters:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeStickerPriceRecipeId:(NSString *)recipeId posId:(NSString *)posId serves:(int32_t)serves completionHandler:(void (^)(MealzcoreRecipePricing * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeStickerPrice(recipeId:posId:serves:completionHandler:)")));
- (MealzcoreRecipePricing * _Nullable)getRecipeStickerPriceFromLocalDataRecipePricingKey:(NSString *)recipePricingKey __attribute__((swift_name("getRecipeStickerPriceFromLocalData(recipePricingKey:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeSuggestionSupplierId:(NSString *)supplierId criteria:(MealzcoreSuggestionsCriteria *)criteria pointOfSale:(NSString *)pointOfSale guestCount:(int32_t)guestCount completionHandler:(void (^)(MealzcoreRecipe * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeSuggestion(supplierId:criteria:pointOfSale:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeSuggestionsSupplierId:(NSString *)supplierId criteria:(MealzcoreSuggestionsCriteria *)criteria size:(int32_t)size pointOfSale:(NSString *)pointOfSale guestCount:(int32_t)guestCount completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeSuggestions(supplierId:criteria:size:pointOfSale:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipeWithAvailableIngredientsNumberOfResultFilters:(NSDictionary<NSString *, NSString *> *)filters posId:(NSString *)posId guestCount:(int32_t)guestCount completionHandler:(void (^)(MealzcoreInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipeWithAvailableIngredientsNumberOfResult(filters:posId:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesFilters:(NSDictionary<NSString *, NSString *> *)filters included:(NSArray<NSString *> *)included pageSize:(int32_t)pageSize pageNumber:(int32_t)pageNumber sort:(MealzcoreRecipeSort *)sort completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipes(filters:included:pageSize:pageNumber:sort:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesByIdsRecipeIds:(NSArray<NSString *> *)recipeIds included:(NSArray<NSString *> * _Nullable)included completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesByIds(recipeIds:included:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesBySearchSearchTerm:(NSString *)searchTerm showUnavailableRecipes:(BOOL)showUnavailableRecipes filters:(NSDictionary<NSString *, NSString *> *)filters included:(NSArray<NSString *> *)included pageSize:(int32_t)pageSize pageNumber:(int32_t)pageNumber pointOfSaleId:(NSString * _Nullable)pointOfSaleId sort:(MealzcoreRecipeSort *)sort guestCount:(int32_t)guestCount primordialOnly:(BOOL)primordialOnly completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesBySearch(searchTerm:showUnavailableRecipes:filters:included:pageSize:pageNumber:pointOfSaleId:sort:guestCount:primordialOnly:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesForBudgetConstraintPointOfSale:(NSString *)pointOfSale budget:(int32_t)budget mealCount:(int32_t)mealCount guestCount:(int32_t)guestCount completionHandler:(void (^)(NSArray<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesForBudgetConstraint(pointOfSale:budget:mealCount:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesIdWithExtIdRecipeExtId:(NSString *)recipeExtId completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesIdWithExtId(recipeExtId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesMaxCountForBudgetConstraintPointOfSale:(NSString *)pointOfSale budget:(int32_t)budget guestCount:(int32_t)guestCount completionHandler:(void (^)(MealzcoreInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesMaxCountForBudgetConstraint(pointOfSale:budget:guestCount:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesWithPOSFilters:(NSDictionary<NSString *, NSString *> *)filters included:(NSArray<NSString *> *)included pageSize:(int32_t)pageSize pageNumber:(int32_t)pageNumber sort:(MealzcoreRecipeSort *)sort pointOfSale:(NSString *)pointOfSale guestCount:(int32_t)guestCount primordialOnly:(BOOL)primordialOnly completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesWithPOS(filters:included:pageSize:pageNumber:sort:pointOfSale:guestCount:primordialOnly:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)recipeExistsRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId completionHandler:(void (^)(MealzcoreBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("recipeExists(recipeId:isExtId:completionHandler:)")));
- (void)resetRecipePricing __attribute__((swift_name("resetRecipePricing()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeRepositoryImp.Companion")))
@interface MealzcoreRecipeRepositoryImpCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeRepositoryImpCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) int32_t DEFAULT_PAGE_SIZE __attribute__((swift_name("DEFAULT_PAGE_SIZE")));
@property (readonly) int32_t FIRST_PAGE __attribute__((swift_name("FIRST_PAGE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeSort")))
@interface MealzcoreRecipeSort : MealzcoreKotlinEnum<MealzcoreRecipeSort *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreRecipeSort *noSort __attribute__((swift_name("noSort")));
@property (class, readonly) MealzcoreRecipeSort *byPositionInPackage __attribute__((swift_name("byPositionInPackage")));
@property (class, readonly) MealzcoreRecipeSort *byComputedPrice __attribute__((swift_name("byComputedPrice")));
@property (class, readonly) MealzcoreRecipeSort *byPrice __attribute__((swift_name("byPrice")));
+ (MealzcoreKotlinArray<MealzcoreRecipeSort *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreRecipeSort *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *sortName __attribute__((swift_name("sortName")));
@end

__attribute__((swift_name("RetailerRepository")))
@protocol MealzcoreRetailerRepository
@required
- (void)setRetailerRetailerId:(NSString * _Nullable)retailerId retailerName:(NSString * _Nullable)retailerName retailerLogoUrl:(NSString * _Nullable)retailerLogoUrl __attribute__((swift_name("setRetailer(retailerId:retailerName:retailerLogoUrl:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RetailerRepositoryCompanion")))
@interface MealzcoreRetailerRepositoryCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRetailerRepositoryCompanion *shared __attribute__((swift_name("shared")));
@property MealzcoreRetailer * _Nullable retailer __attribute__((swift_name("retailer")));
@property NSString * _Nullable retailerId __attribute__((swift_name("retailerId")));
@property NSString * _Nullable retailerLogoUrl __attribute__((swift_name("retailerLogoUrl")));
@property NSString * _Nullable retailerName __attribute__((swift_name("retailerName")));
@end

__attribute__((swift_name("SupplierRepository")))
@protocol MealzcoreSupplierRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getSupplierSupplierId:(NSString *)supplierId completionHandler:(void (^)(MealzcoreSupplier * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getSupplier(supplierId:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)notifyConfirmBasketBasketToken:(NSString *)basketToken completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("notifyConfirmBasket(basketToken:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)notifyPaidBasketBasketToken:(NSString *)basketToken price:(NSString *)price completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("notifyPaidBasket(basketToken:price:completionHandler:)")));
@end

__attribute__((swift_name("UserRepository")))
@protocol MealzcoreUserRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAuthlessUserWithCompletionHandler:(void (^)(MealzcoreAuthLessUser * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAuthlessUser(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealzDI")))
@interface MealzcoreMealzDI : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mealzDI __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealzDI *shared __attribute__((swift_name("shared")));
@property (readonly) id<MealzcoreAnalytics> analyticsService __attribute__((swift_name("analyticsService")));
@property (readonly) MealzcoreSingletonPreferencesViewModel *preferencesViewModel __attribute__((swift_name("preferencesViewModel")));
@property (readonly) MealzcoreRecipeRepositoryImp *recipeRepository __attribute__((swift_name("recipeRepository")));
@property (readonly) MealzcoreRouteService *routeService __attribute__((swift_name("routeService")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler")))
@interface MealzcoreLogHandler : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreLogHandlerCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler.Companion")))
@interface MealzcoreLogHandlerCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreLogHandlerCompanion *shared __attribute__((swift_name("shared")));
@property void (^debug)(NSString *) __attribute__((swift_name("debug")));
@property void (^error)(NSString *) __attribute__((swift_name("error")));
@property void (^info)(NSString *) __attribute__((swift_name("info")));
@property BOOL keepLog __attribute__((swift_name("keepLog")));
@property MealzcoreLogHandlerLogLevels *logLevel __attribute__((swift_name("logLevel")));
@property NSString *stackTrace __attribute__((swift_name("stackTrace")));
@property void (^warn)(NSString *) __attribute__((swift_name("warn")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler.LogLevels")))
@interface MealzcoreLogHandlerLogLevels : MealzcoreKotlinEnum<MealzcoreLogHandlerLogLevels *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreLogHandlerLogLevels *allLogs __attribute__((swift_name("allLogs")));
@property (class, readonly) MealzcoreLogHandlerLogLevels *errorsOnly __attribute__((swift_name("errorsOnly")));
@property (class, readonly) MealzcoreLogHandlerLogLevels *errorsAndWarns __attribute__((swift_name("errorsAndWarns")));
@property (class, readonly) MealzcoreLogHandlerLogLevels *noLogs __attribute__((swift_name("noLogs")));
+ (MealzcoreKotlinArray<MealzcoreLogHandlerLogLevels *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreLogHandlerLogLevels *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Debouncer")))
@interface MealzcoreDebouncer : MealzcoreBase
- (instancetype)initWithDebouncePeriod:(int64_t)debouncePeriod coroutineScope:(id<MealzcoreKotlinx_coroutines_coreCoroutineScope>)coroutineScope __attribute__((swift_name("init(debouncePeriod:coroutineScope:)"))) __attribute__((objc_designated_initializer));
- (void (^)(void))debounceFunction:(id<MealzcoreKotlinSuspendFunction0>)function __attribute__((swift_name("debounce(function:)")));
- (void (^)(id _Nullable))debounceParamFunction:(void (^)(id _Nullable))function __attribute__((swift_name("debounceParam(function:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealzPage")))
@interface MealzcoreMealzPage : MealzcoreKotlinEnum<MealzcoreMealzPage *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreMealzPage *basket __attribute__((swift_name("basket")));
@property (class, readonly) MealzcoreMealzPage *basketPreview __attribute__((swift_name("basketPreview")));
@property (class, readonly) MealzcoreMealzPage *catalog __attribute__((swift_name("catalog")));
@property (class, readonly) MealzcoreMealzPage *categories __attribute__((swift_name("categories")));
@property (class, readonly) MealzcoreMealzPage *cooking __attribute__((swift_name("cooking")));
@property (class, readonly) MealzcoreMealzPage *favorites __attribute__((swift_name("favorites")));
@property (class, readonly) MealzcoreMealzPage *finalize __attribute__((swift_name("finalize")));
@property (class, readonly) MealzcoreMealzPage *itemSelector __attribute__((swift_name("itemSelector")));
@property (class, readonly) MealzcoreMealzPage *mealPlanner __attribute__((swift_name("mealPlanner")));
@property (class, readonly) MealzcoreMealzPage *myMeals __attribute__((swift_name("myMeals")));
@property (class, readonly) MealzcoreMealzPage *onboarding __attribute__((swift_name("onboarding")));
@property (class, readonly) MealzcoreMealzPage *orderHistory __attribute__((swift_name("orderHistory")));
@property (class, readonly) MealzcoreMealzPage *ordered __attribute__((swift_name("ordered")));
@property (class, readonly) MealzcoreMealzPage *shopping __attribute__((swift_name("shopping")));
@property (class, readonly) MealzcoreMealzPage *sponsor __attribute__((swift_name("sponsor")));
@property (class, readonly) MealzcoreMealzPage *storeLocator __attribute__((swift_name("storeLocator")));
@property (class, readonly) MealzcoreMealzPage *preferences __attribute__((swift_name("preferences")));
@property (class, readonly) MealzcoreMealzPage *products __attribute__((swift_name("products")));
@property (class, readonly) MealzcoreMealzPage *results __attribute__((swift_name("results")));
+ (MealzcoreKotlinArray<MealzcoreMealzPage *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreMealzPage *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealzTimer")))
@interface MealzcoreMealzTimer : MealzcoreBase
- (instancetype)initWithCoroutineScope:(id<MealzcoreKotlinx_coroutines_coreCoroutineScope>)coroutineScope __attribute__((swift_name("init(coroutineScope:)"))) __attribute__((objc_designated_initializer));
- (void)startIntervalMillis:(int64_t)intervalMillis action:(void (^)(void))action __attribute__((swift_name("start(intervalMillis:action:)")));
- (void)stop __attribute__((swift_name("stop()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MyBasketTab")))
@interface MealzcoreMyBasketTab : MealzcoreKotlinEnum<MealzcoreMyBasketTab *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreMyBasketTab *recipes __attribute__((swift_name("recipes")));
@property (class, readonly) MealzcoreMyBasketTab *products __attribute__((swift_name("products")));
+ (MealzcoreKotlinArray<MealzcoreMyBasketTab *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreMyBasketTab *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeDetailTab")))
@interface MealzcoreRecipeDetailTab : MealzcoreKotlinEnum<MealzcoreRecipeDetailTab *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreRecipeDetailTab *shopping __attribute__((swift_name("shopping")));
@property (class, readonly) MealzcoreRecipeDetailTab *cooking __attribute__((swift_name("cooking")));
+ (MealzcoreKotlinArray<MealzcoreRecipeDetailTab *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreRecipeDetailTab *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkRequirement")))
@interface MealzcoreSdkRequirement : MealzcoreBase
- (instancetype)initWithContext:(MealzcoreKMMContext *)context key:(NSString *)key __attribute__((swift_name("init(context:key:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreSdkRequirement *)doCopyContext:(MealzcoreKMMContext *)context key:(NSString *)key __attribute__((swift_name("doCopy(context:key:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreKMMContext *context __attribute__((swift_name("context")));
@property (readonly) NSString *key __attribute__((swift_name("key")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OptionalConfiguration")))
@interface MealzcoreOptionalConfiguration : MealzcoreBase
- (instancetype)initWithIsAnonymousModeEnabled:(BOOL)isAnonymousModeEnabled useDeviceLanguage:(BOOL)useDeviceLanguage __attribute__((swift_name("init(isAnonymousModeEnabled:useDeviceLanguage:)"))) __attribute__((objc_designated_initializer));
@property (readonly) BOOL isAnonymousModeEnabled __attribute__((swift_name("isAnonymousModeEnabled")));
@property (readonly) BOOL useDeviceLanguage __attribute__((swift_name("useDeviceLanguage")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OptionalConfigurationBuilder")))
@interface MealzcoreOptionalConfigurationBuilder : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL isAnonymousModeEnabled __attribute__((swift_name("isAnonymousModeEnabled")));
@property BOOL useDeviceLanguage __attribute__((swift_name("useDeviceLanguage")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkBuilder")))
@interface MealzcoreSdkBuilder : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SdkRequirementBuilder")))
@interface MealzcoreSdkRequirementBuilder : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property MealzcoreKMMContext * _Nullable context __attribute__((swift_name("context")));
@property NSString * _Nullable key __attribute__((swift_name("key")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SubscriptionConfigBuilder")))
@interface MealzcoreSubscriptionConfigBuilder : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18nResolver")))
@interface MealzcoreI18nResolver : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)i18nResolver __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreI18nResolver *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)localizeI18nResource:(id<MealzcoreI18nResource>)i18nResource __attribute__((swift_name("localize(i18nResource:)")));
- (void)registerAppBundleBundle:(NSBundle *)bundle __attribute__((swift_name("registerAppBundle(bundle:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Localisation")))
@interface MealzcoreLocalisation : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)localisation __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreLocalisation *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreBasketI18N *basket __attribute__((swift_name("basket")));
@property (readonly) MealzcoreBudgetI18N *budget __attribute__((swift_name("budget")));
@property (readonly) MealzcoreCatalogI18N *catalog __attribute__((swift_name("catalog")));
@property (readonly) MealzcoreCounterI18N *counter __attribute__((swift_name("counter")));
@property (readonly) MealzcoreDateFormatI18N *dateFormat __attribute__((swift_name("dateFormat")));
@property (readonly) MealzcoreErrorI18N *error __attribute__((swift_name("error")));
@property (readonly) MealzcoreFavoritesI18N *favorites __attribute__((swift_name("favorites")));
@property (readonly) MealzcoreFiltersI18N *filters __attribute__((swift_name("filters")));
@property (readonly) MealzcoreIngredientI18N *ingredient __attribute__((swift_name("ingredient")));
@property (readonly) MealzcoreItemSelectorI18N *itemSelector __attribute__((swift_name("itemSelector")));
@property (readonly) MealzcoreMyBasketI18N *myBasket __attribute__((swift_name("myBasket")));
@property (readonly) MealzcoreMyMealsI18N *myMeals __attribute__((swift_name("myMeals")));
@property (readonly) MealzcoreMyProductsI18N *myProducts __attribute__((swift_name("myProducts")));
@property (readonly) MealzcoreMyProductsProductI18N *myProductsProduct __attribute__((swift_name("myProductsProduct")));
@property (readonly) MealzcoreMySpaceI18N *mySpace __attribute__((swift_name("mySpace")));
@property (readonly) MealzcoreNavigationI18N *navigation __attribute__((swift_name("navigation")));
@property (readonly) MealzcoreOrderHistoryI18N *orderHistory __attribute__((swift_name("orderHistory")));
@property (readonly) MealzcorePreferencesI18N *preferences __attribute__((swift_name("preferences")));
@property (readonly) MealzcorePriceI18N *price __attribute__((swift_name("price")));
@property (readonly) MealzcoreRecipeI18N *recipe __attribute__((swift_name("recipe")));
@property (readonly) MealzcoreRecipeDetailsI18N *recipeDetails __attribute__((swift_name("recipeDetails")));
@property (readonly) MealzcoreRecipeDetailsProductI18N *recipeDetailsProduct __attribute__((swift_name("recipeDetailsProduct")));
@property (readonly) MealzcoreSearchI18N *search __attribute__((swift_name("search")));
@property (readonly) MealzcoreSponsorBannerI18N *sponsorBanner __attribute__((swift_name("sponsorBanner")));
@property (readonly) MealzcoreSponsorDetailI18N *sponsorDetail __attribute__((swift_name("sponsorDetail")));
@property (readonly) MealzcoreStoreLocatorButtonI18N *storeLocatorButton __attribute__((swift_name("storeLocatorButton")));
@property (readonly) MealzcoreTagI18N *tag __attribute__((swift_name("tag")));
@end

__attribute__((swift_name("I18nResource")))
@protocol MealzcoreI18nResource
@required
@property (readonly) NSString *accessibilityKey __attribute__((swift_name("accessibilityKey")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18n")))
@interface MealzcoreI18n : MealzcoreBase <MealzcoreI18nResource>
- (instancetype)initWithAccessibilityKey:(NSString *)accessibilityKey localised:(NSString *)localised __attribute__((swift_name("init(accessibilityKey:localised:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreI18nCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreI18n *)doCopyAccessibilityKey:(NSString *)accessibilityKey localised:(NSString *)localised __attribute__((swift_name("doCopy(accessibilityKey:localised:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *accessibilityKey __attribute__((swift_name("accessibilityKey")));
@property (readonly) NSString *localised __attribute__((swift_name("localised")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18n.Companion")))
@interface MealzcoreI18nCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreI18nCompanion *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)empty __attribute__((swift_name("empty()")));
- (MealzcoreI18n *)pluralAccessibilityKey:(NSString *)accessibilityKey res:(MealzcoreResourcesPluralsResource * _Nullable)res quantity:(int32_t)quantity args:(MealzcoreKotlinArray<id> *)args __attribute__((swift_name("plural(accessibilityKey:res:quantity:args:)")));
- (MealzcoreI18n *)stringAccessibilityKey:(NSString *)accessibilityKey res:(MealzcoreResourcesStringResource * _Nullable)res args:(MealzcoreKotlinArray<id> *)args __attribute__((swift_name("string(accessibilityKey:res:args:)")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface MealzcoreKotlinThrowable : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (MealzcoreKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NoResourceThrowable")))
@interface MealzcoreNoResourceThrowable : MealzcoreKotlinThrowable
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)noResourceThrowable __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreNoResourceThrowable *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketI18N")))
@interface MealzcoreBasketI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)basketI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)articlesNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("articles(numberOfProducts:)")));
- (MealzcoreI18n *)basketTranserToRetailerName:(NSString *)retailerName __attribute__((swift_name("basketTranserTo(retailerName:)")));
- (MealzcoreI18n *)basketTranserToQuestionRetailerName:(NSString *)retailerName __attribute__((swift_name("basketTranserToQuestion(retailerName:)")));
- (MealzcoreI18n *)forRecipeNumberOfRecipe:(int32_t)numberOfRecipe __attribute__((swift_name("forRecipe(numberOfRecipe:)")));
- (MealzcoreI18n *)inRecipeNumberOfRecipe:(int32_t)numberOfRecipe __attribute__((swift_name("inRecipe(numberOfRecipe:)")));
- (MealzcoreI18n *)ownedProductsNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("ownedProducts(numberOfProducts:)")));
- (MealzcoreI18n *)removedProductsNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("removedProducts(numberOfProducts:)")));
- (MealzcoreI18n *)unavailableProductsNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("unavailableProducts(numberOfProducts:)")));
@property (readonly) MealzcoreI18n *addProduct __attribute__((swift_name("addProduct")));
@property (readonly) MealzcoreI18n *basketTranser __attribute__((swift_name("basketTranser")));
@property (readonly) MealzcoreI18n *basketTranserAbort __attribute__((swift_name("basketTranserAbort")));
@property (readonly) MealzcoreI18n *basketTranserClose __attribute__((swift_name("basketTranserClose")));
@property (readonly) MealzcoreI18n *basketTranserContinue __attribute__((swift_name("basketTranserContinue")));
@property (readonly) MealzcoreI18n *continueShopping __attribute__((swift_name("continueShopping")));
@property (readonly) MealzcoreI18n *moreDetails __attribute__((swift_name("moreDetails")));
@property (readonly) MealzcoreI18n *person __attribute__((swift_name("person")));
@property (readonly) MealzcoreI18n *recipeAdded __attribute__((swift_name("recipeAdded")));
@property (readonly) MealzcoreI18n *removeRecipe __attribute__((swift_name("removeRecipe")));
@property (readonly) MealzcoreI18n *swapProduct __attribute__((swift_name("swapProduct")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BudgetI18N")))
@interface MealzcoreBudgetI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)budgetI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBudgetI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)mealPlannerMealsForNumberOfMeals:(int32_t)numberOfMeals __attribute__((swift_name("mealPlannerMealsFor(numberOfMeals:)")));
@property (readonly) MealzcoreI18n *addMealIdea __attribute__((swift_name("addMealIdea")));
@property (readonly) MealzcoreI18n *mealPlannerDiscover __attribute__((swift_name("mealPlannerDiscover")));
@property (readonly) MealzcoreI18n *mealPlannerFinalize __attribute__((swift_name("mealPlannerFinalize")));
@property (readonly) MealzcoreI18n *mealPlannerProductAdded __attribute__((swift_name("mealPlannerProductAdded")));
@property (readonly) MealzcoreI18n *mealPlannerPromotion __attribute__((swift_name("mealPlannerPromotion")));
@property (readonly) MealzcoreI18n *mealPlannerSearchFailed __attribute__((swift_name("mealPlannerSearchFailed")));
@property (readonly) MealzcoreI18n *myBudget __attribute__((swift_name("myBudget")));
@property (readonly) MealzcoreI18n *myBudgetChangeRecipe __attribute__((swift_name("myBudgetChangeRecipe")));
@property (readonly) MealzcoreI18n *myBudgetSubtext __attribute__((swift_name("myBudgetSubtext")));
@property (readonly) MealzcoreI18n *noResultsForBudget __attribute__((swift_name("noResultsForBudget")));
@property (readonly) MealzcoreI18n *numberOfGuestsTitle __attribute__((swift_name("numberOfGuestsTitle")));
@property (readonly) MealzcoreI18n *numberOfMealsTitle __attribute__((swift_name("numberOfMealsTitle")));
@property (readonly) MealzcoreI18n *planMealsTitle __attribute__((swift_name("planMealsTitle")));
@property (readonly) MealzcoreI18n *recipeCollectionTitle __attribute__((swift_name("recipeCollectionTitle")));
@property (readonly) MealzcoreI18n *searchForRecipe __attribute__((swift_name("searchForRecipe")));
@property (readonly) MealzcoreI18n *title __attribute__((swift_name("title")));
@property (readonly) MealzcoreI18n *totalBudgetTitle __attribute__((swift_name("totalBudgetTitle")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CatalogI18N")))
@interface MealzcoreCatalogI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)catalogI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreCatalogI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)showResultsNumberOfResults:(int32_t)numberOfResults __attribute__((swift_name("showResults(numberOfResults:)")));
@property (readonly) MealzcoreI18n *browseRecipes __attribute__((swift_name("browseRecipes")));
@property (readonly) MealzcoreI18n *costPerPerson __attribute__((swift_name("costPerPerson")));
@property (readonly) MealzcoreI18n *difficulty __attribute__((swift_name("difficulty")));
@property (readonly) MealzcoreI18n *discountTitle __attribute__((swift_name("discountTitle")));
@property (readonly) MealzcoreI18n *discoverDiscount __attribute__((swift_name("discoverDiscount")));
@property (readonly) MealzcoreI18n *favoriteTitle __attribute__((swift_name("favoriteTitle")));
@property (readonly) MealzcoreI18n *filtersTitle __attribute__((swift_name("filtersTitle")));
@property (readonly) MealzcoreI18n *loadingText __attribute__((swift_name("loadingText")));
@property (readonly, getter=doNew) MealzcoreI18n *new_ __attribute__((swift_name("new_")));
@property (readonly) MealzcoreI18n *noRecipeFound __attribute__((swift_name("noRecipeFound")));
@property (readonly) MealzcoreI18n *noRecipeFoundCategory __attribute__((swift_name("noRecipeFoundCategory")));
@property (readonly) MealzcoreI18n *noRecipeFoundFilter __attribute__((swift_name("noRecipeFoundFilter")));
@property (readonly) MealzcoreI18n *preferencesNoResult __attribute__((swift_name("preferencesNoResult")));
@property (readonly) MealzcoreI18n *preferencesTitle __attribute__((swift_name("preferencesTitle")));
@property (readonly) MealzcoreI18n *preferencesTryAnother __attribute__((swift_name("preferencesTryAnother")));
@property (readonly) MealzcoreI18n *preparationTime __attribute__((swift_name("preparationTime")));
@property (readonly) MealzcoreI18n *removeFilters __attribute__((swift_name("removeFilters")));
@property (readonly) MealzcoreI18n *resultsTitle __attribute__((swift_name("resultsTitle")));
@property (readonly) MealzcoreI18n *searchPlaceholder __attribute__((swift_name("searchPlaceholder")));
@property (readonly) MealzcoreI18n *searchPrefix __attribute__((swift_name("searchPrefix")));
@property (readonly) MealzcoreI18n *searchTitle __attribute__((swift_name("searchTitle")));
@property (readonly) MealzcoreI18n *showAll __attribute__((swift_name("showAll")));
@property (readonly) MealzcoreI18n *title __attribute__((swift_name("title")));
@property (readonly) MealzcoreI18n *tryAnotherSearch __attribute__((swift_name("tryAnotherSearch")));
@property (readonly) MealzcoreI18n *tryWithOtherFilter __attribute__((swift_name("tryWithOtherFilter")));
@property (readonly) MealzcoreI18n *tryWithOtherFilterOrPreferences __attribute__((swift_name("tryWithOtherFilterOrPreferences")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CounterI18N")))
@interface MealzcoreCounterI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)counterI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreCounterI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *persons __attribute__((swift_name("persons")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DateFormatI18N")))
@interface MealzcoreDateFormatI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)dateFormatI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreDateFormatI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *dateFormat __attribute__((swift_name("dateFormat")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorI18N")))
@interface MealzcoreErrorI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)errorI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreErrorI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *generic __attribute__((swift_name("generic")));
@property (readonly) MealzcoreI18n *retry __attribute__((swift_name("retry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FavoritesI18N")))
@interface MealzcoreFavoritesI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)favoritesI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreFavoritesI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *goToCatalog __attribute__((swift_name("goToCatalog")));
@property (readonly) MealzcoreI18n *noFavorites __attribute__((swift_name("noFavorites")));
@property (readonly) MealzcoreI18n *searchBarText __attribute__((swift_name("searchBarText")));
@property (readonly) MealzcoreI18n *searchNoResults __attribute__((swift_name("searchNoResults")));
@property (readonly) MealzcoreI18n *searchTryAgain __attribute__((swift_name("searchTryAgain")));
@property (readonly) MealzcoreI18n *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FiltersI18N")))
@interface MealzcoreFiltersI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)filtersI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreFiltersI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *apply __attribute__((swift_name("apply")));
@property (readonly) MealzcoreI18n *betweenFiveAndTenEuros __attribute__((swift_name("betweenFiveAndTenEuros")));
@property (readonly) MealzcoreI18n *lessThanAnHour __attribute__((swift_name("lessThanAnHour")));
@property (readonly) MealzcoreI18n *lessThanFifteenMinutes __attribute__((swift_name("lessThanFifteenMinutes")));
@property (readonly) MealzcoreI18n *lessThanFiveEuros __attribute__((swift_name("lessThanFiveEuros")));
@property (readonly) MealzcoreI18n *lessThanThirteenMinutes __attribute__((swift_name("lessThanThirteenMinutes")));
@property (readonly) MealzcoreI18n *lessThanTwoHours __attribute__((swift_name("lessThanTwoHours")));
@property (readonly) MealzcoreI18n *moreThanTenEuros __attribute__((swift_name("moreThanTenEuros")));
@property (readonly) MealzcoreI18n *pageTitle __attribute__((swift_name("pageTitle")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IngredientI18N")))
@interface MealzcoreIngredientI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)ingredientI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreIngredientI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)addProductNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("addProduct(numberOfProducts:)")));
- (MealzcoreI18n *)productAddedNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("productAdded(numberOfProducts:)")));
@property (readonly) MealzcoreI18n *addAProduct __attribute__((swift_name("addAProduct")));
@property (readonly) MealzcoreI18n *chooseProduct __attribute__((swift_name("chooseProduct")));
@property (readonly) MealzcoreI18n *immediateDiscount __attribute__((swift_name("immediateDiscount")));
@property (readonly) MealzcoreI18n *notAvailable __attribute__((swift_name("notAvailable")));
@property (readonly) MealzcoreI18n *willNotBeAdded __attribute__((swift_name("willNotBeAdded")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorI18N")))
@interface MealzcoreItemSelectorI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)itemSelectorI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemSelectorI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *add __attribute__((swift_name("add")));
@property (readonly) MealzcoreI18n *emptyCta __attribute__((swift_name("emptyCta")));
@property (readonly) MealzcoreI18n *emptyTitle __attribute__((swift_name("emptyTitle")));
@property (readonly) MealzcoreI18n *headerTitle __attribute__((swift_name("headerTitle")));
@property (readonly) MealzcoreI18n *headerTitleAddProduct __attribute__((swift_name("headerTitleAddProduct")));
@property (readonly) MealzcoreI18n *inBasket __attribute__((swift_name("inBasket")));
@property (readonly) MealzcoreI18n *noSubstitution __attribute__((swift_name("noSubstitution")));
@property (readonly) MealzcoreI18n *notFoundSubtitle __attribute__((swift_name("notFoundSubtitle")));
@property (readonly) MealzcoreI18n *notFoundTitle __attribute__((swift_name("notFoundTitle")));
@property (readonly) MealzcoreI18n *replace __attribute__((swift_name("replace")));
@property (readonly) MealzcoreI18n *search __attribute__((swift_name("search")));
@property (readonly) MealzcoreI18n *searchProductToAdd __attribute__((swift_name("searchProductToAdd")));
@property (readonly) MealzcoreI18n *select __attribute__((swift_name("select")));
@property (readonly) MealzcoreI18n *selected __attribute__((swift_name("selected")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MyBasketI18N")))
@interface MealzcoreMyBasketI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)myBasketI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMyBasketI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)mealsInBasketNumberOfMeals:(int32_t)numberOfMeals __attribute__((swift_name("mealsInBasket(numberOfMeals:)")));
- (MealzcoreI18n *)productsInBasketNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("productsInBasket(numberOfProducts:)")));
@property (readonly) MealzcoreI18n *addAProduct __attribute__((swift_name("addAProduct")));
@property (readonly) MealzcoreI18n *addARecipe __attribute__((swift_name("addARecipe")));
@property (readonly) MealzcoreI18n *inMyBasket __attribute__((swift_name("inMyBasket")));
@property (readonly) MealzcoreI18n *needSomethingElse __attribute__((swift_name("needSomethingElse")));
@property (readonly) MealzcoreI18n *order __attribute__((swift_name("order")));
@property (readonly) MealzcoreI18n *products __attribute__((swift_name("products")));
@property (readonly) MealzcoreI18n *recipes __attribute__((swift_name("recipes")));
@property (readonly) MealzcoreI18n *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MyMealsI18N")))
@interface MealzcoreMyMealsI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)myMealsI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMyMealsI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)mealsAddedNumberOfMeals:(int32_t)numberOfMeals __attribute__((swift_name("mealsAdded(numberOfMeals:)")));
- (MealzcoreI18n *)mealsInBasketNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("mealsInBasket(numberOfProducts:)")));
- (MealzcoreI18n *)perPersonPrice:(NSString *)price __attribute__((swift_name("perPerson(price:)")));
- (MealzcoreI18n *)perPersonWithEuroPrice:(NSString *)price __attribute__((swift_name("perPersonWithEuro(price:)")));
- (MealzcoreI18n *)productsNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("products(numberOfProducts:)")));
- (MealzcoreI18n *)productsUnavailableNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("productsUnavailable(numberOfProducts:)")));
@property (readonly) MealzcoreI18n *goToBasket __attribute__((swift_name("goToBasket")));
@property (readonly) MealzcoreI18n *goToCatalog __attribute__((swift_name("goToCatalog")));
@property (readonly) MealzcoreI18n *noMealIdeaInBasket __attribute__((swift_name("noMealIdeaInBasket")));
@property (readonly) MealzcoreI18n *perPerson __attribute__((swift_name("perPerson")));
@property (readonly) MealzcoreI18n *products __attribute__((swift_name("products")));
@property (readonly) MealzcoreI18n *seeProducts __attribute__((swift_name("seeProducts")));
@property (readonly) MealzcoreI18n *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MyProductsI18N")))
@interface MealzcoreMyProductsI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)myProductsI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMyProductsI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *noProductCTA __attribute__((swift_name("noProductCTA")));
@property (readonly) MealzcoreI18n *noProductsInBasket __attribute__((swift_name("noProductsInBasket")));
@property (readonly) MealzcoreI18n *replace __attribute__((swift_name("replace")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MyProductsProductI18N")))
@interface MealzcoreMyProductsProductI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)myProductsProductI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMyProductsProductI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)productsSharedRecipeNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("productsSharedRecipe(numberOfProducts:)")));
- (MealzcoreI18n *)useInRecipeNumberOfRecipes:(int32_t)numberOfRecipes __attribute__((swift_name("useInRecipe(numberOfRecipes:)")));
@property (readonly) MealzcoreI18n *recipesForProduct __attribute__((swift_name("recipesForProduct")));
@property (readonly) MealzcoreI18n *replace __attribute__((swift_name("replace")));
@property (readonly) MealzcoreI18n *sponsored __attribute__((swift_name("sponsored")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MySpaceI18N")))
@interface MealzcoreMySpaceI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mySpaceI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMySpaceI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *favoritesTab __attribute__((swift_name("favoritesTab")));
@property (readonly) MealzcoreI18n *historyTab __attribute__((swift_name("historyTab")));
@property (readonly) MealzcoreI18n *personalRecipesTab __attribute__((swift_name("personalRecipesTab")));
@property (readonly) MealzcoreI18n *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NavigationI18N")))
@interface MealzcoreNavigationI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)navigationI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreNavigationI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *back __attribute__((swift_name("back")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OrderHistoryI18N")))
@interface MealzcoreOrderHistoryI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)orderHistoryI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreOrderHistoryI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)orderedOnDate:(NSString *)date __attribute__((swift_name("orderedOn(date:)")));
@property (readonly) MealzcoreI18n *alreadyInBasket __attribute__((swift_name("alreadyInBasket")));
@property (readonly) MealzcoreI18n *detailsTitle __attribute__((swift_name("detailsTitle")));
@property (readonly) MealzcoreI18n *exploreOurCatalog __attribute__((swift_name("exploreOurCatalog")));
@property (readonly) MealzcoreI18n *noMeals __attribute__((swift_name("noMeals")));
@property (readonly) MealzcoreI18n *noOrders __attribute__((swift_name("noOrders")));
@property (readonly) MealzcoreI18n *orderAgain __attribute__((swift_name("orderAgain")));
@property (readonly) MealzcoreI18n *orderSelection __attribute__((swift_name("orderSelection")));
@property (readonly) MealzcoreI18n *searchBarText __attribute__((swift_name("searchBarText")));
@property (readonly) MealzcoreI18n *seePreviousOrder __attribute__((swift_name("seePreviousOrder")));
@property (readonly) MealzcoreI18n *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PreferencesI18N")))
@interface MealzcorePreferencesI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)preferencesI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePreferencesI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *addTag __attribute__((swift_name("addTag")));
@property (readonly) MealzcoreI18n *apply __attribute__((swift_name("apply")));
@property (readonly) MealzcoreI18n *cancel __attribute__((swift_name("cancel")));
@property (readonly) MealzcoreI18n *cookingEquipmentSubtitle __attribute__((swift_name("cookingEquipmentSubtitle")));
@property (readonly) MealzcoreI18n *cookingEquipmentTitle __attribute__((swift_name("cookingEquipmentTitle")));
@property (readonly) MealzcoreI18n *dietSubtitle __attribute__((swift_name("dietSubtitle")));
@property (readonly) MealzcoreI18n *dietTitle __attribute__((swift_name("dietTitle")));
@property (readonly) MealzcoreI18n *emptyTitle __attribute__((swift_name("emptyTitle")));
@property (readonly) MealzcoreI18n *numberOfGuests __attribute__((swift_name("numberOfGuests")));
@property (readonly) MealzcoreI18n *reset __attribute__((swift_name("reset")));
@property (readonly) MealzcoreI18n *searchPlaceholder __attribute__((swift_name("searchPlaceholder")));
@property (readonly) MealzcoreI18n *searchTitle __attribute__((swift_name("searchTitle")));
@property (readonly) MealzcoreI18n *tastesSubtitle __attribute__((swift_name("tastesSubtitle")));
@property (readonly) MealzcoreI18n *tastesTitle __attribute__((swift_name("tastesTitle")));
@property (readonly) MealzcoreI18n *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PriceI18N")))
@interface MealzcorePriceI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)priceI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePriceI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)mealCostCost:(NSString *)cost __attribute__((swift_name("mealCost(cost:)")));
@property (readonly) MealzcoreI18n *currency __attribute__((swift_name("currency")));
@property (readonly) MealzcoreI18n *perGuest __attribute__((swift_name("perGuest")));
@property (readonly) MealzcoreI18n *seePrice __attribute__((swift_name("seePrice")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeDetailsI18N")))
@interface MealzcoreRecipeDetailsI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeDetailsI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeDetailsI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)orderedOnDate:(NSString *)date __attribute__((swift_name("orderedOn(date:)")));
- (MealzcoreI18n *)productsUnavailableNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("productsUnavailable(numberOfProducts:)")));
- (MealzcoreI18n *)stepsNumberOfSteps:(int32_t)numberOfSteps __attribute__((swift_name("steps(numberOfSteps:)")));
@property (readonly) MealzcoreI18n *addAllProducts __attribute__((swift_name("addAllProducts")));
@property (readonly) MealzcoreI18n *continueShopping __attribute__((swift_name("continueShopping")));
@property (readonly) MealzcoreI18n *cooking __attribute__((swift_name("cooking")));
@property (readonly) MealzcoreI18n *goToCatalog __attribute__((swift_name("goToCatalog")));
@property (readonly) MealzcoreI18n *inMyBasket __attribute__((swift_name("inMyBasket")));
@property (readonly) MealzcoreI18n *legal __attribute__((swift_name("legal")));
@property (readonly) MealzcoreI18n *oftenDeleted __attribute__((swift_name("oftenDeleted")));
@property (readonly) MealzcoreI18n *prevention __attribute__((swift_name("prevention")));
@property (readonly) MealzcoreI18n *seeMore __attribute__((swift_name("seeMore")));
@property (readonly) MealzcoreI18n *shopping __attribute__((swift_name("shopping")));
@property (readonly) MealzcoreI18n *title __attribute__((swift_name("title")));
@property (readonly) MealzcoreI18n *unavailable __attribute__((swift_name("unavailable")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeDetailsProductI18N")))
@interface MealzcoreRecipeDetailsProductI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeDetailsProductI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeDetailsProductI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)productsSharedRecipeNumberOfProducts:(int32_t)numberOfProducts __attribute__((swift_name("productsSharedRecipe(numberOfProducts:)")));
@property (readonly) MealzcoreI18n *ignoreProduct __attribute__((swift_name("ignoreProduct")));
@property (readonly) MealzcoreI18n *replaceItem __attribute__((swift_name("replaceItem")));
@property (readonly) MealzcoreI18n *sponsored __attribute__((swift_name("sponsored")));
@property (readonly) MealzcoreI18n *unavailable __attribute__((swift_name("unavailable")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeI18N")))
@interface MealzcoreRecipeI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeI18N *shared __attribute__((swift_name("shared")));
- (MealzcoreI18n *)numberOfIngredientsNumberOfIngredients:(int32_t)numberOfIngredients __attribute__((swift_name("numberOfIngredients(numberOfIngredients:)")));
@property (readonly) MealzcoreI18n *add __attribute__((swift_name("add")));
@property (readonly) MealzcoreI18n *addProducts __attribute__((swift_name("addProducts")));
@property (readonly) MealzcoreI18n *added __attribute__((swift_name("added")));
@property (readonly) MealzcoreI18n *cookTime __attribute__((swift_name("cookTime")));
@property (readonly) MealzcoreI18n *discount __attribute__((swift_name("discount")));
@property (readonly) MealzcoreI18n *flag __attribute__((swift_name("flag")));
@property (readonly) MealzcoreI18n *flagDrink __attribute__((swift_name("flagDrink")));
@property (readonly) MealzcoreI18n *highDifficulty __attribute__((swift_name("highDifficulty")));
@property (readonly) MealzcoreI18n *lowDifficulty __attribute__((swift_name("lowDifficulty")));
@property (readonly) MealzcoreI18n *mediumDifficulty __attribute__((swift_name("mediumDifficulty")));
@property (readonly) MealzcoreI18n *orderAgainButton __attribute__((swift_name("orderAgainButton")));
@property (readonly) MealzcoreI18n *orderSubtitle __attribute__((swift_name("orderSubtitle")));
@property (readonly) MealzcoreI18n *orderTitle __attribute__((swift_name("orderTitle")));
@property (readonly) MealzcoreI18n *perPerson __attribute__((swift_name("perPerson")));
@property (readonly) MealzcoreI18n *preparationTime __attribute__((swift_name("preparationTime")));
@property (readonly) MealzcoreI18n *reOrderAlreadyInBasket __attribute__((swift_name("reOrderAlreadyInBasket")));
@property (readonly) MealzcoreI18n *restingTime __attribute__((swift_name("restingTime")));
@property (readonly) MealzcoreI18n *showBasketPreview __attribute__((swift_name("showBasketPreview")));
@property (readonly) MealzcoreI18n *showDetails __attribute__((swift_name("showDetails")));
@property (readonly) MealzcoreI18n *steps __attribute__((swift_name("steps")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SearchI18N")))
@interface MealzcoreSearchI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)searchI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSearchI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *resultsTitle __attribute__((swift_name("resultsTitle")));
@property (readonly) MealzcoreI18n *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBannerI18N")))
@interface MealzcoreSponsorBannerI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sponsorBannerI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBannerI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *sponsorBannerMoreInfo __attribute__((swift_name("sponsorBannerMoreInfo")));
@property (readonly) MealzcoreI18n *sponsorBannerSpeach __attribute__((swift_name("sponsorBannerSpeach")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorDetailI18N")))
@interface MealzcoreSponsorDetailI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sponsorDetailI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorDetailI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *emptyCta __attribute__((swift_name("emptyCta")));
@property (readonly) MealzcoreI18n *emptySubtitle __attribute__((swift_name("emptySubtitle")));
@property (readonly) MealzcoreI18n *emptyTitle __attribute__((swift_name("emptyTitle")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoreLocatorButtonI18N")))
@interface MealzcoreStoreLocatorButtonI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)storeLocatorButtonI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreStoreLocatorButtonI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *cta __attribute__((swift_name("cta")));
@property (readonly) MealzcoreI18n *defaultText __attribute__((swift_name("defaultText")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TagI18N")))
@interface MealzcoreTagI18N : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)tagI18N __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreTagI18N *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreI18n *postRecipeCount __attribute__((swift_name("postRecipeCount")));
@property (readonly) MealzcoreI18n *preRecipeCount __attribute__((swift_name("preRecipeCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AlterQuantityBasketEntry")))
@interface MealzcoreAlterQuantityBasketEntry : MealzcoreBase
- (instancetype)initWithId:(NSString *)id deltaQty:(int32_t)deltaQty currentQty:(int32_t)currentQty __attribute__((swift_name("init(id:deltaQty:currentQty:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreAlterQuantityBasketEntry *)doCopyId:(NSString *)id deltaQty:(int32_t)deltaQty currentQty:(int32_t)currentQty __attribute__((swift_name("doCopy(id:deltaQty:currentQty:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t currentQty __attribute__((swift_name("currentQty")));
@property (readonly) int32_t deltaQty __attribute__((swift_name("deltaQty")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((swift_name("Attributes")))
@interface MealzcoreAttributes : MealzcoreBase
@property (class, readonly, getter=companion) MealzcoreAttributesCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Attributes.Companion")))
@interface MealzcoreAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MealzcoreKotlinArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end

__attribute__((swift_name("AttributesField")))
@interface MealzcoreAttributesField : MealzcoreBase
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer));
- (NSString *)fieldsIncluded:(NSArray<NSString *> *)included __attribute__((swift_name("fields(included:)")));
@property (readonly) NSArray<NSString *> *defaultIncluded __attribute__((swift_name("defaultIncluded")));
@property (readonly) NSString *fieldParameterName __attribute__((swift_name("fieldParameterName")));
@property (readonly) NSString *includedRelationships __attribute__((swift_name("includedRelationships")));
@property (readonly) id<MealzcoreKotlinKClass> t __attribute__((swift_name("t")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthLessUser")))
@interface MealzcoreAuthLessUser : MealzcoreBase
- (instancetype)initWithAuthLessId:(NSString *)authLessId __attribute__((swift_name("init(authLessId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreAuthLessUserCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreAuthLessUser *)doCopyAuthLessId:(NSString *)authLessId __attribute__((swift_name("doCopy(authLessId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *authLessId __attribute__((swift_name("authLessId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthLessUser.Companion")))
@interface MealzcoreAuthLessUserCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreAuthLessUserCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Authorization")))
@interface MealzcoreAuthorization : MealzcoreKotlinEnum<MealzcoreAuthorization *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreAuthorization *bearer __attribute__((swift_name("bearer")));
@property (class, readonly) MealzcoreAuthorization *userId __attribute__((swift_name("userId")));
+ (MealzcoreKotlinArray<MealzcoreAuthorization *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreAuthorization *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((swift_name("Record")))
@interface MealzcoreRecord : MealzcoreBase
@property (class, readonly, getter=companion) MealzcoreRecordCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreKotlinx_serialization_jsonJsonElement *)toJsonElement __attribute__((swift_name("toJsonElement()")));
@property (readonly) MealzcoreAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@property (readonly) MealzcoreRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Basket")))
@interface MealzcoreBasket : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreBasketCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreBasket *)doCopyId:(NSString *)id attributes:(MealzcoreBasketAttributes * _Nullable)attributes relationships:(MealzcoreBasketRelationships * _Nullable)relationships recipes:(NSArray<MealzcoreRecipe *> *)recipes __attribute__((swift_name("doCopy(id:attributes:relationships:recipes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (int32_t)guestsForRecipeRecipeId:(NSString *)recipeId __attribute__((swift_name("guestsForRecipe(recipeId:)")));
- (BOOL)hasRecipeRecipeId:(NSString *)recipeId __attribute__((swift_name("hasRecipe(recipeId:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSArray<NSString *> *)missingRecipesIdsExistingRecipes:(NSArray<MealzcoreRecipe *> *)existingRecipes __attribute__((swift_name("missingRecipesIds(existingRecipes:)")));
- (void)rebuildRecipesRelationshipsMissingRecipes:(NSArray<MealzcoreRecipe *> *)missingRecipes existingRecipes:(NSArray<MealzcoreRecipe *> *)existingRecipes __attribute__((swift_name("rebuildRecipesRelationships(missingRecipes:existingRecipes:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (MealzcoreBasket *)updateBasketEntryNewBe:(MealzcoreBasketEntry *)newBe __attribute__((swift_name("updateBasketEntry(newBe:)")));
@property MealzcoreBasketAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSArray<MealzcoreBasketEntry *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property NSArray<MealzcoreRecipe *> *recipes __attribute__((swift_name("recipes")));
@property (readonly) MealzcoreBasketRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Basket.Companion")))
@interface MealzcoreBasketCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@property (readonly) NSArray<NSString *> *defaultIncluded __attribute__((swift_name("defaultIncluded")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketAttributes")))
@interface MealzcoreBasketAttributes : MealzcoreAttributes
- (instancetype)initWithStatus:(MealzcoreBasketStatus *)status recipesInfos:(NSMutableArray<MealzcoreRecipeInfos *> *)recipesInfos updatedAt:(NSString *)updatedAt totalPrice:(float)totalPrice token:(NSString * _Nullable)token priceBookKey:(NSString * _Nullable)priceBookKey affiliated:(NSString * _Nullable)affiliated __attribute__((swift_name("init(status:recipesInfos:updatedAt:totalPrice:token:priceBookKey:affiliated:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreBasketAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreBasketAttributes *)doCopyStatus:(MealzcoreBasketStatus *)status recipesInfos:(NSMutableArray<MealzcoreRecipeInfos *> *)recipesInfos updatedAt:(NSString *)updatedAt totalPrice:(float)totalPrice token:(NSString * _Nullable)token priceBookKey:(NSString * _Nullable)priceBookKey affiliated:(NSString * _Nullable)affiliated __attribute__((swift_name("doCopy(status:recipesInfos:updatedAt:totalPrice:token:priceBookKey:affiliated:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable affiliated __attribute__((swift_name("affiliated")));
@property (readonly) NSString * _Nullable priceBookKey __attribute__((swift_name("priceBookKey")));
@property (readonly) NSMutableArray<MealzcoreRecipeInfos *> *recipesInfos __attribute__((swift_name("recipesInfos")));
@property (readonly) MealzcoreBasketStatus *status __attribute__((swift_name("status")));
@property (readonly) NSString * _Nullable token __attribute__((swift_name("token")));
@property (readonly) float totalPrice __attribute__((swift_name("totalPrice"))) __attribute__((deprecated("totalPrice has been replaced with totalPrice stored in the BasketRepository")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/utils/CustomDateSerializer))
*/
@property (readonly) NSString *updatedAt __attribute__((swift_name("updatedAt")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketAttributes.Companion")))
@interface MealzcoreBasketAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntriesItem")))
@interface MealzcoreBasketEntriesItem : MealzcoreBase
- (instancetype)initWithId:(MealzcoreInt * _Nullable)id itemId:(MealzcoreInt * _Nullable)itemId score:(MealzcoreFloat * _Nullable)score learningFactor:(MealzcoreInt * _Nullable)learningFactor timesSelected:(MealzcoreInt * _Nullable)timesSelected selected:(BOOL)selected default:(BOOL)default_ unitPrice:(MealzcoreDouble * _Nullable)unitPrice currency:(NSString * _Nullable)currency pftPlages:(NSArray<MealzcoreDouble *> * _Nullable)pftPlages pftChecksum:(NSString * _Nullable)pftChecksum __attribute__((swift_name("init(id:itemId:score:learningFactor:timesSelected:selected:default:unitPrice:currency:pftPlages:pftChecksum:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreBasketEntriesItemCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreBasketEntriesItem *)doCopyId:(MealzcoreInt * _Nullable)id itemId:(MealzcoreInt * _Nullable)itemId score:(MealzcoreFloat * _Nullable)score learningFactor:(MealzcoreInt * _Nullable)learningFactor timesSelected:(MealzcoreInt * _Nullable)timesSelected selected:(BOOL)selected default:(BOOL)default_ unitPrice:(MealzcoreDouble * _Nullable)unitPrice currency:(NSString * _Nullable)currency pftPlages:(NSArray<MealzcoreDouble *> * _Nullable)pftPlages pftChecksum:(NSString * _Nullable)pftChecksum __attribute__((swift_name("doCopy(id:itemId:score:learningFactor:timesSelected:selected:default:unitPrice:currency:pftPlages:pftChecksum:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable currency __attribute__((swift_name("currency")));
@property (readonly, getter=default) BOOL default_ __attribute__((swift_name("default_")));
@property (readonly) MealzcoreInt * _Nullable id __attribute__((swift_name("id")));
@property (readonly) MealzcoreInt * _Nullable itemId __attribute__((swift_name("itemId")));
@property (readonly) MealzcoreInt * _Nullable learningFactor __attribute__((swift_name("learningFactor")));
@property (readonly) NSString * _Nullable pftChecksum __attribute__((swift_name("pftChecksum")));
@property (readonly) NSArray<MealzcoreDouble *> * _Nullable pftPlages __attribute__((swift_name("pftPlages")));
@property (readonly) MealzcoreFloat * _Nullable score __attribute__((swift_name("score")));
@property (readonly) BOOL selected __attribute__((swift_name("selected")));
@property (readonly) MealzcoreInt * _Nullable timesSelected __attribute__((swift_name("timesSelected")));
@property (readonly) MealzcoreDouble * _Nullable unitPrice __attribute__((swift_name("unitPrice")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntriesItem.Companion")))
@interface MealzcoreBasketEntriesItemCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntriesItemCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntry")))
@interface MealzcoreBasketEntry : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreBasketEntryCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreBasketEntry *)doCopyId:(NSString *)id attributes:(MealzcoreBasketEntryAttributes * _Nullable)attributes relationships:(MealzcoreBasketEntryRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isForRecipeRecipeId:(NSString *)recipeId __attribute__((swift_name("isForRecipe(recipeId:)")));
- (MealzcoreSupplierProduct *)toRetailerProductOverwriteQuantity:(MealzcoreInt * _Nullable)overwriteQuantity __attribute__((swift_name("toRetailerProduct(overwriteQuantity:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (MealzcoreBasketEntry *)updateQuantityQty:(int32_t)qty __attribute__((swift_name("updateQuantity(qty:)")));
- (MealzcoreBasketEntry *)updateStatusStatus:(NSString *)status __attribute__((swift_name("updateStatus(status:)")));
@property (readonly) double absolutePrice __attribute__((swift_name("absolutePrice")));
@property (readonly) MealzcoreBasketEntryAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL canBeAdded __attribute__((swift_name("canBeAdded")));
@property (readonly) NSString *extId __attribute__((swift_name("extId")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *image __attribute__((swift_name("image")));
@property (readonly) BOOL isDeleted __attribute__((swift_name("isDeleted")));
@property (readonly) BOOL isIgnored __attribute__((swift_name("isIgnored")));
@property (readonly) BOOL isInCustomerBasket __attribute__((swift_name("isInCustomerBasket")));
@property (readonly) BOOL isInitial __attribute__((swift_name("isInitial")));
@property (readonly) BOOL isOftenDeleted __attribute__((swift_name("isOftenDeleted")));
@property (readonly) BOOL isOutOfStock __attribute__((swift_name("isOutOfStock")));
@property (readonly) BOOL isSubstitutable __attribute__((swift_name("isSubstitutable")));
@property (readonly) BOOL isUnavailable __attribute__((swift_name("isUnavailable")));
@property (readonly) int32_t itemsCountOrZero __attribute__((swift_name("itemsCountOrZero")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property BOOL needPatch __attribute__((swift_name("needPatch")));
@property (readonly) double price __attribute__((swift_name("price")));
@property (readonly) double pricePerUnitOfMeasurement __attribute__((swift_name("pricePerUnitOfMeasurement")));
@property (readonly) NSString *pricePerUnitOfMeasurementAsString __attribute__((swift_name("pricePerUnitOfMeasurementAsString")));
@property (readonly) int32_t quantity __attribute__((swift_name("quantity")));
@property (readonly) MealzcoreInt * _Nullable quantityToAdd __attribute__((swift_name("quantityToAdd")));
@property (readonly) int32_t recipeCount __attribute__((swift_name("recipeCount")));
@property (readonly) MealzcoreBasketEntryRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@property (readonly) MealzcoreItem * _Nullable selectedItem __attribute__((swift_name("selectedItem")));
@property (readonly) int32_t shareInRecipeCount __attribute__((swift_name("shareInRecipeCount")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) NSString * _Nullable unitOfMeasurement __attribute__((swift_name("unitOfMeasurement")));
@property (readonly) double unitPrice __attribute__((swift_name("unitPrice")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntry.Companion")))
@interface MealzcoreBasketEntryCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntry.CompanionStates")))
@interface MealzcoreBasketEntryCompanionStates : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)states __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryCompanionStates *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *ACTIVE __attribute__((swift_name("ACTIVE")));
@property (readonly) NSString *DELETED __attribute__((swift_name("DELETED")));
@property (readonly) NSString *IGNORED __attribute__((swift_name("IGNORED")));
@property (readonly) NSString *INITIAL __attribute__((swift_name("INITIAL")));
@property (readonly) NSString *OFTEN_DELETED __attribute__((swift_name("OFTEN_DELETED")));
@property (readonly) NSString *OUT_OF_STOCK __attribute__((swift_name("OUT_OF_STOCK")));
@property (readonly) NSString *UNAVAILABLE __attribute__((swift_name("UNAVAILABLE")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryAttributes")))
@interface MealzcoreBasketEntryAttributes : MealzcoreAttributes
- (instancetype)initWithSelectedItemId:(MealzcoreInt * _Nullable)selectedItemId quantity:(MealzcoreInt * _Nullable)quantity recipeIds:(NSArray<MealzcoreInt *> * _Nullable)recipeIds quantityToAdd:(MealzcoreInt * _Nullable)quantityToAdd status:(NSString *)status name:(NSString *)name unitPrice:(MealzcoreDouble * _Nullable)unitPrice pricePerUnitOfMeasurement:(MealzcoreDouble * _Nullable)pricePerUnitOfMeasurement unitOfMeasurement:(NSString * _Nullable)unitOfMeasurement discountedPrice:(MealzcoreDouble * _Nullable)discountedPrice discountType:(MealzcoreDiscountType *)discountType discountAmount:(MealzcoreDouble * _Nullable)discountAmount __attribute__((swift_name("init(selectedItemId:quantity:recipeIds:quantityToAdd:status:name:unitPrice:pricePerUnitOfMeasurement:unitOfMeasurement:discountedPrice:discountType:discountAmount:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreBasketEntryAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreBasketEntryAttributes *)doCopySelectedItemId:(MealzcoreInt * _Nullable)selectedItemId quantity:(MealzcoreInt * _Nullable)quantity recipeIds:(NSArray<MealzcoreInt *> * _Nullable)recipeIds quantityToAdd:(MealzcoreInt * _Nullable)quantityToAdd status:(NSString *)status name:(NSString *)name unitPrice:(MealzcoreDouble * _Nullable)unitPrice pricePerUnitOfMeasurement:(MealzcoreDouble * _Nullable)pricePerUnitOfMeasurement unitOfMeasurement:(NSString * _Nullable)unitOfMeasurement discountedPrice:(MealzcoreDouble * _Nullable)discountedPrice discountType:(MealzcoreDiscountType *)discountType discountAmount:(MealzcoreDouble * _Nullable)discountAmount __attribute__((swift_name("doCopy(selectedItemId:quantity:recipeIds:quantityToAdd:status:name:unitPrice:pricePerUnitOfMeasurement:unitOfMeasurement:discountedPrice:discountType:discountAmount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreDouble * _Nullable discountAmount __attribute__((swift_name("discountAmount")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/utils/DiscountTypeSerializer))
*/
@property (readonly) MealzcoreDiscountType *discountType __attribute__((swift_name("discountType")));
@property (readonly) MealzcoreDouble * _Nullable discountedPrice __attribute__((swift_name("discountedPrice")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) MealzcoreDouble * _Nullable pricePerUnitOfMeasurement __attribute__((swift_name("pricePerUnitOfMeasurement")));
@property (readonly) MealzcoreInt * _Nullable quantity __attribute__((swift_name("quantity")));
@property (readonly) MealzcoreInt * _Nullable quantityToAdd __attribute__((swift_name("quantityToAdd")));
@property (readonly) NSArray<MealzcoreInt *> * _Nullable recipeIds __attribute__((swift_name("recipeIds")));
@property (readonly) MealzcoreInt * _Nullable selectedItemId __attribute__((swift_name("selectedItemId")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) NSString * _Nullable unitOfMeasurement __attribute__((swift_name("unitOfMeasurement")));
@property (readonly) MealzcoreDouble * _Nullable unitPrice __attribute__((swift_name("unitPrice")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryAttributes.Companion")))
@interface MealzcoreBasketEntryAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((swift_name("RelationshipList")))
@interface MealzcoreRelationshipList : MealzcoreBase
@property (class, readonly, getter=companion) MealzcoreRelationshipListCompanion *companion __attribute__((swift_name("companion")));
- (NSArray<MealzcoreRecord *> *)buildedFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords subClass:(id<MealzcoreKotlinKClass>)subClass __attribute__((swift_name("buildedFromIncluded(includedRecords:subClass:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder __attribute__((swift_name("serialize(encoder:)")));
@property (readonly) NSArray<MealzcoreRecord *> *data __attribute__((swift_name("data")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/BasketEntryRelationshipListSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryRelationshipList")))
@interface MealzcoreBasketEntryRelationshipList : MealzcoreRelationshipList
- (instancetype)initWithData:(NSArray<MealzcoreBasketEntry *> *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreBasketEntryRelationshipListCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property NSArray<MealzcoreBasketEntry *> *data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryRelationshipList.Companion")))
@interface MealzcoreBasketEntryRelationshipListCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryRelationshipListCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol MealzcoreKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol MealzcoreKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol MealzcoreKotlinx_serialization_coreKSerializer <MealzcoreKotlinx_serialization_coreSerializationStrategy, MealzcoreKotlinx_serialization_coreDeserializationStrategy>
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializer(forClass=NormalClass(value=ai/mealz/core/model/BasketEntryRelationshipList))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryRelationshipListSerializer")))
@interface MealzcoreBasketEntryRelationshipListSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)basketEntryRelationshipListSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryRelationshipListSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreBasketEntryRelationshipList *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreBasketEntryRelationshipList *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((swift_name("Relationships")))
@interface MealzcoreRelationships : MealzcoreBase
@property (class, readonly, getter=companion) MealzcoreRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryRelationships")))
@interface MealzcoreBasketEntryRelationships : MealzcoreRelationships
- (instancetype)initWithItems:(MealzcoreItemRelationshipList * _Nullable)items selectedItem:(MealzcoreItemRelationship * _Nullable)selectedItem __attribute__((swift_name("init(items:selectedItem:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreBasketEntryRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
- (MealzcoreBasketEntryRelationships *)doCopyItems:(MealzcoreItemRelationshipList * _Nullable)items selectedItem:(MealzcoreItemRelationship * _Nullable)selectedItem __attribute__((swift_name("doCopy(items:selectedItem:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property MealzcoreItemRelationshipList * _Nullable items __attribute__((swift_name("items")));
@property MealzcoreItemRelationship * _Nullable selectedItem __attribute__((swift_name("selectedItem")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryRelationships.Companion")))
@interface MealzcoreBasketEntryRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketPrice")))
@interface MealzcoreBasketPrice : MealzcoreBase
- (instancetype)initWithTotalPrice:(double)totalPrice __attribute__((swift_name("init(totalPrice:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreBasketPriceCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreBasketPrice *)doCopyTotalPrice:(double)totalPrice __attribute__((swift_name("doCopy(totalPrice:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) double totalPrice __attribute__((swift_name("totalPrice")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketPrice.Companion")))
@interface MealzcoreBasketPriceCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketPriceCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketRelationships")))
@interface MealzcoreBasketRelationships : MealzcoreRelationships
- (instancetype)initWithBasketEntries:(MealzcoreBasketEntryRelationshipList * _Nullable)basketEntries __attribute__((swift_name("init(basketEntries:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreBasketRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
- (MealzcoreBasketRelationships *)doCopyBasketEntries:(MealzcoreBasketEntryRelationshipList * _Nullable)basketEntries __attribute__((swift_name("doCopy(basketEntries:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property MealzcoreBasketEntryRelationshipList * _Nullable basketEntries __attribute__((swift_name("basketEntries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketRelationships.Companion")))
@interface MealzcoreBasketRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/BasketStatusSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketStatus")))
@interface MealzcoreBasketStatus : MealzcoreKotlinEnum<MealzcoreBasketStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MealzcoreBasketStatusCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MealzcoreBasketStatus *initial __attribute__((swift_name("initial")));
@property (class, readonly) MealzcoreBasketStatus *transferring __attribute__((swift_name("transferring")));
@property (class, readonly) MealzcoreBasketStatus *transferred __attribute__((swift_name("transferred")));
@property (class, readonly) MealzcoreBasketStatus *confirmed __attribute__((swift_name("confirmed")));
+ (MealzcoreKotlinArray<MealzcoreBasketStatus *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreBasketStatus *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketStatus.Companion")))
@interface MealzcoreBasketStatusCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketStatusCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MealzcoreKotlinArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketStatusSerializer")))
@interface MealzcoreBasketStatusSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)basketStatusSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketStatusSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreBasketStatus *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreBasketStatus *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("CatalogCategory")))
@interface MealzcoreCatalogCategory : MealzcoreBase
- (instancetype)initWithId:(NSString *)id title:(NSString *)title __attribute__((swift_name("init(id:title:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CatalogFilterOptions")))
@interface MealzcoreCatalogFilterOptions : MealzcoreBase
- (instancetype)initWithName:(NSString *)name uiLabel:(NSString *)uiLabel isSelected:(BOOL)isSelected __attribute__((swift_name("init(name:uiLabel:isSelected:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreCatalogFilterOptions *)doCopyName:(NSString *)name uiLabel:(NSString *)uiLabel isSelected:(BOOL)isSelected __attribute__((swift_name("doCopy(name:uiLabel:isSelected:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (MealzcoreCatalogFilterOptions *)off __attribute__((swift_name("off()")));
- (MealzcoreCatalogFilterOptions *)on __attribute__((swift_name("on()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (MealzcoreCatalogFilterOptions *)toogle __attribute__((swift_name("toogle()")));
@property BOOL isSelected __attribute__((swift_name("isSelected")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *uiLabel __attribute__((swift_name("uiLabel")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckableTag")))
@interface MealzcoreCheckableTag : MealzcoreBase
- (instancetype)initWithTagType:(MealzcoreTagTypes *)tagType tag:(MealzcoreTag *)tag __attribute__((swift_name("init(tagType:tag:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithTagType:(MealzcoreTagTypes *)tagType tag:(MealzcoreTag *)tag isChecked:(BOOL)isChecked __attribute__((swift_name("init(tagType:tag:isChecked:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreCheckableTagCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreCheckableTag *)doCopyTagType:(MealzcoreTagTypes *)tagType tag:(MealzcoreTag *)tag isChecked:(BOOL)isChecked __attribute__((swift_name("doCopy(tagType:tag:isChecked:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (MealzcoreCheckableTag *)resetWithStorageTagIds:(NSArray<NSString *> *)storageTagIds __attribute__((swift_name("resetWith(storageTagIds:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (MealzcoreCheckableTag *)toggleIfNeededTagIdToToggle:(NSString *)tagIdToToggle __attribute__((swift_name("toggleIfNeeded(tagIdToToggle:)")));
@property (readonly) BOOL changedFromItsDefaultValue __attribute__((swift_name("changedFromItsDefaultValue")));
@property (readonly) BOOL isChecked __attribute__((swift_name("isChecked")));
@property (readonly) BOOL isDefault __attribute__((swift_name("isDefault")));
@property (readonly) BOOL isIncludedInQuery __attribute__((swift_name("isIncludedInQuery")));
@property (readonly) MealzcoreTag *tag __attribute__((swift_name("tag")));
@property (readonly) MealzcoreTagTypes *tagType __attribute__((swift_name("tagType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckableTag.Companion")))
@interface MealzcoreCheckableTagCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreCheckableTagCompanion *shared __attribute__((swift_name("shared")));
- (BOOL)checkedByDefaultTagType:(MealzcoreTagTypes *)tagType __attribute__((swift_name("checkedByDefault(tagType:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DiscountType")))
@interface MealzcoreDiscountType : MealzcoreKotlinEnum<MealzcoreDiscountType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreDiscountType *undiscounted __attribute__((swift_name("undiscounted")));
@property (class, readonly) MealzcoreDiscountType *unsupported __attribute__((swift_name("unsupported")));
@property (class, readonly) MealzcoreDiscountType *strikethroughPrice __attribute__((swift_name("strikethroughPrice")));
@property (class, readonly) MealzcoreDiscountType *strikethroughPricePercentage __attribute__((swift_name("strikethroughPricePercentage")));
@property (class, readonly) MealzcoreDiscountType *loyaltyFund __attribute__((swift_name("loyaltyFund")));
@property (class, readonly) MealzcoreDiscountType *loyaltyFundPercentage __attribute__((swift_name("loyaltyFundPercentage")));
@property (class, readonly) MealzcoreDiscountType *loyaltyDiscount __attribute__((swift_name("loyaltyDiscount")));
@property (class, readonly) MealzcoreDiscountType *loyaltyDiscountPercentage __attribute__((swift_name("loyaltyDiscountPercentage")));
@property (class, readonly) MealzcoreDiscountType *discountedProduct __attribute__((swift_name("discountedProduct")));
@property (class, readonly) MealzcoreDiscountType *discountedProductPercentage __attribute__((swift_name("discountedProductPercentage")));
+ (MealzcoreKotlinArray<MealzcoreDiscountType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreDiscountType *> *entries __attribute__((swift_name("entries")));
- (NSString *)formatDiscountAmountDiscountAmount:(double)discountAmount __attribute__((swift_name("formatDiscountAmount(discountAmount:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *apiName __attribute__((swift_name("apiName")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ingredient")))
@interface MealzcoreIngredient : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreIngredientCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreIngredient *)doCopyId:(NSString *)id attributes:(MealzcoreIngredientAttributes * _Nullable)attributes relationships:(MealzcoreIngredientRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (void)ingredientAttributesGuardCallbacks:(void (^)(NSString *, NSString *, NSString *, NSString *))callbacks __attribute__((swift_name("ingredientAttributesGuard(callbacks:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreIngredientAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) BOOL isIgnored __attribute__((swift_name("isIgnored")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property NSString * _Nullable recipeId __attribute__((swift_name("recipeId")));
@property (readonly) MealzcoreIngredientRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ingredient.Companion")))
@interface MealzcoreIngredientCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreIngredientCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IngredientAttributes")))
@interface MealzcoreIngredientAttributes : MealzcoreAttributes
- (instancetype)initWithName:(NSString * _Nullable)name quantity:(NSString * _Nullable)quantity unit:(NSString * _Nullable)unit pictureUrl:(NSString * _Nullable)pictureUrl forcedEans:(NSArray<NSString *> *)forcedEans __attribute__((swift_name("init(name:quantity:unit:pictureUrl:forcedEans:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreIngredientAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreIngredientAttributes *)doCopyName:(NSString * _Nullable)name quantity:(NSString * _Nullable)quantity unit:(NSString * _Nullable)unit pictureUrl:(NSString * _Nullable)pictureUrl forcedEans:(NSArray<NSString *> *)forcedEans __attribute__((swift_name("doCopy(name:quantity:unit:pictureUrl:forcedEans:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<NSString *> *forcedEans __attribute__((swift_name("forcedEans")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) NSString * _Nullable pictureUrl __attribute__((swift_name("pictureUrl")));
@property (readonly) NSString * _Nullable quantity __attribute__((swift_name("quantity")));
@property (readonly) NSString * _Nullable unit __attribute__((swift_name("unit")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IngredientAttributes.Companion")))
@interface MealzcoreIngredientAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreIngredientAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/IngredientListSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IngredientListRelationship")))
@interface MealzcoreIngredientListRelationship : MealzcoreRelationshipList
- (instancetype)initWithData:(NSArray<MealzcoreIngredient *> *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreIngredientListRelationshipCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property NSArray<MealzcoreIngredient *> *data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IngredientListRelationship.Companion")))
@interface MealzcoreIngredientListRelationshipCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreIngredientListRelationshipCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializer(forClass=NormalClass(value=ai/mealz/core/model/IngredientListRelationship))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IngredientListSerializer")))
@interface MealzcoreIngredientListSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)ingredientListSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreIngredientListSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreIngredientListRelationship *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreIngredientListRelationship *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IngredientRelationships")))
@interface MealzcoreIngredientRelationships : MealzcoreRelationships
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)ingredientRelationships __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreIngredientRelationships *shared __attribute__((swift_name("shared")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MealzcoreKotlinArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Item")))
@interface MealzcoreItem : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreItemCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreItem *)doCopyId:(NSString *)id attributes:(MealzcoreItemAttributes * _Nullable)attributes relationships:(MealzcoreItemRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreItemAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *capacity __attribute__((swift_name("capacity")));
@property (readonly) NSString *capacityCombined __attribute__((swift_name("capacityCombined")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *pricePerUnitOfMeasurementAsString __attribute__((swift_name("pricePerUnitOfMeasurementAsString")));
@property (readonly) MealzcoreItemRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Item.Companion")))
@interface MealzcoreItemCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemAttributes")))
@interface MealzcoreItemAttributes : MealzcoreAttributes
- (instancetype)initWithExtId:(NSString * _Nullable)extId name:(NSString *)name itemDescription:(NSString * _Nullable)itemDescription brand:(NSString * _Nullable)brand image:(NSString * _Nullable)image unitPrice:(MealzcoreDouble * _Nullable)unitPrice pricePerUnitOfMeasurement:(MealzcoreDouble * _Nullable)pricePerUnitOfMeasurement unitOfMeasurement:(NSString * _Nullable)unitOfMeasurement discountedPrice:(MealzcoreDouble * _Nullable)discountedPrice discountType:(MealzcoreDiscountType * _Nullable)discountType discountAmount:(MealzcoreDouble * _Nullable)discountAmount capacityUnit:(NSString * _Nullable)capacityUnit capacityVolume:(NSString * _Nullable)capacityVolume capacityFactor:(MealzcoreInt * _Nullable)capacityFactor ean:(NSString *)ean sponsored:(BOOL)sponsored __attribute__((swift_name("init(extId:name:itemDescription:brand:image:unitPrice:pricePerUnitOfMeasurement:unitOfMeasurement:discountedPrice:discountType:discountAmount:capacityUnit:capacityVolume:capacityFactor:ean:sponsored:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreItemAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreItemAttributes *)doCopyExtId:(NSString * _Nullable)extId name:(NSString *)name itemDescription:(NSString * _Nullable)itemDescription brand:(NSString * _Nullable)brand image:(NSString * _Nullable)image unitPrice:(MealzcoreDouble * _Nullable)unitPrice pricePerUnitOfMeasurement:(MealzcoreDouble * _Nullable)pricePerUnitOfMeasurement unitOfMeasurement:(NSString * _Nullable)unitOfMeasurement discountedPrice:(MealzcoreDouble * _Nullable)discountedPrice discountType:(MealzcoreDiscountType * _Nullable)discountType discountAmount:(MealzcoreDouble * _Nullable)discountAmount capacityUnit:(NSString * _Nullable)capacityUnit capacityVolume:(NSString * _Nullable)capacityVolume capacityFactor:(MealzcoreInt * _Nullable)capacityFactor ean:(NSString *)ean sponsored:(BOOL)sponsored __attribute__((swift_name("doCopy(extId:name:itemDescription:brand:image:unitPrice:pricePerUnitOfMeasurement:unitOfMeasurement:discountedPrice:discountType:discountAmount:capacityUnit:capacityVolume:capacityFactor:ean:sponsored:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable brand __attribute__((swift_name("brand")));
@property (readonly) NSString * _Nullable brandOrNull __attribute__((swift_name("brandOrNull")));
@property (readonly) MealzcoreInt * _Nullable capacityFactor __attribute__((swift_name("capacityFactor")));
@property (readonly) NSString * _Nullable capacityUnit __attribute__((swift_name("capacityUnit")));
@property (readonly) NSString * _Nullable capacityVolume __attribute__((swift_name("capacityVolume")));
@property (readonly) MealzcoreDouble * _Nullable discountAmount __attribute__((swift_name("discountAmount")));
@property (readonly) MealzcoreDiscountType * _Nullable discountType __attribute__((swift_name("discountType")));
@property (readonly) MealzcoreDouble * _Nullable discountedPrice __attribute__((swift_name("discountedPrice")));
@property (readonly) NSString *ean __attribute__((swift_name("ean")));
@property (readonly) NSString * _Nullable extId __attribute__((swift_name("extId")));
@property (readonly) NSString * _Nullable image __attribute__((swift_name("image")));
@property (readonly) NSString * _Nullable itemDescription __attribute__((swift_name("itemDescription")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) MealzcoreDouble * _Nullable pricePerUnitOfMeasurement __attribute__((swift_name("pricePerUnitOfMeasurement")));
@property (readonly) BOOL sponsored __attribute__((swift_name("sponsored")));
@property (readonly) NSString * _Nullable unitOfMeasurement __attribute__((swift_name("unitOfMeasurement")));
@property (readonly) MealzcoreDouble * _Nullable unitPrice __attribute__((swift_name("unitPrice")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemAttributes.Companion")))
@interface MealzcoreItemAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemPrice")))
@interface MealzcoreItemPrice : MealzcoreBase
- (instancetype)initWithUnitPrice:(MealzcoreDouble * _Nullable)unitPrice pricePerUnitOfMeasurement:(MealzcoreDouble * _Nullable)pricePerUnitOfMeasurement unitOfMeasurement:(NSString * _Nullable)unitOfMeasurement discountedPrice:(MealzcoreDouble * _Nullable)discountedPrice discountType:(MealzcoreDiscountType *)discountType discountAmount:(MealzcoreDouble * _Nullable)discountAmount __attribute__((swift_name("init(unitPrice:pricePerUnitOfMeasurement:unitOfMeasurement:discountedPrice:discountType:discountAmount:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreItemPriceCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreItemPrice *)doCopyUnitPrice:(MealzcoreDouble * _Nullable)unitPrice pricePerUnitOfMeasurement:(MealzcoreDouble * _Nullable)pricePerUnitOfMeasurement unitOfMeasurement:(NSString * _Nullable)unitOfMeasurement discountedPrice:(MealzcoreDouble * _Nullable)discountedPrice discountType:(MealzcoreDiscountType *)discountType discountAmount:(MealzcoreDouble * _Nullable)discountAmount __attribute__((swift_name("doCopy(unitPrice:pricePerUnitOfMeasurement:unitOfMeasurement:discountedPrice:discountType:discountAmount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreDouble * _Nullable discountAmount __attribute__((swift_name("discountAmount")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/utils/DiscountTypeSerializer))
*/
@property (readonly) MealzcoreDiscountType *discountType __attribute__((swift_name("discountType")));
@property (readonly) MealzcoreDouble * _Nullable discountedPrice __attribute__((swift_name("discountedPrice")));
@property (readonly) MealzcoreDouble * _Nullable pricePerUnitOfMeasurement __attribute__((swift_name("pricePerUnitOfMeasurement")));
@property (readonly) NSString * _Nullable unitOfMeasurement __attribute__((swift_name("unitOfMeasurement")));
@property (readonly) MealzcoreDouble * _Nullable unitPrice __attribute__((swift_name("unitPrice")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemPrice.Companion")))
@interface MealzcoreItemPriceCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemPriceCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((swift_name("Relationship")))
@interface MealzcoreRelationship : MealzcoreBase
@property (class, readonly, getter=companion) MealzcoreRelationshipCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecord *)buildedFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords subClass:(id<MealzcoreKotlinKClass>)subClass __attribute__((swift_name("buildedFromIncluded(includedRecords:subClass:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder __attribute__((swift_name("serialize(encoder:)")));
@property (readonly) MealzcoreRecord *data __attribute__((swift_name("data")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/ItemRelationshipSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemRelationship")))
@interface MealzcoreItemRelationship : MealzcoreRelationship
- (instancetype)initWithData:(MealzcoreItem *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreItemRelationshipCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecord:(NSArray<MealzcoreRecord *> *)includedRecord __attribute__((swift_name("buildFromIncluded(includedRecord:)")));
@property MealzcoreItem *data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemRelationship.Companion")))
@interface MealzcoreItemRelationshipCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemRelationshipCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/ItemRelationshipListSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemRelationshipList")))
@interface MealzcoreItemRelationshipList : MealzcoreRelationshipList
- (instancetype)initWithData:(NSArray<MealzcoreItem *> *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreItemRelationshipListCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property NSArray<MealzcoreItem *> *data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemRelationshipList.Companion")))
@interface MealzcoreItemRelationshipListCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemRelationshipListCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializer(forClass=NormalClass(value=ai/mealz/core/model/ItemRelationshipList))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemRelationshipListSerializer")))
@interface MealzcoreItemRelationshipListSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)itemRelationshipListSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemRelationshipListSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreItemRelationshipList *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreItemRelationshipList *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializer(forClass=NormalClass(value=ai/mealz/core/model/ItemRelationship))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemRelationshipSerializer")))
@interface MealzcoreItemRelationshipSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)itemRelationshipSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemRelationshipSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreItemRelationship *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreItemRelationship *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemRelationships")))
@interface MealzcoreItemRelationships : MealzcoreRelationships
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreItemRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemRelationships.Companion")))
@interface MealzcoreItemRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerRecipe")))
@interface MealzcoreMealPlannerRecipe : MealzcoreBase
- (instancetype)initWithRecipeId:(NSString *)recipeId price:(double)price __attribute__((swift_name("init(recipeId:price:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMealPlannerRecipe *)doCopyRecipeId:(NSString *)recipeId price:(double)price __attribute__((swift_name("doCopy(recipeId:price:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) double price __attribute__((swift_name("price")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MiamConfig")))
@interface MealzcoreMiamConfig : MealzcoreBase
@property (class, readonly, getter=companion) MealzcoreMiamConfigCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreMiamConfig *)doCopySupplierId:(NSString * _Nullable)supplierId providerId:(NSString * _Nullable)providerId plausibleDomain:(NSString *)plausibleDomain miamOrigin:(NSString *)miamOrigin origin:(NSString *)origin environment:(NSString *)environment __attribute__((swift_name("doCopy(supplierId:providerId:plausibleDomain:miamOrigin:origin:environment:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *environment __attribute__((swift_name("environment")));
@property (readonly) NSString *miamOrigin __attribute__((swift_name("miamOrigin")));
@property (readonly) NSString *origin __attribute__((swift_name("origin")));
@property (readonly) NSString *plausibleDomain __attribute__((swift_name("plausibleDomain")));
@property (readonly) NSString * _Nullable providerId __attribute__((swift_name("providerId")));
@property (readonly) NSString * _Nullable supplierId __attribute__((swift_name("supplierId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MiamConfig.Companion")))
@interface MealzcoreMiamConfigCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMiamConfigCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Package")))
@interface MealzcorePackage : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcorePackageCompanion *companion __attribute__((swift_name("companion")));
- (MealzcorePackage *)buildRecipesRecipes:(NSArray<MealzcoreRecipe *> *)recipes __attribute__((swift_name("buildRecipes(recipes:)")));
- (MealzcorePackage *)doCopyId:(NSString *)id attributes:(MealzcorePackageAttributes * _Nullable)attributes relationships:(MealzcorePackageRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property MealzcorePackageAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) MealzcorePackageRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@property (readonly) NSString * _Nullable subtitle __attribute__((swift_name("subtitle")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Package.Companion")))
@interface MealzcorePackageCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePackageCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PackageAttributes")))
@interface MealzcorePackageAttributes : MealzcoreAttributes
- (instancetype)initWithTitle:(NSString *)title settings:(MealzcorePackageSettings *)settings __attribute__((swift_name("init(title:settings:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcorePackageAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcorePackageAttributes *)doCopyTitle:(NSString *)title settings:(MealzcorePackageSettings *)settings __attribute__((swift_name("doCopy(title:settings:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcorePackageSettings *settings __attribute__((swift_name("settings")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PackageAttributes.Companion")))
@interface MealzcorePackageAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePackageAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PackageRelationships")))
@interface MealzcorePackageRelationships : MealzcoreRelationships
- (instancetype)initWithRecipes:(MealzcoreRecipeRelationshipList * _Nullable)recipes __attribute__((swift_name("init(recipes:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcorePackageRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
- (MealzcorePackageRelationships *)doCopyRecipes:(MealzcoreRecipeRelationshipList * _Nullable)recipes __attribute__((swift_name("doCopy(recipes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property MealzcoreRecipeRelationshipList * _Nullable recipes __attribute__((swift_name("recipes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PackageRelationships.Companion")))
@interface MealzcorePackageRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePackageRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PackageSettings")))
@interface MealzcorePackageSettings : MealzcoreBase
- (instancetype)initWithSubtitle:(NSString * _Nullable)subtitle __attribute__((swift_name("init(subtitle:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcorePackageSettingsCompanion *companion __attribute__((swift_name("companion")));
- (MealzcorePackageSettings *)doCopySubtitle:(NSString * _Nullable)subtitle __attribute__((swift_name("doCopy(subtitle:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable subtitle __attribute__((swift_name("subtitle")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PackageSettings.Companion")))
@interface MealzcorePackageSettingsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePackageSettingsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PointOfSale")))
@interface MealzcorePointOfSale : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes __attribute__((swift_name("init(id:attributes:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithId:(NSString *)id attributes:(MealzcorePointOfSaleAttributes * _Nullable)attributes relationships:(MealzcoreRelationships * _Nullable)relationships __attribute__((swift_name("init(id:attributes:relationships:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcorePointOfSaleCompanion *companion __attribute__((swift_name("companion")));
- (MealzcorePointOfSale *)doCopyId:(NSString *)id attributes:(MealzcorePointOfSaleAttributes * _Nullable)attributes relationships:(MealzcoreRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcorePointOfSaleAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) MealzcoreRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PointOfSale.Companion")))
@interface MealzcorePointOfSaleCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePointOfSaleCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PointOfSaleAttributes")))
@interface MealzcorePointOfSaleAttributes : MealzcoreAttributes
- (instancetype)initWithName:(NSString *)name address:(NSString *)address __attribute__((swift_name("init(name:address:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcorePointOfSaleAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcorePointOfSaleAttributes *)doCopyName:(NSString *)name address:(NSString *)address __attribute__((swift_name("doCopy(name:address:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *address __attribute__((swift_name("address")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PointOfSaleAttributes.Companion")))
@interface MealzcorePointOfSaleAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePointOfSaleAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Recipe")))
@interface MealzcoreRecipe : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecipe *)doCopyId:(NSString *)id attributes:(MealzcoreRecipeAttributes * _Nullable)attributes relationships:(MealzcoreRecipeRelationships * _Nullable)relationships recipeLike:(MealzcoreRecipeLike * _Nullable)recipeLike __attribute__((swift_name("doCopy(id:attributes:relationships:recipeLike:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreRecipeAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *cookingTimeIos __attribute__((swift_name("cookingTimeIos")));
@property (readonly) MealzcoreRecipeDifficulty *difficulty __attribute__((swift_name("difficulty")));
@property (readonly) BOOL hasRelationships __attribute__((swift_name("hasRelationships")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSDictionary<NSString *, NSString *> *ingredientsMap __attribute__((swift_name("ingredientsMap")));
@property (readonly) BOOL isADrink __attribute__((swift_name("isADrink")));
@property (readonly) BOOL isSponsored __attribute__((swift_name("isSponsored")));
@property (readonly) NSString *preparationTimeIos __attribute__((swift_name("preparationTimeIos")));
@property (readonly) MealzcoreRecipeLike * _Nullable recipeLike __attribute__((swift_name("recipeLike")));
@property (readonly) MealzcoreRecipeRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@property (readonly) NSString *restingTimeIos __attribute__((swift_name("restingTimeIos")));
@property (readonly) NSArray<MealzcoreRecipeStep *> *sortedStep __attribute__((swift_name("sortedStep")));
@property (readonly) NSString *totalTime __attribute__((swift_name("totalTime")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Recipe.Companion")))
@interface MealzcoreRecipeCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeAttributes")))
@interface MealzcoreRecipeAttributes : MealzcoreAttributes
- (instancetype)initWithTitle:(NSString *)title extId:(NSString * _Nullable)extId recipeDescription:(NSString * _Nullable)recipeDescription numberOfGuests:(int32_t)numberOfGuests preparationTime:(id _Nullable)preparationTime cookingTime:(id _Nullable)cookingTime restingTime:(id _Nullable)restingTime computedCost:(MealzcoreDouble * _Nullable)computedCost mediaUrl:(NSString *)mediaUrl difficulty:(MealzcoreInt * _Nullable)difficulty price:(MealzcoreRecipePricing * _Nullable)price discountedIngredientCount:(int32_t)discountedIngredientCount orderHistory:(NSString * _Nullable)orderHistory __attribute__((swift_name("init(title:extId:recipeDescription:numberOfGuests:preparationTime:cookingTime:restingTime:computedCost:mediaUrl:difficulty:price:discountedIngredientCount:orderHistory:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecipeAttributes *)doCopyTitle:(NSString *)title extId:(NSString * _Nullable)extId recipeDescription:(NSString * _Nullable)recipeDescription numberOfGuests:(int32_t)numberOfGuests preparationTime:(id _Nullable)preparationTime cookingTime:(id _Nullable)cookingTime restingTime:(id _Nullable)restingTime computedCost:(MealzcoreDouble * _Nullable)computedCost mediaUrl:(NSString *)mediaUrl difficulty:(MealzcoreInt * _Nullable)difficulty price:(MealzcoreRecipePricing * _Nullable)price discountedIngredientCount:(int32_t)discountedIngredientCount orderHistory:(NSString * _Nullable)orderHistory __attribute__((swift_name("doCopy(title:extId:recipeDescription:numberOfGuests:preparationTime:cookingTime:restingTime:computedCost:mediaUrl:difficulty:price:discountedIngredientCount:orderHistory:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreDouble * _Nullable computedCost __attribute__((swift_name("computedCost")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/utils/CustomDurationSerializer))
*/
@property (readonly) id _Nullable cookingTime __attribute__((swift_name("cookingTime")));
@property (readonly) MealzcoreInt * _Nullable difficulty __attribute__((swift_name("difficulty")));
@property (readonly) int32_t discountedIngredientCount __attribute__((swift_name("discountedIngredientCount")));
@property (readonly) NSString * _Nullable extId __attribute__((swift_name("extId")));
@property (readonly) NSString *mediaUrl __attribute__((swift_name("mediaUrl")));
@property (readonly) int32_t numberOfGuests __attribute__((swift_name("numberOfGuests")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/utils/CustomDateSerializer))
*/
@property (readonly) NSString * _Nullable orderHistory __attribute__((swift_name("orderHistory")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/utils/CustomDurationSerializer))
*/
@property (readonly) id _Nullable preparationTime __attribute__((swift_name("preparationTime")));
@property (readonly) MealzcoreRecipePricing * _Nullable price __attribute__((swift_name("price")));
@property (readonly) NSString * _Nullable recipeDescription __attribute__((swift_name("recipeDescription")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/utils/CustomDurationSerializer))
*/
@property (readonly) id _Nullable restingTime __attribute__((swift_name("restingTime")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeAttributes.Companion")))
@interface MealzcoreRecipeAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeDifficulty")))
@interface MealzcoreRecipeDifficulty : MealzcoreKotlinEnum<MealzcoreRecipeDifficulty *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreRecipeDifficulty *easy __attribute__((swift_name("easy")));
@property (class, readonly) MealzcoreRecipeDifficulty *medium __attribute__((swift_name("medium")));
@property (class, readonly) MealzcoreRecipeDifficulty *hard __attribute__((swift_name("hard")));
+ (MealzcoreKotlinArray<MealzcoreRecipeDifficulty *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreRecipeDifficulty *> *entries __attribute__((swift_name("entries")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeInfos")))
@interface MealzcoreRecipeInfos : MealzcoreBase
- (instancetype)initWithId:(int32_t)id guests:(int32_t)guests __attribute__((swift_name("init(id:guests:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeInfosCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecipeInfos *)doCopyId:(int32_t)id guests:(int32_t)guests __attribute__((swift_name("doCopy(id:guests:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int32_t guests __attribute__((swift_name("guests")));
@property (readonly) int32_t id __attribute__((swift_name("id")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeInfos.Companion")))
@interface MealzcoreRecipeInfosCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeInfosCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeLike")))
@interface MealzcoreRecipeLike : MealzcoreRecord
- (instancetype)initWithId:(NSString * _Nullable)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeLikeCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecipeLike *)doCopyId:(NSString * _Nullable)id attributes:(MealzcoreRecipeLikeAttributes * _Nullable)attributes relationships:(MealzcoreRecipeLikeRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (MealzcoreRecipeLike *)toggle __attribute__((swift_name("toggle()")));
@property (readonly) MealzcoreRecipeLikeAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL exists __attribute__((swift_name("exists")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@property (readonly) BOOL isLiked __attribute__((swift_name("isLiked")));
@property (readonly) MealzcoreRecipeLikeRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeLike.Companion")))
@interface MealzcoreRecipeLikeCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeLikeCompanion *shared __attribute__((swift_name("shared")));
- (MealzcoreRecipeLike *)createDefaultRecipeId:(NSString *)recipeId __attribute__((swift_name("createDefault(recipeId:)")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeLikeAttributes")))
@interface MealzcoreRecipeLikeAttributes : MealzcoreAttributes
- (instancetype)initWithIsPast:(BOOL)isPast recipeId:(int32_t)recipeId __attribute__((swift_name("init(isPast:recipeId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeLikeAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecipeLikeAttributes *)doCopyIsPast:(BOOL)isPast recipeId:(int32_t)recipeId __attribute__((swift_name("doCopy(isPast:recipeId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isPast __attribute__((swift_name("isPast")));
@property (readonly) int32_t recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeLikeAttributes.Companion")))
@interface MealzcoreRecipeLikeAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeLikeAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeLikeRelationships")))
@interface MealzcoreRecipeLikeRelationships : MealzcoreRelationships
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreRecipeLikeRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeLikeRelationships.Companion")))
@interface MealzcoreRecipeLikeRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeLikeRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipePlan")))
@interface MealzcoreRecipePlan : MealzcoreBase
- (instancetype)initWithMaxRecipes:(int32_t)maxRecipes __attribute__((swift_name("init(maxRecipes:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipePlanCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecipePlan *)doCopyMaxRecipes:(int32_t)maxRecipes __attribute__((swift_name("doCopy(maxRecipes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t maxRecipes __attribute__((swift_name("maxRecipes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipePlan.Companion")))
@interface MealzcoreRecipePlanCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipePlanCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipePricing")))
@interface MealzcoreRecipePricing : MealzcoreBase
- (instancetype)initWithPrice:(double)price serves:(int32_t)serves discountedIngredientsCount:(int32_t)discountedIngredientsCount __attribute__((swift_name("init(price:serves:discountedIngredientsCount:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPrice:(double)price serves:(int32_t)serves pricePerServe:(double)pricePerServe discountedIngredientsCount:(int32_t)discountedIngredientsCount __attribute__((swift_name("init(price:serves:pricePerServe:discountedIngredientsCount:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipePricingCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecipePricing *)doCopyPrice:(double)price serves:(int32_t)serves pricePerServe:(double)pricePerServe discountedIngredientsCount:(int32_t)discountedIngredientsCount __attribute__((swift_name("doCopy(price:serves:pricePerServe:discountedIngredientsCount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t discountedIngredientsCount __attribute__((swift_name("discountedIngredientsCount")));
@property (readonly) double price __attribute__((swift_name("price")));
@property (readonly) double pricePerServe __attribute__((swift_name("pricePerServe")));
@property (readonly) int32_t serves __attribute__((swift_name("serves")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipePricing.Companion")))
@interface MealzcoreRecipePricingCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipePricingCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/RecipeRelationshipListSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeRelationshipList")))
@interface MealzcoreRecipeRelationshipList : MealzcoreRelationshipList
- (instancetype)initWithData:(NSArray<MealzcoreRecipe *> *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeRelationshipListCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property NSArray<MealzcoreRecipe *> *data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeRelationshipList.Companion")))
@interface MealzcoreRecipeRelationshipListCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeRelationshipListCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializer(forClass=NormalClass(value=ai/mealz/core/model/RecipeRelationshipList))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeRelationshipListSerializer")))
@interface MealzcoreRecipeRelationshipListSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeRelationshipListSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeRelationshipListSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreRecipeRelationshipList *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreRecipeRelationshipList *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeRelationships")))
@interface MealzcoreRecipeRelationships : MealzcoreRelationships
- (instancetype)initWithIngredients:(MealzcoreIngredientListRelationship * _Nullable)ingredients sponsors:(MealzcoreSponsorListRelationship * _Nullable)sponsors recipeSteps:(MealzcoreRecipeStepListRelationship * _Nullable)recipeSteps tags:(MealzcoreTagListRelationship * _Nullable)tags __attribute__((swift_name("init(ingredients:sponsors:recipeSteps:tags:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
- (MealzcoreRecipeRelationships *)doCopyIngredients:(MealzcoreIngredientListRelationship * _Nullable)ingredients sponsors:(MealzcoreSponsorListRelationship * _Nullable)sponsors recipeSteps:(MealzcoreRecipeStepListRelationship * _Nullable)recipeSteps tags:(MealzcoreTagListRelationship * _Nullable)tags __attribute__((swift_name("doCopy(ingredients:sponsors:recipeSteps:tags:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property MealzcoreIngredientListRelationship * _Nullable ingredients __attribute__((swift_name("ingredients")));
@property MealzcoreRecipeStepListRelationship * _Nullable recipeSteps __attribute__((swift_name("recipeSteps")));
@property MealzcoreSponsorListRelationship * _Nullable sponsors __attribute__((swift_name("sponsors")));
@property MealzcoreTagListRelationship * _Nullable tags __attribute__((swift_name("tags")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeRelationships.Companion")))
@interface MealzcoreRecipeRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeStep")))
@interface MealzcoreRecipeStep : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeStepCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecipeStep *)doCopyId:(NSString *)id attributes:(MealzcoreRecipeStepAttributes * _Nullable)attributes relationships:(MealzcoreRecipeStepRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreRecipeStepAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) MealzcoreRecipeStepRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeStep.Companion")))
@interface MealzcoreRecipeStepCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeStepCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeStepAttributes")))
@interface MealzcoreRecipeStepAttributes : MealzcoreAttributes
- (instancetype)initWithStepNumber:(int32_t)stepNumber title:(NSString * _Nullable)title stepDescription:(NSString * _Nullable)stepDescription mediaUrl:(NSString * _Nullable)mediaUrl __attribute__((swift_name("init(stepNumber:title:stepDescription:mediaUrl:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeStepAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecipeStepAttributes *)doCopyStepNumber:(int32_t)stepNumber title:(NSString * _Nullable)title stepDescription:(NSString * _Nullable)stepDescription mediaUrl:(NSString * _Nullable)mediaUrl __attribute__((swift_name("doCopy(stepNumber:title:stepDescription:mediaUrl:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable mediaUrl __attribute__((swift_name("mediaUrl")));
@property (readonly) NSString * _Nullable stepDescription __attribute__((swift_name("stepDescription")));
@property (readonly) int32_t stepNumber __attribute__((swift_name("stepNumber")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeStepAttributes.Companion")))
@interface MealzcoreRecipeStepAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeStepAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializer(forClass=NormalClass(value=ai/mealz/core/model/RecipeStepListRelationship))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeStepListListSerializer")))
@interface MealzcoreRecipeStepListListSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeStepListListSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeStepListListSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreRecipeStepListRelationship *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreRecipeStepListRelationship *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/RecipeStepListListSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeStepListRelationship")))
@interface MealzcoreRecipeStepListRelationship : MealzcoreRelationshipList
- (instancetype)initWithData:(NSArray<MealzcoreRecipeStep *> *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecipeStepListRelationshipCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property NSArray<MealzcoreRecipeStep *> *data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeStepListRelationship.Companion")))
@interface MealzcoreRecipeStepListRelationshipCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeStepListRelationshipCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeStepRelationships")))
@interface MealzcoreRecipeStepRelationships : MealzcoreRelationships
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreRecipeStepRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeStepRelationships.Companion")))
@interface MealzcoreRecipeStepRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeStepRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Record.Companion")))
@interface MealzcoreRecordCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecordCompanion *shared __attribute__((swift_name("shared")));
- (MealzcoreRecord * _Nullable)fromStringStr:(NSString *)str __attribute__((swift_name("fromString(str:)")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MealzcoreKotlinArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecordCounterWrapper")))
@interface MealzcoreRecordCounterWrapper : MealzcoreBase
- (instancetype)initWithLinks:(MealzcoreRecordLink *)links data:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)data __attribute__((swift_name("init(links:data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecordCounterWrapperCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecordCounterWrapper *)doCopyLinks:(MealzcoreRecordLink *)links data:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)data __attribute__((swift_name("doCopy(links:data:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (int32_t)getCount __attribute__((swift_name("getCount()")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable data __attribute__((swift_name("data")));
@property MealzcoreRecordLink *links __attribute__((swift_name("links")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecordCounterWrapper.Companion")))
@interface MealzcoreRecordCounterWrapperCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecordCounterWrapperCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecordLink")))
@interface MealzcoreRecordLink : MealzcoreBase
- (instancetype)initWithFirst:(NSString *)first last:(NSString *)last __attribute__((swift_name("init(first:last:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecordLinkCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecordLink *)doCopyFirst:(NSString *)first last:(NSString *)last __attribute__((swift_name("doCopy(first:last:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *first __attribute__((swift_name("first")));
@property (readonly) NSString *last __attribute__((swift_name("last")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecordLink.Companion")))
@interface MealzcoreRecordLinkCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecordLinkCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecordWrapper")))
@interface MealzcoreRecordWrapper : MealzcoreBase
- (instancetype)initWithData:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)data included:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)included __attribute__((swift_name("init(data:included:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRecordWrapperCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRecordWrapper *)doCopyData:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)data included:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)included __attribute__((swift_name("doCopy(data:included:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (MealzcoreRecord *)toRecord __attribute__((swift_name("toRecord()")));
- (NSArray<MealzcoreRecord *> *)toRecords __attribute__((swift_name("toRecords()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable data __attribute__((swift_name("data")));
@property MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable included __attribute__((swift_name("included")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecordWrapper.Companion")))
@interface MealzcoreRecordWrapperCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecordWrapperCompanion *shared __attribute__((swift_name("shared")));
- (MealzcoreRecordWrapper *)fromRecordRecord:(MealzcoreRecord *)record __attribute__((swift_name("fromRecord(record:)")));
- (MealzcoreRecordWrapper *)fromRecordsRecords:(NSArray<MealzcoreRecord *> *)records __attribute__((swift_name("fromRecords(records:)")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Relationship.Companion")))
@interface MealzcoreRelationshipCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRelationshipCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MealzcoreKotlinArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RelationshipList.Companion")))
@interface MealzcoreRelationshipListCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRelationshipListCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MealzcoreKotlinArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Relationships.Companion")))
@interface MealzcoreRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (MealzcoreKotlinx_serialization_jsonJsonElement *)filterEmptyRelationshipsRelationships:(MealzcoreKotlinx_serialization_jsonJsonElement *)relationships __attribute__((swift_name("filterEmptyRelationships(relationships:)")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MealzcoreKotlinArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Sponsor")))
@interface MealzcoreSponsor : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreSponsor *)doCopyId:(NSString *)id attributes:(MealzcoreSponsorAttributes * _Nullable)attributes relationships:(MealzcoreSponsorRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreSponsorAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) MealzcoreSponsorRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Sponsor.Companion")))
@interface MealzcoreSponsorCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorAttributes")))
@interface MealzcoreSponsorAttributes : MealzcoreAttributes
- (instancetype)initWithName:(NSString *)name logoUrl:(NSString *)logoUrl __attribute__((swift_name("init(name:logoUrl:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreSponsorAttributes *)doCopyName:(NSString *)name logoUrl:(NSString *)logoUrl __attribute__((swift_name("doCopy(name:logoUrl:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *logoUrl __attribute__((swift_name("logoUrl")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorAttributes.Companion")))
@interface MealzcoreSponsorAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlock")))
@interface MealzcoreSponsorBlock : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorBlockCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreSponsorBlock *)doCopyId:(NSString *)id attributes:(MealzcoreSponsorBlockAttributes * _Nullable)attributes relationships:(MealzcoreSponsorBlockRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreSponsorBlockAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) MealzcoreSponsorBlockRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlock.Companion")))
@interface MealzcoreSponsorBlockCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlockCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockAttributes")))
@interface MealzcoreSponsorBlockAttributes : MealzcoreAttributes
- (instancetype)initWithPosition:(int32_t)position height:(int32_t)height width:(int32_t)width videoUrl:(NSString * _Nullable)videoUrl pictureUrl:(NSString * _Nullable)pictureUrl content:(NSString * _Nullable)content backgroundColor:(NSString * _Nullable)backgroundColor __attribute__((swift_name("init(position:height:width:videoUrl:pictureUrl:content:backgroundColor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorBlockAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreSponsorBlockAttributes *)doCopyPosition:(int32_t)position height:(int32_t)height width:(int32_t)width videoUrl:(NSString * _Nullable)videoUrl pictureUrl:(NSString * _Nullable)pictureUrl content:(NSString * _Nullable)content backgroundColor:(NSString * _Nullable)backgroundColor __attribute__((swift_name("doCopy(position:height:width:videoUrl:pictureUrl:content:backgroundColor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable backgroundColor __attribute__((swift_name("backgroundColor")));
@property (readonly) NSString * _Nullable content __attribute__((swift_name("content")));
@property (readonly) int32_t height __attribute__((swift_name("height")));
@property (readonly) NSString * _Nullable pictureUrl __attribute__((swift_name("pictureUrl")));
@property (readonly) int32_t position __attribute__((swift_name("position")));
@property (readonly) NSString * _Nullable videoUrl __attribute__((swift_name("videoUrl")));
@property (readonly) int32_t width __attribute__((swift_name("width")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockAttributes.Companion")))
@interface MealzcoreSponsorBlockAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlockAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockRelationshipName")))
@interface MealzcoreSponsorBlockRelationshipName : MealzcoreKotlinEnum<MealzcoreSponsorBlockRelationshipName *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreSponsorBlockRelationshipName *sponsorBlockType __attribute__((swift_name("sponsorBlockType")));
+ (MealzcoreKotlinArray<MealzcoreSponsorBlockRelationshipName *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreSponsorBlockRelationshipName *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *relationshipName __attribute__((swift_name("relationshipName")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockRelationships")))
@interface MealzcoreSponsorBlockRelationships : MealzcoreRelationships
- (instancetype)initWithSponsorBlockType:(MealzcoreSponsorBlockTypeRelationship * _Nullable)sponsorBlockType __attribute__((swift_name("init(sponsorBlockType:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorBlockRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property MealzcoreSponsorBlockTypeRelationship * _Nullable sponsorBlockType __attribute__((swift_name("sponsorBlockType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockRelationships.Companion")))
@interface MealzcoreSponsorBlockRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlockRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockType")))
@interface MealzcoreSponsorBlockType : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorBlockTypeCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreSponsorBlockType *)doCopyId:(NSString *)id attributes:(MealzcoreSponsorBlockTypeAttributes * _Nullable)attributes relationships:(MealzcoreSponsorBlockTypeRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreSponsorBlockTypeAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) MealzcoreSponsorBlockTypeRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockType.Companion")))
@interface MealzcoreSponsorBlockTypeCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlockTypeCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockTypeAttributes")))
@interface MealzcoreSponsorBlockTypeAttributes : MealzcoreAttributes
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorBlockTypeAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreSponsorBlockTypeAttributes *)doCopyName:(NSString *)name __attribute__((swift_name("doCopy(name:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockTypeAttributes.Companion")))
@interface MealzcoreSponsorBlockTypeAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlockTypeAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/SponsorBlockTypeSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockTypeRelationship")))
@interface MealzcoreSponsorBlockTypeRelationship : MealzcoreRelationship
- (instancetype)initWithData:(MealzcoreSponsorBlockType *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorBlockTypeRelationshipCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property MealzcoreSponsorBlockType *data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockTypeRelationship.Companion")))
@interface MealzcoreSponsorBlockTypeRelationshipCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlockTypeRelationshipCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockTypeRelationships")))
@interface MealzcoreSponsorBlockTypeRelationships : MealzcoreRelationships
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sponsorBlockTypeRelationships __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlockTypeRelationships *shared __attribute__((swift_name("shared")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MealzcoreKotlinArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializer(forClass=NormalClass(value=ai/mealz/core/model/SponsorBlockTypeRelationship))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockTypeSerializer")))
@interface MealzcoreSponsorBlockTypeSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sponsorBlockTypeSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlockTypeSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreSponsorBlockTypeRelationship *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreSponsorBlockTypeRelationship *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockTypesList")))
@interface MealzcoreSponsorBlockTypesList : MealzcoreKotlinEnum<MealzcoreSponsorBlockTypesList *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreSponsorBlockTypesList *title __attribute__((swift_name("title")));
@property (class, readonly) MealzcoreSponsorBlockTypesList *smallTitle __attribute__((swift_name("smallTitle")));
@property (class, readonly) MealzcoreSponsorBlockTypesList *picture __attribute__((swift_name("picture")));
@property (class, readonly) MealzcoreSponsorBlockTypesList *smallPicture __attribute__((swift_name("smallPicture")));
@property (class, readonly) MealzcoreSponsorBlockTypesList *logo __attribute__((swift_name("logo")));
@property (class, readonly) MealzcoreSponsorBlockTypesList *imageWithText __attribute__((swift_name("imageWithText")));
@property (class, readonly) MealzcoreSponsorBlockTypesList *imageAndText __attribute__((swift_name("imageAndText")));
@property (class, readonly) MealzcoreSponsorBlockTypesList *textAndImage __attribute__((swift_name("textAndImage")));
@property (class, readonly) MealzcoreSponsorBlockTypesList *text __attribute__((swift_name("text")));
@property (class, readonly) MealzcoreSponsorBlockTypesList *smallText __attribute__((swift_name("smallText")));
@property (class, readonly) MealzcoreSponsorBlockTypesList *video __attribute__((swift_name("video")));
+ (MealzcoreKotlinArray<MealzcoreSponsorBlockTypesList *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreSponsorBlockTypesList *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/SponsorBlocksSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlocksRelationships")))
@interface MealzcoreSponsorBlocksRelationships : MealzcoreRelationshipList
- (instancetype)initWithData:(NSArray<MealzcoreSponsorBlock *> *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorBlocksRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property NSArray<MealzcoreSponsorBlock *> *data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlocksRelationships.Companion")))
@interface MealzcoreSponsorBlocksRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlocksRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializer(forClass=NormalClass(value=ai/mealz/core/model/SponsorBlocksRelationships))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlocksSerializer")))
@interface MealzcoreSponsorBlocksSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sponsorBlocksSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlocksSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreSponsorBlocksRelationships *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreSponsorBlocksRelationships *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/SponsorListSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorListRelationship")))
@interface MealzcoreSponsorListRelationship : MealzcoreRelationshipList
- (instancetype)initWithData:(NSArray<MealzcoreSponsor *> *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorListRelationshipCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property NSArray<MealzcoreSponsor *> *data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorListRelationship.Companion")))
@interface MealzcoreSponsorListRelationshipCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorListRelationshipCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializer(forClass=NormalClass(value=ai/mealz/core/model/SponsorListRelationship))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorListSerializer")))
@interface MealzcoreSponsorListSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sponsorListSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorListSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreSponsorListRelationship *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreSponsorListRelationship *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorRelationshipName")))
@interface MealzcoreSponsorRelationshipName : MealzcoreKotlinEnum<MealzcoreSponsorRelationshipName *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreSponsorRelationshipName *sponsorBlock __attribute__((swift_name("sponsorBlock")));
+ (MealzcoreKotlinArray<MealzcoreSponsorRelationshipName *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreSponsorRelationshipName *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *relationshipName __attribute__((swift_name("relationshipName")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorRelationships")))
@interface MealzcoreSponsorRelationships : MealzcoreRelationships
- (instancetype)initWithSponsorBlocks:(MealzcoreSponsorBlocksRelationships * _Nullable)sponsorBlocks __attribute__((swift_name("init(sponsorBlocks:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSponsorRelationshipsCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property MealzcoreSponsorBlocksRelationships * _Nullable sponsorBlocks __attribute__((swift_name("sponsorBlocks")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorRelationships.Companion")))
@interface MealzcoreSponsorRelationshipsCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorRelationshipsCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StartTransferResponse")))
@interface MealzcoreStartTransferResponse : MealzcoreBase
- (instancetype)initWithTransferUrl:(NSString * _Nullable)transferUrl __attribute__((swift_name("init(transferUrl:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreStartTransferResponseCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreStartTransferResponse *)doCopyTransferUrl:(NSString * _Nullable)transferUrl __attribute__((swift_name("doCopy(transferUrl:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable transferUrl __attribute__((swift_name("transferUrl")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StartTransferResponse.Companion")))
@interface MealzcoreStartTransferResponseCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreStartTransferResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Store_")))
@interface MealzcoreStore : MealzcoreBase
- (instancetype)initWithMealzPointOfSaleIdentifier:(NSString *)mealzPointOfSaleIdentifier externalPointOfSaleIdentifier:(NSString *)externalPointOfSaleIdentifier name:(NSString * _Nullable)name address:(NSString * _Nullable)address __attribute__((swift_name("init(mealzPointOfSaleIdentifier:externalPointOfSaleIdentifier:name:address:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreStoreCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreStore *)doCopyMealzPointOfSaleIdentifier:(NSString *)mealzPointOfSaleIdentifier externalPointOfSaleIdentifier:(NSString *)externalPointOfSaleIdentifier name:(NSString * _Nullable)name address:(NSString * _Nullable)address __attribute__((swift_name("doCopy(mealzPointOfSaleIdentifier:externalPointOfSaleIdentifier:name:address:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable address __attribute__((swift_name("address")));
@property (readonly) NSString *externalPointOfSaleIdentifier __attribute__((swift_name("externalPointOfSaleIdentifier")));
@property (readonly) NSString *mealzPointOfSaleIdentifier __attribute__((swift_name("mealzPointOfSaleIdentifier")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Store_.Companion")))
@interface MealzcoreStoreCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreStoreCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SuggestionsCriteria")))
@interface MealzcoreSuggestionsCriteria : MealzcoreBase
- (instancetype)initWithShelfIngredientsIds:(NSArray<NSString *> * _Nullable)shelfIngredientsIds currentIngredientsIds:(NSArray<NSString *> * _Nullable)currentIngredientsIds basketIngredientsIds:(NSArray<NSString *> * _Nullable)basketIngredientsIds groupId:(NSString * _Nullable)groupId __attribute__((swift_name("init(shelfIngredientsIds:currentIngredientsIds:basketIngredientsIds:groupId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSuggestionsCriteriaCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreSuggestionsCriteria *)doCopyShelfIngredientsIds:(NSArray<NSString *> * _Nullable)shelfIngredientsIds currentIngredientsIds:(NSArray<NSString *> * _Nullable)currentIngredientsIds basketIngredientsIds:(NSArray<NSString *> * _Nullable)basketIngredientsIds groupId:(NSString * _Nullable)groupId __attribute__((swift_name("doCopy(shelfIngredientsIds:currentIngredientsIds:basketIngredientsIds:groupId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<NSString *> * _Nullable basketIngredientsIds __attribute__((swift_name("basketIngredientsIds")));
@property (readonly) NSArray<NSString *> * _Nullable currentIngredientsIds __attribute__((swift_name("currentIngredientsIds")));
@property (readonly) NSString * _Nullable groupId __attribute__((swift_name("groupId")));
@property (readonly) NSArray<NSString *> * _Nullable shelfIngredientsIds __attribute__((swift_name("shelfIngredientsIds")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SuggestionsCriteria.Companion")))
@interface MealzcoreSuggestionsCriteriaCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSuggestionsCriteriaCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Supplier")))
@interface MealzcoreSupplier : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSupplierCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreSupplier *)doCopyId:(NSString *)id attributes:(MealzcoreSupplierAttributes * _Nullable)attributes relationships:(MealzcoreSupplierRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreSupplierAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) MealzcoreSupplierRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Supplier.Companion")))
@interface MealzcoreSupplierCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSupplierCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SupplierAttributes")))
@interface MealzcoreSupplierAttributes : MealzcoreAttributes
- (instancetype)initWithName:(NSString * _Nullable)name logo:(NSString * _Nullable)logo languageId:(NSString * _Nullable)languageId __attribute__((swift_name("init(name:logo:languageId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSupplierAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreSupplierAttributes *)doCopyName:(NSString * _Nullable)name logo:(NSString * _Nullable)logo languageId:(NSString * _Nullable)languageId __attribute__((swift_name("doCopy(name:logo:languageId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable languageId __attribute__((swift_name("languageId")));
@property (readonly) NSString * _Nullable logo __attribute__((swift_name("logo")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SupplierAttributes.Companion")))
@interface MealzcoreSupplierAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSupplierAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SupplierNotificationWrapper")))
@interface MealzcoreSupplierNotificationWrapper : MealzcoreBase
- (instancetype)initWithToken:(NSString *)token status:(NSString *)status price:(NSString * _Nullable)price __attribute__((swift_name("init(token:status:price:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSupplierNotificationWrapperCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreSupplierNotificationWrapper *)doCopyToken:(NSString *)token status:(NSString *)status price:(NSString * _Nullable)price __attribute__((swift_name("doCopy(token:status:price:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable price __attribute__((swift_name("price")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SupplierNotificationWrapper.Companion")))
@interface MealzcoreSupplierNotificationWrapperCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSupplierNotificationWrapperCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SupplierProduct")))
@interface MealzcoreSupplierProduct : MealzcoreBase
- (instancetype)initWithId:(NSString *)id quantity:(int32_t)quantity name:(NSString * _Nullable)name productIdentifier:(NSString * _Nullable)productIdentifier imageURL:(NSString * _Nullable)imageURL __attribute__((swift_name("init(id:quantity:name:productIdentifier:imageURL:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreSupplierProduct *)doCopyId:(NSString *)id quantity:(int32_t)quantity name:(NSString * _Nullable)name productIdentifier:(NSString * _Nullable)productIdentifier imageURL:(NSString * _Nullable)imageURL __attribute__((swift_name("doCopy(id:quantity:name:productIdentifier:imageURL:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable imageURL __attribute__((swift_name("imageURL")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) NSString * _Nullable productIdentifier __attribute__((swift_name("productIdentifier")));
@property (readonly) int32_t quantity __attribute__((swift_name("quantity")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SupplierRelationships")))
@interface MealzcoreSupplierRelationships : MealzcoreRelationships
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)supplierRelationships __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSupplierRelationships *shared __attribute__((swift_name("shared")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MealzcoreKotlinArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Tag")))
@interface MealzcoreTag : MealzcoreRecord
- (instancetype)initWithId:(NSString *)id attributes:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)attributes json_relationships:(MealzcoreKotlinx_serialization_jsonJsonElement * _Nullable)json_relationships includedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("init(id:attributes:json_relationships:includedRecords:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreTagCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreTag *)doCopyId:(NSString *)id attributes:(MealzcoreTagAttributes * _Nullable)attributes relationships:(MealzcoreTagRelationships * _Nullable)relationships __attribute__((swift_name("doCopy(id:attributes:relationships:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreTagAttributes * _Nullable attributes __attribute__((swift_name("attributes")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) MealzcoreTagRelationships * _Nullable relationships __attribute__((swift_name("relationships")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Tag.Companion")))
@interface MealzcoreTagCompanion : MealzcoreAttributesField
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithT:(id<MealzcoreKotlinKClass>)t __attribute__((swift_name("init(t:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreTagCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TagAttributes")))
@interface MealzcoreTagAttributes : MealzcoreAttributes
- (instancetype)initWithTagTypeId:(NSString *)tagTypeId name:(NSString *)name iconUrl:(NSString * _Nullable)iconUrl pictureUrl:(NSString * _Nullable)pictureUrl __attribute__((swift_name("init(tagTypeId:name:iconUrl:pictureUrl:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreTagAttributesCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreTagAttributes *)doCopyTagTypeId:(NSString *)tagTypeId name:(NSString *)name iconUrl:(NSString * _Nullable)iconUrl pictureUrl:(NSString * _Nullable)pictureUrl __attribute__((swift_name("doCopy(tagTypeId:name:iconUrl:pictureUrl:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable iconUrl __attribute__((swift_name("iconUrl")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString * _Nullable pictureUrl __attribute__((swift_name("pictureUrl")));
@property (readonly) NSString *tagTypeId __attribute__((swift_name("tagTypeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TagAttributes.Companion")))
@interface MealzcoreTagAttributesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreTagAttributesCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializer(forClass=NormalClass(value=ai/mealz/core/model/TagListRelationship))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TagListListSerializer")))
@interface MealzcoreTagListListSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)tagListListSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreTagListListSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreTagListRelationship *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreTagListRelationship *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=ai/mealz/core/model/TagListListSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TagListRelationship")))
@interface MealzcoreTagListRelationship : MealzcoreRelationshipList
- (instancetype)initWithData:(NSArray<MealzcoreTag *> *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreTagListRelationshipCompanion *companion __attribute__((swift_name("companion")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
@property NSArray<MealzcoreTag *> *data __attribute__((swift_name("data")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TagListRelationship.Companion")))
@interface MealzcoreTagListRelationshipCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreTagListRelationshipCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TagRelationships")))
@interface MealzcoreTagRelationships : MealzcoreRelationships
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)tagRelationships __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreTagRelationships *shared __attribute__((swift_name("shared")));
- (void)buildFromIncludedIncludedRecords:(NSArray<MealzcoreRecord *> *)includedRecords __attribute__((swift_name("buildFromIncluded(includedRecords:)")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(MealzcoreKotlinArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TagTypes")))
@interface MealzcoreTagTypes : MealzcoreKotlinEnum<MealzcoreTagTypes *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreTagTypes *diet __attribute__((swift_name("diet")));
@property (class, readonly) MealzcoreTagTypes *ingredient __attribute__((swift_name("ingredient")));
@property (class, readonly) MealzcoreTagTypes *equipment __attribute__((swift_name("equipment")));
+ (MealzcoreKotlinArray<MealzcoreTagTypes *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreTagTypes *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryFakeFactory")))
@interface MealzcoreBasketEntryFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)basketEntryFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreBasketEntry *)createId:(NSString *)id attributes:(MealzcoreBasketEntryAttributes * _Nullable)attributes relationships:(MealzcoreBasketEntryRelationships * _Nullable)relationships __attribute__((swift_name("create(id:attributes:relationships:)")));
- (MealzcoreBasketEntryAttributes *)createAttributesSelectedItemId:(MealzcoreInt * _Nullable)selectedItemId quantity:(MealzcoreInt * _Nullable)quantity recipeIds:(NSArray<MealzcoreInt *> * _Nullable)recipeIds status:(NSString *)status name:(NSString *)name unitPrice:(double)unitPrice __attribute__((swift_name("createAttributes(selectedItemId:quantity:recipeIds:status:name:unitPrice:)")));
- (MealzcoreBasketEntry *)createBasketEntryWithSelectedIdSelectedItemId:(int32_t)selectedItemId recipeId:(MealzcoreInt * _Nullable)recipeId status:(NSString *)status __attribute__((swift_name("createBasketEntryWithSelectedId(selectedItemId:recipeId:status:)")));
- (MealzcoreBasketEntryRelationships *)createRelationshipsItems:(NSArray<MealzcoreItem *> * _Nullable)items selectedItem:(MealzcoreItem * _Nullable)selectedItem __attribute__((swift_name("createRelationships(items:selectedItem:)")));
@property (readonly) NSString *FAKE_ENTRY_ID __attribute__((swift_name("FAKE_ENTRY_ID")));
@property (readonly) double FAKE_UNIT_PRICE __attribute__((swift_name("FAKE_UNIT_PRICE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketFakeFactory")))
@interface MealzcoreBasketFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)basketFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreBasket *)createBasketId:(NSString *)id attributes:(MealzcoreBasketAttributes * _Nullable)attributes relationships:(MealzcoreBasketRelationships * _Nullable)relationships recipes:(NSArray<MealzcoreRecipe *> *)recipes __attribute__((swift_name("createBasket(id:attributes:relationships:recipes:)")));
- (MealzcoreBasketAttributes *)createBasketAttributesRecipeInfos:(NSMutableArray<MealzcoreRecipeInfos *> *)recipeInfos token:(NSString * _Nullable)token updatedAt:(NSString *)updatedAt __attribute__((swift_name("createBasketAttributes(recipeInfos:token:updatedAt:)")));
- (MealzcoreBasketRelationships *)createBasketRelationshipsBasketEntries:(NSArray<MealzcoreBasketEntry *> * _Nullable)basketEntries __attribute__((swift_name("createBasketRelationships(basketEntries:)")));
- (MealzcoreBasket *)createBasketWithRecipeRecipeId:(NSString *)recipeId guests:(int32_t)guests __attribute__((swift_name("createBasketWithRecipe(recipeId:guests:)")));
- (MealzcoreBasket *)createBasketWithRecipeAndEntriesRecipeId:(NSString *)recipeId guests:(int32_t)guests basketEntries:(NSArray<MealzcoreBasketEntry *> *)basketEntries __attribute__((swift_name("createBasketWithRecipeAndEntries(recipeId:guests:basketEntries:)")));
@property (readonly) NSString *FAKE_BASKET_ID __attribute__((swift_name("FAKE_BASKET_ID")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IngredientFakeFactory")))
@interface MealzcoreIngredientFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)ingredientFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreIngredientFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreIngredient *)createId:(NSString *)id attributes:(MealzcoreIngredientAttributes * _Nullable)attributes relationships:(MealzcoreIngredientRelationships * _Nullable)relationships __attribute__((swift_name("create(id:attributes:relationships:)")));
- (MealzcoreIngredientAttributes *)createAttributesName:(NSString *)name __attribute__((swift_name("createAttributes(name:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemFakeFactory")))
@interface MealzcoreItemFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)itemFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreItem *)createId:(NSString *)id attributes:(MealzcoreItemAttributes * _Nullable)attributes relationships:(MealzcoreItemRelationships * _Nullable)relationships __attribute__((swift_name("create(id:attributes:relationships:)")));
- (MealzcoreItemAttributes *)createAttributesName:(NSString *)name unitPrice:(MealzcoreDouble * _Nullable)unitPrice __attribute__((swift_name("createAttributes(name:unitPrice:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@property (readonly) NSString *FAKE_NAME __attribute__((swift_name("FAKE_NAME")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PackageFakeFactory")))
@interface MealzcorePackageFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)packageFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePackageFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcorePackage *)createId:(NSString *)id attributes:(MealzcorePackageAttributes * _Nullable)attributes relationships:(MealzcorePackageRelationships * _Nullable)relationships __attribute__((swift_name("create(id:attributes:relationships:)")));
- (MealzcorePackageAttributes *)createAttributesTitle:(NSString *)title __attribute__((swift_name("createAttributes(title:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@property (readonly) NSString *FAKE_TITLE __attribute__((swift_name("FAKE_TITLE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PointOfSaleFakeFactory")))
@interface MealzcorePointOfSaleFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)pointOfSaleFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePointOfSaleFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcorePointOfSale *)createId:(NSString *)id __attribute__((swift_name("create(id:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeFakeFactory")))
@interface MealzcoreRecipeFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreRecipe *)createIdAsInt:(int32_t)idAsInt attributes:(MealzcoreRecipeAttributes * _Nullable)attributes relationships:(MealzcoreRecipeRelationships * _Nullable)relationships __attribute__((swift_name("create(idAsInt:attributes:relationships:)")));
- (MealzcoreRecipe *)createId:(NSString *)id attributes:(MealzcoreRecipeAttributes * _Nullable)attributes relationships:(MealzcoreRecipeRelationships * _Nullable)relationships __attribute__((swift_name("create(id:attributes:relationships:)")));
- (MealzcoreRecipeAttributes *)createAdvancedAttributes __attribute__((swift_name("createAdvancedAttributes()")));
- (MealzcoreRecipeAttributes *)createAttributesTitle:(NSString *)title mediaUrl:(NSString *)mediaUrl __attribute__((swift_name("createAttributes(title:mediaUrl:)")));
- (MealzcoreRecipeRelationships *)createRelationshipsIngredients:(MealzcoreIngredientListRelationship *)ingredients __attribute__((swift_name("createRelationships(ingredients:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@property (readonly) NSString *FAKE_TITLE __attribute__((swift_name("FAKE_TITLE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeLikeFakeFactory")))
@interface MealzcoreRecipeLikeFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeLikeFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeLikeFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreRecipeLike *)createId:(NSString *)id attributes:(MealzcoreRecipeLikeAttributes * _Nullable)attributes relationships:(MealzcoreRecipeLikeRelationships * _Nullable)relationships __attribute__((swift_name("create(id:attributes:relationships:)")));
- (MealzcoreRecipeLikeAttributes *)createAttributesIsPast:(BOOL)isPast recipeId:(int32_t)recipeId __attribute__((swift_name("createAttributes(isPast:recipeId:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@property (readonly) NSString *FAKE_TITLE __attribute__((swift_name("FAKE_TITLE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeStepFakeFactory")))
@interface MealzcoreRecipeStepFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeStepFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeStepFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreRecipeStep *)createId:(NSString *)id attributes:(MealzcoreRecipeStepAttributes * _Nullable)attributes relationships:(MealzcoreRecipeStepRelationships * _Nullable)relationships __attribute__((swift_name("create(id:attributes:relationships:)")));
- (MealzcoreRecipeStepAttributes *)createAttributesStepNumber:(int32_t)stepNumber title:(NSString *)title stepDescription:(NSString * _Nullable)stepDescription mediaUrl:(NSString * _Nullable)mediaUrl __attribute__((swift_name("createAttributes(stepNumber:title:stepDescription:mediaUrl:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@property (readonly) NSString *FAKE_TITLE __attribute__((swift_name("FAKE_TITLE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockFakeFactory")))
@interface MealzcoreSponsorBlockFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sponsorBlockFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlockFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreSponsorBlock *)createId:(NSString *)id attributes:(MealzcoreSponsorBlockAttributes * _Nullable)attributes relationships:(MealzcoreSponsorBlockRelationships * _Nullable)relationships __attribute__((swift_name("create(id:attributes:relationships:)")));
- (MealzcoreSponsorBlockAttributes *)createAttributesPosition:(int32_t)position height:(int32_t)height width:(int32_t)width videoUrl:(NSString * _Nullable)videoUrl pictureUrl:(NSString * _Nullable)pictureUrl content:(NSString * _Nullable)content backgroundColor:(NSString * _Nullable)backgroundColor __attribute__((swift_name("createAttributes(position:height:width:videoUrl:pictureUrl:content:backgroundColor:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@property (readonly) NSString *FAKE_NAME __attribute__((swift_name("FAKE_NAME")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorBlockTypeFakeFactory")))
@interface MealzcoreSponsorBlockTypeFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sponsorBlockTypeFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorBlockTypeFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreSponsorBlockType *)createId:(NSString *)id attributes:(MealzcoreSponsorBlockTypeAttributes * _Nullable)attributes relationships:(MealzcoreSponsorBlockTypeRelationships * _Nullable)relationships __attribute__((swift_name("create(id:attributes:relationships:)")));
- (MealzcoreSponsorBlockTypeAttributes *)createAttributesName:(NSString *)name __attribute__((swift_name("createAttributes(name:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@property (readonly) NSString *FAKE_NAME __attribute__((swift_name("FAKE_NAME")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorFakeFactory")))
@interface MealzcoreSponsorFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)sponsorFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSponsorFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreSponsor *)createId:(NSString *)id attributes:(MealzcoreSponsorAttributes * _Nullable)attributes relationships:(MealzcoreSponsorRelationships * _Nullable)relationships __attribute__((swift_name("create(id:attributes:relationships:)")));
- (MealzcoreSponsorAttributes *)createAttributesName:(NSString *)name logoUrl:(NSString *)logoUrl __attribute__((swift_name("createAttributes(name:logoUrl:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@property (readonly) NSString *FAKE_NAME __attribute__((swift_name("FAKE_NAME")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SupplierFakeFactory")))
@interface MealzcoreSupplierFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)supplierFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSupplierFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreSupplier *)createId:(NSString *)id attributes:(MealzcoreSupplierAttributes * _Nullable)attributes __attribute__((swift_name("create(id:attributes:)")));
- (MealzcoreSupplierAttributes *)createAttributes __attribute__((swift_name("createAttributes()")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TagFakeFactory")))
@interface MealzcoreTagFakeFactory : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)tagFakeFactory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreTagFakeFactory *shared __attribute__((swift_name("shared")));
- (MealzcoreTag *)createId:(NSString *)id attributes:(MealzcoreTagAttributes * _Nullable)attributes __attribute__((swift_name("create(id:attributes:)")));
- (MealzcoreTagAttributes *)createAttributesName:(NSString *)name __attribute__((swift_name("createAttributes(name:)")));
@property (readonly) NSString *FAKE_ID __attribute__((swift_name("FAKE_ID")));
@property (readonly) NSString *FAKE_NAME __attribute__((swift_name("FAKE_NAME")));
@end

__attribute__((swift_name("ItemSelectorNavigationData")))
@interface MealzcoreItemSelectorNavigationData : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@property (readonly) void (^updateProductFromItemSelector)(MealzcoreItem *) __attribute__((swift_name("updateProductFromItemSelector")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorWithBasketEntryNavigationData")))
@interface MealzcoreItemSelectorWithBasketEntryNavigationData : MealzcoreItemSelectorNavigationData
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry updateProductFromItemSelector:(void (^)(MealzcoreItem *))updateProductFromItemSelector __attribute__((swift_name("init(basketEntry:updateProductFromItemSelector:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (MealzcoreItemSelectorWithBasketEntryNavigationData *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry updateProductFromItemSelector:(void (^)(MealzcoreItem *))updateProductFromItemSelector __attribute__((swift_name("doCopy(basketEntry:updateProductFromItemSelector:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@property (readonly) void (^updateProductFromItemSelector)(MealzcoreItem *) __attribute__((swift_name("updateProductFromItemSelector")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorWithIngredientNavigationData")))
@interface MealzcoreItemSelectorWithIngredientNavigationData : MealzcoreItemSelectorNavigationData
- (instancetype)initWithRecipeId:(NSString *)recipeId ingredientId:(NSString *)ingredientId ingredientName:(NSString *)ingredientName ingredientQuantity:(float)ingredientQuantity ingredientUnit:(NSString *)ingredientUnit guestCount:(int32_t)guestCount defaultRecipeGuest:(int32_t)defaultRecipeGuest basketEntry:(MealzcoreBasketEntry *)basketEntry isASubstitution:(BOOL)isASubstitution updateProductFromItemSelector:(void (^)(MealzcoreItem *))updateProductFromItemSelector __attribute__((swift_name("init(recipeId:ingredientId:ingredientName:ingredientQuantity:ingredientUnit:guestCount:defaultRecipeGuest:basketEntry:isASubstitution:updateProductFromItemSelector:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (MealzcoreItemSelectorWithIngredientNavigationData *)doCopyRecipeId:(NSString *)recipeId ingredientId:(NSString *)ingredientId ingredientName:(NSString *)ingredientName ingredientQuantity:(float)ingredientQuantity ingredientUnit:(NSString *)ingredientUnit guestCount:(int32_t)guestCount defaultRecipeGuest:(int32_t)defaultRecipeGuest basketEntry:(MealzcoreBasketEntry *)basketEntry isASubstitution:(BOOL)isASubstitution updateProductFromItemSelector:(void (^)(MealzcoreItem *))updateProductFromItemSelector __attribute__((swift_name("doCopy(recipeId:ingredientId:ingredientName:ingredientQuantity:ingredientUnit:guestCount:defaultRecipeGuest:basketEntry:isASubstitution:updateProductFromItemSelector:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@property (readonly) int32_t defaultRecipeGuest __attribute__((swift_name("defaultRecipeGuest")));
@property (readonly) int32_t guestCount __attribute__((swift_name("guestCount")));
@property (readonly) NSString *ingredientId __attribute__((swift_name("ingredientId")));
@property (readonly) NSString *ingredientName __attribute__((swift_name("ingredientName")));
@property (readonly) float ingredientQuantity __attribute__((swift_name("ingredientQuantity")));
@property (readonly) NSString *ingredientUnit __attribute__((swift_name("ingredientUnit")));
@property (readonly) BOOL isASubstitution __attribute__((swift_name("isASubstitution")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@property (readonly) void (^updateProductFromItemSelector)(MealzcoreItem *) __attribute__((swift_name("updateProductFromItemSelector")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CustomDateSerializer")))
@interface MealzcoreCustomDateSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)customDateSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreCustomDateSerializer *shared __attribute__((swift_name("shared")));
- (NSString *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(NSString *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CustomDurationSerializer")))
@interface MealzcoreCustomDurationSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)customDurationSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreCustomDurationSerializer *shared __attribute__((swift_name("shared")));
- (id)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(id)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DiscountTypeSerializer")))
@interface MealzcoreDiscountTypeSerializer : MealzcoreBase <MealzcoreKotlinx_serialization_coreKSerializer>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)discountTypeSerializer __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreDiscountTypeSerializer *shared __attribute__((swift_name("shared")));
- (MealzcoreDiscountType *)deserializeDecoder:(id<MealzcoreKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<MealzcoreKotlinx_serialization_coreEncoder>)encoder value:(MealzcoreDiscountType *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<MealzcoreKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Retailer")))
@interface MealzcoreRetailer : MealzcoreBase
- (instancetype)initWithRetailerId:(NSString *)retailerId retailerName:(NSString * _Nullable)retailerName retailerLogoUrl:(NSString * _Nullable)retailerLogoUrl __attribute__((swift_name("init(retailerId:retailerName:retailerLogoUrl:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreRetailerCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreRetailer *)doCopyRetailerId:(NSString *)retailerId retailerName:(NSString * _Nullable)retailerName retailerLogoUrl:(NSString * _Nullable)retailerLogoUrl __attribute__((swift_name("doCopy(retailerId:retailerName:retailerLogoUrl:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *retailerId __attribute__((swift_name("retailerId")));
@property (readonly) NSString * _Nullable retailerLogoUrl __attribute__((swift_name("retailerLogoUrl")));
@property (readonly) NSString * _Nullable retailerName __attribute__((swift_name("retailerName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Retailer.Companion")))
@interface MealzcoreRetailerCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRetailerCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("Notifier")))
@protocol MealzcoreNotifier
@required
- (id<MealzcoreKotlinx_coroutines_coreJob>)listenCallBack:(void (^)(id _Nullable))callBack __attribute__((swift_name("listen(callBack:)")));
- (id<MealzcoreKotlinx_coroutines_coreJob>)listenWithDebounceDebounceTime:(int64_t)debounceTime callBack:(void (^)(id _Nullable))callBack __attribute__((swift_name("listenWithDebounce(debounceTime:callBack:)")));
- (void)pushNotification:(id _Nullable)notification __attribute__((swift_name("push(notification:)")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableSharedFlow> _notificationFlow __attribute__((swift_name("_notificationFlow")));
@end

__attribute__((swift_name("AbstractNotifier")))
@interface MealzcoreAbstractNotifier<T1> : MealzcoreBase <MealzcoreNotifier, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<MealzcoreKotlinx_coroutines_coreJob>)listenCallBack:(void (^)(T1 _Nullable))callBack __attribute__((swift_name("listen(callBack:)")));
- (id<MealzcoreKotlinx_coroutines_coreJob>)listenWithDebounceDebounceTime:(int64_t)debounceTime callBack:(void (^)(T1 _Nullable))callBack __attribute__((swift_name("listenWithDebounce(debounceTime:callBack:)")));
- (void)pushNotification:(T1 _Nullable)notification __attribute__((swift_name("push(notification:)")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableSharedFlow> _notificationFlow __attribute__((swift_name("_notificationFlow")));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreCoroutineExceptionHandler> coroutineHandler __attribute__((swift_name("coroutineHandler")));
@end

__attribute__((swift_name("BasketNotification")))
@interface MealzcoreBasketNotification : MealzcoreBase
@property (readonly) MealzcoreBasketEntry * _Nullable basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.BasketConfirmed")))
@interface MealzcoreBasketNotificationBasketConfirmed : MealzcoreBasketNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)basketConfirmed __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketNotificationBasketConfirmed *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.BasketInit")))
@interface MealzcoreBasketNotificationBasketInit : MealzcoreBasketNotification
- (instancetype)initWithBasket:(MealzcoreBasket *)basket __attribute__((swift_name("init(basket:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationBasketInit *)doCopyBasket:(MealzcoreBasket *)basket __attribute__((swift_name("doCopy(basket:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasket *basket __attribute__((swift_name("basket")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.BasketReloaded")))
@interface MealzcoreBasketNotificationBasketReloaded : MealzcoreBasketNotification
- (instancetype)initWithBasket:(MealzcoreBasket *)basket __attribute__((swift_name("init(basket:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationBasketReloaded *)doCopyBasket:(MealzcoreBasket *)basket __attribute__((swift_name("doCopy(basket:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasket *basket __attribute__((swift_name("basket")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.BasketReset")))
@interface MealzcoreBasketNotificationBasketReset : MealzcoreBasketNotification
- (instancetype)initWithBasket:(MealzcoreBasket *)basket __attribute__((swift_name("init(basket:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationBasketReset *)doCopyBasket:(MealzcoreBasket *)basket __attribute__((swift_name("doCopy(basket:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasket *basket __attribute__((swift_name("basket")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.BasketUpdated")))
@interface MealzcoreBasketNotificationBasketUpdated : MealzcoreBasketNotification
- (instancetype)initWithBasket:(MealzcoreBasket *)basket __attribute__((swift_name("init(basket:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationBasketUpdated *)doCopyBasket:(MealzcoreBasket *)basket __attribute__((swift_name("doCopy(basket:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasket *basket __attribute__((swift_name("basket")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.BasketUpdating")))
@interface MealzcoreBasketNotificationBasketUpdating : MealzcoreBasketNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)basketUpdating __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketNotificationBasketUpdating *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.ComparatorIsReady")))
@interface MealzcoreBasketNotificationComparatorIsReady : MealzcoreBasketNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)comparatorIsReady __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketNotificationComparatorIsReady *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.ComparatorIsReset")))
@interface MealzcoreBasketNotificationComparatorIsReset : MealzcoreBasketNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)comparatorIsReset __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketNotificationComparatorIsReset *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.EntriesAltered")))
@interface MealzcoreBasketNotificationEntriesAltered : MealzcoreBasketNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)entriesAltered __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketNotificationEntriesAltered *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.EntryAdded")))
@interface MealzcoreBasketNotificationEntryAdded : MealzcoreBasketNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationEntryAdded *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.EntryItemReplaced")))
@interface MealzcoreBasketNotificationEntryItemReplaced : MealzcoreBasketNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationEntryItemReplaced *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.EntryQuantityUpdated")))
@interface MealzcoreBasketNotificationEntryQuantityUpdated : MealzcoreBasketNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationEntryQuantityUpdated *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.EntryRemoved")))
@interface MealzcoreBasketNotificationEntryRemoved : MealzcoreBasketNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationEntryRemoved *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.RecipeCountChanged")))
@interface MealzcoreBasketNotificationRecipeCountChanged : MealzcoreBasketNotification
- (instancetype)initWithRecipeCount:(int32_t)recipeCount __attribute__((swift_name("init(recipeCount:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationRecipeCountChanged *)doCopyRecipeCount:(int32_t)recipeCount __attribute__((swift_name("doCopy(recipeCount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t recipeCount __attribute__((swift_name("recipeCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.RecipesAdded")))
@interface MealzcoreBasketNotificationRecipesAdded : MealzcoreBasketNotification
- (instancetype)initWithBasket:(MealzcoreBasket *)basket __attribute__((swift_name("init(basket:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationRecipesAdded *)doCopyBasket:(MealzcoreBasket *)basket __attribute__((swift_name("doCopy(basket:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasket *basket __attribute__((swift_name("basket")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.RecipesRemoved")))
@interface MealzcoreBasketNotificationRecipesRemoved : MealzcoreBasketNotification
- (instancetype)initWithBasket:(MealzcoreBasket *)basket __attribute__((swift_name("init(basket:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationRecipesRemoved *)doCopyBasket:(MealzcoreBasket *)basket __attribute__((swift_name("doCopy(basket:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasket *basket __attribute__((swift_name("basket")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketNotification.RecipesUpdated")))
@interface MealzcoreBasketNotificationRecipesUpdated : MealzcoreBasketNotification
- (instancetype)initWithBasket:(MealzcoreBasket *)basket __attribute__((swift_name("init(basket:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketNotificationRecipesUpdated *)doCopyBasket:(MealzcoreBasket *)basket __attribute__((swift_name("doCopy(basket:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasket *basket __attribute__((swift_name("basket")));
@end

__attribute__((swift_name("MealPlannerBasketPreviewNotification")))
@interface MealzcoreMealPlannerBasketPreviewNotification : MealzcoreBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerBasketPreviewNotification.RecipeProductMutualizedAsChange")))
@interface MealzcoreMealPlannerBasketPreviewNotificationRecipeProductMutualizedAsChange : MealzcoreMealPlannerBasketPreviewNotification
- (instancetype)initWithRecipeId:(NSString *)recipeId basketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(recipeId:basketEntry:)"))) __attribute__((objc_designated_initializer));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerBasketPreviewNotification.RecipeRowDeleted")))
@interface MealzcoreMealPlannerBasketPreviewNotificationRecipeRowDeleted : MealzcoreMealPlannerBasketPreviewNotification
- (instancetype)initWithRecipeId:(NSString *)recipeId __attribute__((swift_name("init(recipeId:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerBasketPreviewNotification.RecipeRowLoading")))
@interface MealzcoreMealPlannerBasketPreviewNotificationRecipeRowLoading : MealzcoreMealPlannerBasketPreviewNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeRowLoading __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealPlannerBasketPreviewNotificationRecipeRowLoading *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerBasketPreviewNotification.RecipeRowReady")))
@interface MealzcoreMealPlannerBasketPreviewNotificationRecipeRowReady : MealzcoreMealPlannerBasketPreviewNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeRowReady __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealPlannerBasketPreviewNotificationRecipeRowReady *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("PointOfSaleNotification")))
@interface MealzcorePointOfSaleNotification : MealzcoreBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PointOfSaleNotification.PosChange")))
@interface MealzcorePointOfSaleNotificationPosChange : MealzcorePointOfSaleNotification
- (instancetype)initWithPosId:(NSString *)PosId PosName:(NSString *)PosName __attribute__((swift_name("init(PosId:PosName:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *PosId __attribute__((swift_name("PosId")));
@property (readonly) NSString *PosName __attribute__((swift_name("PosName")));
@end

__attribute__((swift_name("PreferencesNotification")))
@interface MealzcorePreferencesNotification : MealzcoreBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PreferencesNotification.PreferencesLoaded")))
@interface MealzcorePreferencesNotificationPreferencesLoaded : MealzcorePreferencesNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)preferencesLoaded __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePreferencesNotificationPreferencesLoaded *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PreferencesNotification.PreferencesUpdated")))
@interface MealzcorePreferencesNotificationPreferencesUpdated : MealzcorePreferencesNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)preferencesUpdated __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePreferencesNotificationPreferencesUpdated *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("BasketEntryNotification")))
@interface MealzcoreBasketEntryNotification : MealzcoreBase
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryNotification.BasketEntryAdded")))
@interface MealzcoreBasketEntryNotificationBasketEntryAdded : MealzcoreBasketEntryNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketEntryNotificationBasketEntryAdded *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryNotification.BasketEntryQtyUpdated")))
@interface MealzcoreBasketEntryNotificationBasketEntryQtyUpdated : MealzcoreBasketEntryNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketEntryNotificationBasketEntryQtyUpdated *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryNotification.BasketEntryRemoved")))
@interface MealzcoreBasketEntryNotificationBasketEntryRemoved : MealzcoreBasketEntryNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketEntryNotificationBasketEntryRemoved *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryNotification.BasketEntryReplaced")))
@interface MealzcoreBasketEntryNotificationBasketEntryReplaced : MealzcoreBasketEntryNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketEntryNotificationBasketEntryReplaced *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryNotification.ChildReady")))
@interface MealzcoreBasketEntryNotificationChildReady : MealzcoreBasketEntryNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketEntryNotificationChildReady *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryNotification.GoToItemSelector")))
@interface MealzcoreBasketEntryNotificationGoToItemSelector : MealzcoreBasketEntryNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketEntryNotificationGoToItemSelector *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryNotification.GoToItemSelectorForRecipe")))
@interface MealzcoreBasketEntryNotificationGoToItemSelectorForRecipe : MealzcoreBasketEntryNotification
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry ingredientId:(NSString *)ingredientId __attribute__((swift_name("init(basketEntry:ingredientId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketEntryNotificationGoToItemSelectorForRecipe *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry ingredientId:(NSString *)ingredientId __attribute__((swift_name("doCopy(basketEntry:ingredientId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@property (readonly) NSString *ingredientId __attribute__((swift_name("ingredientId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryNotifier")))
@interface MealzcoreBasketEntryNotifier : MealzcoreAbstractNotifier<MealzcoreBasketEntryNotification *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreCoroutineExceptionHandler> coroutineHandler __attribute__((swift_name("coroutineHandler")));
@end

__attribute__((swift_name("ToasterNotification")))
@interface MealzcoreToasterNotification : MealzcoreBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ToasterNotification.RecipeAdded")))
@interface MealzcoreToasterNotificationRecipeAdded : MealzcoreToasterNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeAdded __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreToasterNotificationRecipeAdded *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ToasterNotification.RecipeLiked")))
@interface MealzcoreToasterNotificationRecipeLiked : MealzcoreToasterNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)recipeLiked __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreToasterNotificationRecipeLiked *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ToasterNotifier")))
@interface MealzcoreToasterNotifier : MealzcoreAbstractNotifier<MealzcoreToasterNotification *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreCoroutineExceptionHandler> coroutineHandler __attribute__((swift_name("coroutineHandler")));
@end

__attribute__((swift_name("UserNotification")))
@interface MealzcoreUserNotification : MealzcoreBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserNotification.TokenExpired")))
@interface MealzcoreUserNotificationTokenExpired : MealzcoreUserNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)tokenExpired __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreUserNotificationTokenExpired *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserNotification.UserConnected")))
@interface MealzcoreUserNotificationUserConnected : MealzcoreUserNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)userConnected __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreUserNotificationUserConnected *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserNotification.UserDisconnected")))
@interface MealzcoreUserNotificationUserDisconnected : MealzcoreUserNotification
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)userDisconnected __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreUserNotificationUserDisconnected *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserNotifier")))
@interface MealzcoreUserNotifier : MealzcoreAbstractNotifier<MealzcoreUserNotification *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreCoroutineExceptionHandler> coroutineHandler __attribute__((swift_name("coroutineHandler")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealzImages")))
@interface MealzcoreMealzImages : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mealzImages __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreMealzImages *shared __attribute__((swift_name("shared")));
- (MealzcoreResourcesImageResource *)getImageWithFileNameFileName:(NSString *)fileName __attribute__((swift_name("getImageWithFileName(fileName:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AnalyticEvent")))
@interface MealzcoreAnalyticEvent : MealzcoreBase
- (instancetype)initWithEventType:(NSString *)eventType path:(NSString *)path props:(MealzcoreAnalyticsPlausibleProps *)props __attribute__((swift_name("init(eventType:path:props:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreAnalyticEvent *)doCopyEventType:(NSString *)eventType path:(NSString *)path props:(MealzcoreAnalyticsPlausibleProps *)props __attribute__((swift_name("doCopy(eventType:path:props:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *eventType __attribute__((swift_name("eventType")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@property (readonly) MealzcoreAnalyticsPlausibleProps *props __attribute__((swift_name("props")));
@end

__attribute__((swift_name("Analytics")))
@protocol MealzcoreAnalytics
@required
- (void)emitEventEvent:(MealzcoreAnalyticEvent *)event __attribute__((swift_name("emitEvent(event:)")));
- (void)emitEventEvent_:(MealzcoreAnalyticsEvent *)event __attribute__((swift_name("emitEvent(event_:)")));
- (void)doInitSupplierOrigin:(NSString *)supplierOrigin __attribute__((swift_name("doInit(supplierOrigin:)")));
- (void)sendEventName:(NSString *)name path:(NSString *)path props:(MealzcoreMutableDictionary<NSString *, id> *)props __attribute__((swift_name("sendEvent(name:path:props:)")));
@property NSString *currentPath __attribute__((swift_name("currentPath")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AnalyticsPlausiblePaths")))
@interface MealzcoreAnalyticsPlausiblePaths : MealzcoreKotlinEnum<MealzcoreAnalyticsPlausiblePaths *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *basketPreview __attribute__((swift_name("basketPreview")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *preferences __attribute__((swift_name("preferences")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *recipes __attribute__((swift_name("recipes")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *categories __attribute__((swift_name("categories")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *myMeals __attribute__((swift_name("myMeals")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *myProducts __attribute__((swift_name("myProducts")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *recipeSponsor __attribute__((swift_name("recipeSponsor")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *recipeMealPlanner __attribute__((swift_name("recipeMealPlanner")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *recipeMealPlannerResult __attribute__((swift_name("recipeMealPlannerResult")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *recipeMealPlannerCatalog __attribute__((swift_name("recipeMealPlannerCatalog")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *recipeMealPlannerBasketPreview __attribute__((swift_name("recipeMealPlannerBasketPreview")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *recipeMealPlannerFinalize __attribute__((swift_name("recipeMealPlannerFinalize")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *storeLocator __attribute__((swift_name("storeLocator")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *recipeSearch __attribute__((swift_name("recipeSearch")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *orders __attribute__((swift_name("orders")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *favorites __attribute__((swift_name("favorites")));
@property (class, readonly) MealzcoreAnalyticsPlausiblePaths *filter __attribute__((swift_name("filter")));
+ (MealzcoreKotlinArray<MealzcoreAnalyticsPlausiblePaths *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreAnalyticsPlausiblePaths *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AnalyticsPlausibleProps")))
@interface MealzcoreAnalyticsPlausibleProps : MealzcoreBase
- (instancetype)initWithProps:(NSDictionary<NSString *, id> *)props __attribute__((swift_name("init(props:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithRecipe_id:(NSString * _Nullable)recipe_id category_id:(NSString * _Nullable)category_id entry_name:(NSString * _Nullable)entry_name basket_id:(NSString * _Nullable)basket_id miam_amount:(MealzcoreFloat * _Nullable)miam_amount total_amount:(NSString * _Nullable)total_amount pos_id:(NSString * _Nullable)pos_id pos_total_amount:(NSString * _Nullable)pos_total_amount pos_name:(NSString * _Nullable)pos_name search_term:(NSString * _Nullable)search_term uses_count:(NSString * _Nullable)uses_count time_passed:(NSString * _Nullable)time_passed budget_user:(NSString * _Nullable)budget_user budget_planner:(NSString * _Nullable)budget_planner recipe_count:(NSString * _Nullable)recipe_count query:(NSString * _Nullable)query guests:(NSString * _Nullable)guests item_id:(NSString * _Nullable)item_id item_ean:(NSString * _Nullable)item_ean user_preference:(NSString * _Nullable)user_preference old_item_id:(NSString * _Nullable)old_item_id old_item_ean:(NSString * _Nullable)old_item_ean new_item_id:(NSString * _Nullable)new_item_id new_item_ean:(NSString * _Nullable)new_item_ean recipe_item_id:(NSString * _Nullable)recipe_item_id diff:(NSString * _Nullable)diff from_miam:(MealzcoreBoolean * _Nullable)from_miam miam_products:(MealzcoreInt * _Nullable)miam_products total_products:(MealzcoreInt * _Nullable)total_products product_quantity:(MealzcoreInt * _Nullable)product_quantity client_order_id:(NSString * _Nullable)client_order_id version:(NSString * _Nullable)version device:(NSString * _Nullable)device __attribute__((swift_name("init(recipe_id:category_id:entry_name:basket_id:miam_amount:total_amount:pos_id:pos_total_amount:pos_name:search_term:uses_count:time_passed:budget_user:budget_planner:recipe_count:query:guests:item_id:item_ean:user_preference:old_item_id:old_item_ean:new_item_id:new_item_ean:recipe_item_id:diff:from_miam:miam_products:total_products:product_quantity:client_order_id:version:device:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreAnalyticsPlausibleProps *)doCopyRecipe_id:(NSString * _Nullable)recipe_id category_id:(NSString * _Nullable)category_id entry_name:(NSString * _Nullable)entry_name basket_id:(NSString * _Nullable)basket_id miam_amount:(MealzcoreFloat * _Nullable)miam_amount total_amount:(NSString * _Nullable)total_amount pos_id:(NSString * _Nullable)pos_id pos_total_amount:(NSString * _Nullable)pos_total_amount pos_name:(NSString * _Nullable)pos_name search_term:(NSString * _Nullable)search_term uses_count:(NSString * _Nullable)uses_count time_passed:(NSString * _Nullable)time_passed budget_user:(NSString * _Nullable)budget_user budget_planner:(NSString * _Nullable)budget_planner recipe_count:(NSString * _Nullable)recipe_count query:(NSString * _Nullable)query guests:(NSString * _Nullable)guests item_id:(NSString * _Nullable)item_id item_ean:(NSString * _Nullable)item_ean user_preference:(NSString * _Nullable)user_preference old_item_id:(NSString * _Nullable)old_item_id old_item_ean:(NSString * _Nullable)old_item_ean new_item_id:(NSString * _Nullable)new_item_id new_item_ean:(NSString * _Nullable)new_item_ean recipe_item_id:(NSString * _Nullable)recipe_item_id diff:(NSString * _Nullable)diff from_miam:(MealzcoreBoolean * _Nullable)from_miam miam_products:(MealzcoreInt * _Nullable)miam_products total_products:(MealzcoreInt * _Nullable)total_products product_quantity:(MealzcoreInt * _Nullable)product_quantity client_order_id:(NSString * _Nullable)client_order_id version:(NSString * _Nullable)version device:(NSString * _Nullable)device __attribute__((swift_name("doCopy(recipe_id:category_id:entry_name:basket_id:miam_amount:total_amount:pos_id:pos_total_amount:pos_name:search_term:uses_count:time_passed:budget_user:budget_planner:recipe_count:query:guests:item_id:item_ean:user_preference:old_item_id:old_item_ean:new_item_id:new_item_ean:recipe_item_id:diff:from_miam:miam_products:total_products:product_quantity:client_order_id:version:device:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable basket_id __attribute__((swift_name("basket_id")));
@property (readonly) NSString * _Nullable budget_planner __attribute__((swift_name("budget_planner")));
@property (readonly) NSString * _Nullable budget_user __attribute__((swift_name("budget_user")));
@property (readonly) NSString * _Nullable category_id __attribute__((swift_name("category_id")));
@property (readonly) NSString * _Nullable client_order_id __attribute__((swift_name("client_order_id")));
@property (readonly) NSString * _Nullable device __attribute__((swift_name("device")));
@property (readonly) NSString * _Nullable diff __attribute__((swift_name("diff")));
@property (readonly) NSString * _Nullable entry_name __attribute__((swift_name("entry_name")));
@property (readonly) MealzcoreBoolean * _Nullable from_miam __attribute__((swift_name("from_miam")));
@property (readonly) NSString * _Nullable guests __attribute__((swift_name("guests")));
@property (readonly) NSString * _Nullable item_ean __attribute__((swift_name("item_ean")));
@property (readonly) NSString * _Nullable item_id __attribute__((swift_name("item_id")));
@property (readonly) MealzcoreFloat * _Nullable miam_amount __attribute__((swift_name("miam_amount")));
@property (readonly) MealzcoreInt * _Nullable miam_products __attribute__((swift_name("miam_products")));
@property (readonly, getter=doNew_item_ean) NSString * _Nullable new_item_ean __attribute__((swift_name("new_item_ean")));
@property (readonly, getter=doNew_item_id) NSString * _Nullable new_item_id __attribute__((swift_name("new_item_id")));
@property (readonly) NSString * _Nullable old_item_ean __attribute__((swift_name("old_item_ean")));
@property (readonly) NSString * _Nullable old_item_id __attribute__((swift_name("old_item_id")));
@property (readonly) NSString * _Nullable pos_id __attribute__((swift_name("pos_id")));
@property (readonly) NSString * _Nullable pos_name __attribute__((swift_name("pos_name")));
@property (readonly) NSString * _Nullable pos_total_amount __attribute__((swift_name("pos_total_amount")));
@property (readonly) MealzcoreInt * _Nullable product_quantity __attribute__((swift_name("product_quantity")));
@property (readonly) NSString * _Nullable query __attribute__((swift_name("query")));
@property (readonly) NSString * _Nullable recipe_count __attribute__((swift_name("recipe_count")));
@property (readonly) NSString * _Nullable recipe_id __attribute__((swift_name("recipe_id")));
@property (readonly) NSString * _Nullable recipe_item_id __attribute__((swift_name("recipe_item_id")));
@property (readonly) NSString * _Nullable search_term __attribute__((swift_name("search_term")));
@property (readonly) NSString * _Nullable time_passed __attribute__((swift_name("time_passed")));
@property (readonly) NSString * _Nullable total_amount __attribute__((swift_name("total_amount")));
@property (readonly) MealzcoreInt * _Nullable total_products __attribute__((swift_name("total_products")));
@property (readonly) NSString * _Nullable user_preference __attribute__((swift_name("user_preference")));
@property (readonly) NSString * _Nullable uses_count __attribute__((swift_name("uses_count")));
@property (readonly) NSString * _Nullable version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AnalyticsEvent")))
@interface MealzcoreAnalyticsEvent : MealzcoreBase
- (instancetype)initWithEventType:(NSString *)eventType path:(NSString *)path props:(NSDictionary<NSString *, id> *)props __attribute__((swift_name("init(eventType:path:props:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreAnalyticsEvent *)doCopyEventType:(NSString *)eventType path:(NSString *)path props:(NSDictionary<NSString *, id> *)props __attribute__((swift_name("doCopy(eventType:path:props:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *eventType __attribute__((swift_name("eventType")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@property (readonly) NSDictionary<NSString *, id> *props __attribute__((swift_name("props")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AnalyticsImp")))
@interface MealzcoreAnalyticsImp : MealzcoreBase <MealzcoreAnalytics>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)emitEventEvent:(MealzcoreAnalyticEvent *)event __attribute__((swift_name("emitEvent(event:)")));
- (void)emitEventEvent_:(MealzcoreAnalyticsEvent *)event __attribute__((swift_name("emitEvent(event_:)")));
- (void)doInitSupplierOrigin:(NSString *)supplierOrigin __attribute__((swift_name("doInit(supplierOrigin:)")));
- (void)sendEventName:(NSString *)name path:(NSString *)path props:(MealzcoreMutableDictionary<NSString *, id> *)props __attribute__((swift_name("sendEvent(name:path:props:)")));
@property NSString *currentPath __attribute__((swift_name("currentPath")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> domain __attribute__((swift_name("domain")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AnalyticsInstance")))
@interface MealzcoreAnalyticsInstance : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)analyticsInstance __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreAnalyticsInstance *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Route")))
@interface MealzcoreRoute : MealzcoreBase
- (instancetype)initWithTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute previous:(MealzcoreRoute * _Nullable)previous __attribute__((swift_name("init(title:backToRoute:previous:)"))) __attribute__((objc_designated_initializer));
- (void)onDialogBackRoute:(MealzcoreDialogRoute *)route __attribute__((swift_name("onDialogBack(route:)")));
- (MealzcorePageRoute * _Nullable)onDialogClose __attribute__((swift_name("onDialogClose()")));
- (void)onPrevious __attribute__((swift_name("onPrevious()")));
@property (readonly) void (^backToRoute)(void) __attribute__((swift_name("backToRoute")));
@property (readonly) MealzcoreRoute * _Nullable previous __attribute__((swift_name("previous")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DialogRoute")))
@interface MealzcoreDialogRoute : MealzcoreRoute
- (instancetype)initWithTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute previous:(MealzcoreRoute * _Nullable)previous closeDialog:(void (^)(void))closeDialog __attribute__((swift_name("init(title:backToRoute:previous:closeDialog:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute previous:(MealzcoreRoute * _Nullable)previous __attribute__((swift_name("init(title:backToRoute:previous:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (MealzcoreDialogRoute *)doCopyTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute previous:(MealzcoreRoute * _Nullable)previous closeDialog:(void (^)(void))closeDialog __attribute__((swift_name("doCopy(title:backToRoute:previous:closeDialog:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (void)onDialogBackRoute:(MealzcoreDialogRoute *)route __attribute__((swift_name("onDialogBack(route:)")));
- (MealzcorePageRoute * _Nullable)onDialogClose __attribute__((swift_name("onDialogClose()")));
- (void)onPrevious __attribute__((swift_name("onPrevious()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) void (^backToRoute)(void) __attribute__((swift_name("backToRoute")));
@property (readonly) void (^closeDialog)(void) __attribute__((swift_name("closeDialog")));
@property (readonly) MealzcoreRoute * _Nullable previous __attribute__((swift_name("previous")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PageRoute")))
@interface MealzcorePageRoute : MealzcoreRoute
- (instancetype)initWithTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute previous:(MealzcoreRoute * _Nullable)previous __attribute__((swift_name("init(title:backToRoute:previous:)"))) __attribute__((objc_designated_initializer));
- (MealzcorePageRoute *)doCopyTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute previous:(MealzcoreRoute * _Nullable)previous __attribute__((swift_name("doCopy(title:backToRoute:previous:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (void)onDialogBackRoute:(MealzcoreDialogRoute *)route __attribute__((swift_name("onDialogBack(route:)")));
- (MealzcorePageRoute *)onDialogClose __attribute__((swift_name("onDialogClose()")));
- (void)onPrevious __attribute__((swift_name("onPrevious()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) void (^backToRoute)(void) __attribute__((swift_name("backToRoute")));
@property (readonly) MealzcoreRoute * _Nullable previous __attribute__((swift_name("previous")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((swift_name("RouteService")))
@interface MealzcoreRouteService : MealzcoreBase <MealzcoreStore, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<MealzcoreKotlinx_coroutines_coreJob>)dispatchAction:(MealzcoreRouteServiceAction *)action __attribute__((swift_name("dispatch(action:)")));
- (MealzcoreRoute * _Nullable)getCurrentRoute __attribute__((swift_name("getCurrentRoute()")));
- (void)onCloseDialog __attribute__((swift_name("onCloseDialog()")));
- (void)onRouteChangeUpdateRoute:(void (^)(MealzcoreRoute * _Nullable))updateRoute __attribute__((swift_name("onRouteChange(updateRoute:)")));
- (MealzcoreRoute * _Nullable)previous __attribute__((swift_name("previous()")));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> state __attribute__((swift_name("state")));
@end

__attribute__((swift_name("RouteServiceAction")))
@interface MealzcoreRouteServiceAction : MealzcoreBase <MealzcoreAction>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouteServiceAction.SetDialogRoute")))
@interface MealzcoreRouteServiceActionSetDialogRoute : MealzcoreRouteServiceAction
- (instancetype)initWithTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute closeDialog:(void (^)(void))closeDialog __attribute__((swift_name("init(title:backToRoute:closeDialog:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRouteServiceActionSetDialogRoute *)doCopyTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute closeDialog:(void (^)(void))closeDialog __attribute__((swift_name("doCopy(title:backToRoute:closeDialog:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) void (^backToRoute)(void) __attribute__((swift_name("backToRoute")));
@property (readonly) void (^closeDialog)(void) __attribute__((swift_name("closeDialog")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouteServiceAction.SetInitialPageRoute")))
@interface MealzcoreRouteServiceActionSetInitialPageRoute : MealzcoreRouteServiceAction
- (instancetype)initWithTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute __attribute__((swift_name("init(title:backToRoute:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRouteServiceActionSetInitialPageRoute *)doCopyTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute __attribute__((swift_name("doCopy(title:backToRoute:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) void (^backToRoute)(void) __attribute__((swift_name("backToRoute")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouteServiceAction.SetPageRoute")))
@interface MealzcoreRouteServiceActionSetPageRoute : MealzcoreRouteServiceAction
- (instancetype)initWithTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute __attribute__((swift_name("init(title:backToRoute:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRouteServiceActionSetPageRoute *)doCopyTitle:(NSString *)title backToRoute:(void (^)(void))backToRoute __attribute__((swift_name("doCopy(title:backToRoute:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) void (^backToRoute)(void) __attribute__((swift_name("backToRoute")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((swift_name("RouteServiceEffect")))
@interface MealzcoreRouteServiceEffect : MealzcoreBase <MealzcoreEffect>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouteServiceEffect.RouteChanged")))
@interface MealzcoreRouteServiceEffectRouteChanged : MealzcoreRouteServiceEffect
- (instancetype)initWithNewRoute:(MealzcoreRoute *)newRoute __attribute__((swift_name("init(newRoute:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRouteServiceEffectRouteChanged *)doCopyNewRoute:(MealzcoreRoute *)newRoute __attribute__((swift_name("doCopy(newRoute:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=doNewRoute) MealzcoreRoute *newRoute __attribute__((swift_name("newRoute")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouteServiceInstance")))
@interface MealzcoreRouteServiceInstance : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)routeServiceInstance __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRouteServiceInstance *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreRouteService *instance __attribute__((swift_name("instance")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouteServiceState")))
@interface MealzcoreRouteServiceState : MealzcoreBase <MealzcoreState>
- (instancetype)initWithRoute:(MealzcoreRoute * _Nullable)route __attribute__((swift_name("init(route:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRouteServiceState *)doCopyRoute:(MealzcoreRoute * _Nullable)route __attribute__((swift_name("doCopy(route:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreRoute * _Nullable route __attribute__((swift_name("route")));
@end

__attribute__((swift_name("UserPreferences")))
@protocol MealzcoreUserPreferences
@required
- (MealzcoreDouble * _Nullable)getDoubleOrNullKey:(NSString *)key __attribute__((swift_name("getDoubleOrNull(key:)")));
- (MealzcoreInt * _Nullable)getIntOrNullKey:(NSString *)key __attribute__((swift_name("getIntOrNull(key:)")));
- (NSArray<NSString *> * _Nullable)getListOrNullKey:(NSString *)key __attribute__((swift_name("getListOrNull(key:)")));
- (NSString * _Nullable)getStringOrNullKey:(NSString *)key __attribute__((swift_name("getStringOrNull(key:)")));
- (void)putDoubleKey:(NSString *)key value:(double)value __attribute__((swift_name("putDouble(key:value:)")));
- (void)putIntKey:(NSString *)key value:(int32_t)value __attribute__((swift_name("putInt(key:value:)")));
- (void)putListKey:(NSString *)key value:(NSArray<NSString *> *)value __attribute__((swift_name("putList(key:value:)")));
- (void)putStringKey:(NSString *)key value:(NSString *)value __attribute__((swift_name("putString(key:value:)")));
- (void)removeKeyKey:(NSString *)key __attribute__((swift_name("removeKey(key:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserPreferencesCompanion")))
@interface MealzcoreUserPreferencesCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreUserPreferencesCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserPreferencesImp")))
@interface MealzcoreUserPreferencesImp : MealzcoreBase <MealzcoreUserPreferences>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreDouble * _Nullable)getDoubleOrNullKey:(NSString *)key __attribute__((swift_name("getDoubleOrNull(key:)")));
- (MealzcoreInt * _Nullable)getIntOrNullKey:(NSString *)key __attribute__((swift_name("getIntOrNull(key:)")));
- (NSArray<NSString *> * _Nullable)getListOrNullKey:(NSString *)key __attribute__((swift_name("getListOrNull(key:)")));
- (NSString * _Nullable)getStringOrNullKey:(NSString *)key __attribute__((swift_name("getStringOrNull(key:)")));
- (void)putDoubleKey:(NSString *)key value:(double)value __attribute__((swift_name("putDouble(key:value:)")));
- (void)putIntKey:(NSString *)key value:(int32_t)value __attribute__((swift_name("putInt(key:value:)")));
- (void)putListKey:(NSString *)key value:(NSArray<NSString *> *)value __attribute__((swift_name("putList(key:value:)")));
- (void)putStringKey:(NSString *)key value:(NSString *)value __attribute__((swift_name("putString(key:value:)")));
- (void)removeKeyKey:(NSString *)key __attribute__((swift_name("removeKey(key:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Environment")))
@interface MealzcoreEnvironment : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)environment __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreEnvironment *shared __attribute__((swift_name("shared")));
@property BOOL allowsSponsoredProducts __attribute__((swift_name("allowsSponsoredProducts")));
@property MealzcoreKMMContext * _Nullable context __attribute__((swift_name("context")));
@property NSString *environmentUrl __attribute__((swift_name("environmentUrl")));
@property BOOL isAnalyticsEnabled __attribute__((swift_name("isAnalyticsEnabled")));
@property (readonly) BOOL isProviderOnly __attribute__((swift_name("isProviderOnly")));
@property (readonly) BOOL isSupplierOnly __attribute__((swift_name("isSupplierOnly")));
@property MealzcoreSupportedLanguage *language __attribute__((swift_name("language")));
@property NSString *miamOrigin __attribute__((swift_name("miamOrigin")));
@property NSString *origin __attribute__((swift_name("origin")));
@property NSString *priceBook __attribute__((swift_name("priceBook"))) __attribute__((deprecated("Don't use this variable anymore. Now we always use the default priceBook since one POS have a unique priceBook")));
@property NSString * _Nullable providerId __attribute__((swift_name("providerId")));
@property BOOL showTranslateKey __attribute__((swift_name("showTranslateKey")));
@property NSString * _Nullable supplierId __attribute__((swift_name("supplierId")));
@end

__attribute__((swift_name("LikeEffect")))
@interface MealzcoreLikeEffect : MealzcoreBase <MealzcoreEffect>
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LikeEffect.Disliked")))
@interface MealzcoreLikeEffectDisliked : MealzcoreLikeEffect
- (instancetype)initWithRecipeId:(NSString *)recipeId __attribute__((swift_name("init(recipeId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreLikeEffectDisliked *)doCopyRecipeId:(NSString *)recipeId __attribute__((swift_name("doCopy(recipeId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LikeEffect.Liked")))
@interface MealzcoreLikeEffectLiked : MealzcoreLikeEffect
- (instancetype)initWithRecipe:(MealzcoreRecipe *)recipe __attribute__((swift_name("init(recipe:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreLikeEffectLiked *)doCopyRecipe:(MealzcoreRecipe *)recipe __attribute__((swift_name("doCopy(recipe:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreRecipe *recipe __attribute__((swift_name("recipe")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LikeStore")))
@interface MealzcoreLikeStore : MealzcoreBase <MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)fetchAndGetRecipeLikesRecipeIds:(NSArray<NSString *> *)recipeIds completionHandler:(void (^)(NSArray<MealzcoreRecipeLike *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("fetchAndGetRecipeLikes(recipeIds:completionHandler:)")));
- (NSArray<NSString *> *)getCurrentLikedRecipeIds __attribute__((swift_name("getCurrentLikedRecipeIds()")));
- (id<MealzcoreKotlinx_coroutines_coreFlow>)observeSideEffect __attribute__((swift_name("observeSideEffect()")));
- (void)reset __attribute__((swift_name("reset()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)toggleLikeRecipeId:(NSString *)recipeId completionHandler:(void (^)(MealzcoreRecipeLike * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("toggleLike(recipeId:completionHandler:)")));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LikeStoreInstance")))
@interface MealzcoreLikeStoreInstance : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)likeStoreInstance __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreLikeStoreInstance *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreLikeStore *instance __attribute__((swift_name("instance")));
@end

__attribute__((swift_name("UserAction")))
@interface MealzcoreUserAction : MealzcoreBase <MealzcoreAction>
@end

__attribute__((swift_name("UserEffect")))
@interface MealzcoreUserEffect : MealzcoreBase <MealzcoreEffect>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserState")))
@interface MealzcoreUserState : MealzcoreBase <MealzcoreState>
- (instancetype)initWithUserId:(NSString * _Nullable)userId sessionId:(NSString * _Nullable)sessionId authorization:(MealzcoreAuthorization *)authorization profilingAllowed:(BOOL)profilingAllowed likeIsEnable:(BOOL)likeIsEnable __attribute__((swift_name("init(userId:sessionId:authorization:profilingAllowed:likeIsEnable:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreUserState *)doCopyUserId:(NSString * _Nullable)userId sessionId:(NSString * _Nullable)sessionId authorization:(MealzcoreAuthorization *)authorization profilingAllowed:(BOOL)profilingAllowed likeIsEnable:(BOOL)likeIsEnable __attribute__((swift_name("doCopy(userId:sessionId:authorization:profilingAllowed:likeIsEnable:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreAuthorization *authorization __attribute__((swift_name("authorization")));
@property (readonly) BOOL likeIsEnable __attribute__((swift_name("likeIsEnable")));
@property (readonly) BOOL profilingAllowed __attribute__((swift_name("profilingAllowed")));
@property (readonly) NSString * _Nullable sessionId __attribute__((swift_name("sessionId")));
@property (readonly) NSString * _Nullable userId __attribute__((swift_name("userId")));
@end

__attribute__((swift_name("UserStore")))
@protocol MealzcoreUserStore <MealzcoreStore>
@required
- (BOOL)ProfilingForbiden __attribute__((swift_name("ProfilingForbiden()")));
- (int32_t)getAndIncreaseMealPlannerUsesCount __attribute__((swift_name("getAndIncreaseMealPlannerUsesCount()")));
- (BOOL)getEnableLike __attribute__((swift_name("getEnableLike()")));
- (NSString * _Nullable)getSessionId __attribute__((swift_name("getSessionId()")));
- (BOOL)isLoggedIn __attribute__((swift_name("isLoggedIn()")));
- (void)refreshTokenToken:(NSString *)token __attribute__((swift_name("refreshToken(token:)")));
- (void)refreshUserUserId:(NSString * _Nullable)userId authorization:(MealzcoreAuthorization *)authorization __attribute__((swift_name("refreshUser(userId:authorization:)")));
- (BOOL)sameSessionSessionId:(NSString *)sessionId __attribute__((swift_name("sameSession(sessionId:)")));
- (BOOL)sameUserUserId:(NSString * _Nullable)userId __attribute__((swift_name("sameUser(userId:)")));
- (void)setEnableLikeIsEnable:(BOOL)isEnable __attribute__((swift_name("setEnableLike(isEnable:)")));
- (void)setProfilingAllowedAllowance:(BOOL)allowance __attribute__((swift_name("setProfilingAllowed(allowance:)")));
- (void)setSessionIdSessionId:(NSString *)sessionId __attribute__((swift_name("setSessionId(sessionId:)")));
@property BOOL isAnonymousModeEnabled __attribute__((swift_name("isAnonymousModeEnabled")));
@property void (^signInRedirection)(void) __attribute__((swift_name("signInRedirection")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserStoreImpl")))
@interface MealzcoreUserStoreImpl : MealzcoreBase <MealzcoreUserStore, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreUserStoreImplCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)ProfilingForbiden __attribute__((swift_name("ProfilingForbiden()")));
- (id<MealzcoreKotlinx_coroutines_coreJob>)dispatchAction:(MealzcoreUserAction *)action __attribute__((swift_name("dispatch(action:)")));
- (int32_t)getAndIncreaseMealPlannerUsesCount __attribute__((swift_name("getAndIncreaseMealPlannerUsesCount()")));
- (BOOL)getEnableLike __attribute__((swift_name("getEnableLike()")));
- (NSString * _Nullable)getSessionId __attribute__((swift_name("getSessionId()")));
- (BOOL)isLoggedIn __attribute__((swift_name("isLoggedIn()")));
- (void)refreshTokenToken:(NSString *)token __attribute__((swift_name("refreshToken(token:)")));
- (void)refreshUserUserId:(NSString * _Nullable)userId authorization:(MealzcoreAuthorization *)authorization __attribute__((swift_name("refreshUser(userId:authorization:)")));
- (BOOL)sameSessionSessionId:(NSString *)sessionId __attribute__((swift_name("sameSession(sessionId:)")));
- (BOOL)sameUserUserId:(NSString * _Nullable)userId __attribute__((swift_name("sameUser(userId:)")));
- (void)setEnableLikeIsEnable:(BOOL)isEnable __attribute__((swift_name("setEnableLike(isEnable:)")));
- (void)setProfilingAllowedAllowance:(BOOL)allowance __attribute__((swift_name("setProfilingAllowed(allowance:)")));
- (void)setSessionIdSessionId:(NSString *)sessionId __attribute__((swift_name("setSessionId(sessionId:)")));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property BOOL isAnonymousModeEnabled __attribute__((swift_name("isAnonymousModeEnabled")));
@property void (^signInRedirection)(void) __attribute__((swift_name("signInRedirection")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> state __attribute__((swift_name("state")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserStoreImpl.Companion")))
@interface MealzcoreUserStoreImplCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreUserStoreImplCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AvailabilityState")))
@interface MealzcoreAvailabilityState : MealzcoreBase
- (instancetype)initWithIsInError:(BOOL)isInError isUserConnected:(BOOL)isUserConnected isBasketComparatorReady:(BOOL)isBasketComparatorReady isPreferencesReady:(BOOL)isPreferencesReady __attribute__((swift_name("init(isInError:isUserConnected:isBasketComparatorReady:isPreferencesReady:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreAvailabilityState *)doCopyIsInError:(BOOL)isInError isUserConnected:(BOOL)isUserConnected isBasketComparatorReady:(BOOL)isBasketComparatorReady isPreferencesReady:(BOOL)isPreferencesReady __attribute__((swift_name("doCopy(isInError:isUserConnected:isBasketComparatorReady:isPreferencesReady:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isBasketComparatorReady __attribute__((swift_name("isBasketComparatorReady")));
@property (readonly) BOOL isInError __attribute__((swift_name("isInError")));
@property (readonly) BOOL isPreferencesReady __attribute__((swift_name("isPreferencesReady")));
@property (readonly) BOOL isUserConnected __attribute__((swift_name("isUserConnected")));
@end

__attribute__((swift_name("AvailabilityStore")))
@protocol MealzcoreAvailabilityStore
@required
- (BOOL)isAvailable __attribute__((swift_name("isAvailable()")));
@end

__attribute__((swift_name("BasketAction")))
@interface MealzcoreBasketAction : MealzcoreBase <MealzcoreAction>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketAction.RefreshBasket")))
@interface MealzcoreBasketActionRefreshBasket : MealzcoreBasketAction
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)refreshBasket __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketActionRefreshBasket *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketAction.RefreshBasketPrice")))
@interface MealzcoreBasketActionRefreshBasketPrice : MealzcoreBasketAction
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)refreshBasketPrice __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketActionRefreshBasketPrice *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketAction.ResetBasket")))
@interface MealzcoreBasketActionResetBasket : MealzcoreBasketAction
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)resetBasket __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketActionResetBasket *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketState")))
@interface MealzcoreBasketState : MealzcoreBase <MealzcoreState>
- (instancetype)initWithBasket:(MealzcoreBasket * _Nullable)basket isLoading:(BOOL)isLoading __attribute__((swift_name("init(basket:isLoading:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketState *)doCopyBasket:(MealzcoreBasket * _Nullable)basket isLoading:(BOOL)isLoading __attribute__((swift_name("doCopy(basket:isLoading:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasket * _Nullable basket __attribute__((swift_name("basket")));
@property BOOL isLoading __attribute__((swift_name("isLoading")));
@property (readonly) int32_t recipeCount __attribute__((swift_name("recipeCount")));
@end

__attribute__((swift_name("BasketStore")))
@protocol MealzcoreBasketStore <MealzcoreStore>
@required
- (void)addEmptyRecipeToBasketRecipeId:(NSString *)recipeId basket:(MealzcoreBasket *)basket __attribute__((swift_name("addEmptyRecipeToBasket(recipeId:basket:)")));
- (BOOL)basketIsEmpty __attribute__((swift_name("basketIsEmpty()")));
- (int32_t)basketRecipesCount __attribute__((swift_name("basketRecipesCount()")));
- (void)checkBasketLoading __attribute__((swift_name("checkBasketLoading()")));
- (MealzcoreBasket * _Nullable)getBasket __attribute__((swift_name("getBasket()")));
- (NSArray<MealzcoreBasketEntry *> *)getBasketEntries __attribute__((swift_name("getBasketEntries()")));
- (int32_t)guestsForRecipeRecipeId:(NSString * _Nullable)recipeId __attribute__((swift_name("guestsForRecipe(recipeId:)")));
- (void)pushActionAction:(MealzcoreBasketAction *)action __attribute__((swift_name("pushAction(action:)")));
- (BOOL)recipeIsInBasketRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId __attribute__((swift_name("recipeIsInBasket(recipeId:isExtId:)")));
- (void)setBasketBasket:(MealzcoreBasket *)basket __attribute__((swift_name("setBasket(basket:)")));
@property (readonly) double basketTotalPrice __attribute__((swift_name("basketTotalPrice")));
@property (readonly) NSArray<MealzcoreBasketEntry *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketComparator")))
@interface MealzcoreBasketComparator : MealzcoreBase
- (instancetype)initWithExtIdToComparisonItem:(NSDictionary<NSString *, MealzcoreBasketComparisonItem *> *)extIdToComparisonItem __attribute__((swift_name("init(extIdToComparisonItem:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketComparator *)doCopyExtIdToComparisonItem:(NSDictionary<NSString *, MealzcoreBasketComparisonItem *> *)extIdToComparisonItem __attribute__((swift_name("doCopy(extIdToComparisonItem:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (MealzcoreBasketComparator *)doInitSupplierBasket:(NSArray<MealzcoreSupplierProduct *> *)supplierBasket sdkActiveBasket:(NSArray<MealzcoreBasketEntry *> *)sdkActiveBasket __attribute__((swift_name("doInit(supplierBasket:sdkActiveBasket:)")));
- (NSMutableArray<MealzcoreSupplierProduct *> *)resolveFromSDKNewBasketComparator:(MealzcoreBasketComparator *)newBasketComparator __attribute__((swift_name("resolveFromSDK(newBasketComparator:)")));
- (NSArray<MealzcoreAlterQuantityBasketEntry *> *)resolveFromSupplierNewComparator:(MealzcoreBasketComparator *)newComparator __attribute__((swift_name("resolveFromSupplier(newComparator:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (MealzcoreBasketComparator *)updateReceivedFromSDKSdkActiveBasket:(NSArray<MealzcoreBasketEntry *> *)sdkActiveBasket __attribute__((swift_name("updateReceivedFromSDK(sdkActiveBasket:)")));
- (MealzcoreBasketComparator *)updateReceivedFromSupplierSupplierBasket:(NSArray<MealzcoreSupplierProduct *> *)supplierBasket __attribute__((swift_name("updateReceivedFromSupplier(supplierBasket:)")));
@property (readonly) NSDictionary<NSString *, MealzcoreBasketComparisonItem *> *extIdToComparisonItem __attribute__((swift_name("extIdToComparisonItem")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketComparatorData")))
@interface MealzcoreBasketComparatorData : MealzcoreBase
- (instancetype)initWithExtIdToComparisonItem:(MealzcoreMutableDictionary<NSString *, MealzcoreBasketComparisonItem *> *)extIdToComparisonItem __attribute__((swift_name("init(extIdToComparisonItem:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketComparatorData *)doCopyExtIdToComparisonItem:(MealzcoreMutableDictionary<NSString *, MealzcoreBasketComparisonItem *> *)extIdToComparisonItem __attribute__((swift_name("doCopy(extIdToComparisonItem:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (void)doInitSupplierBasket:(NSArray<MealzcoreSupplierProduct *> *)supplierBasket sDKActiveBasket:(NSArray<MealzcoreBasketEntry *> *)sDKActiveBasket __attribute__((swift_name("doInit(supplierBasket:sDKActiveBasket:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (void)updateMapFromSdkSdkActiveBasket:(NSArray<MealzcoreBasketEntry *> *)sdkActiveBasket __attribute__((swift_name("updateMapFromSdk(sdkActiveBasket:)")));
- (void)updateMapFromSupplierSupplierBasket:(NSArray<MealzcoreSupplierProduct *> *)supplierBasket __attribute__((swift_name("updateMapFromSupplier(supplierBasket:)")));
@property (readonly) MealzcoreMutableDictionary<NSString *, MealzcoreBasketComparisonItem *> *extIdToComparisonItem __attribute__((swift_name("extIdToComparisonItem")));
@end

__attribute__((swift_name("BasketComparatorStore")))
@protocol MealzcoreBasketComparatorStore
@required
- (void)basketChangeSdkActiveBasket:(NSArray<MealzcoreBasketEntry *> *)sdkActiveBasket __attribute__((swift_name("basketChange(sdkActiveBasket:)")));
- (int32_t)getNumberOfProductsInCustomerBasket __attribute__((swift_name("getNumberOfProductsInCustomerBasket()")));
- (void)handleSdkBasketNotificationNotification:(MealzcoreBasketNotification *)notification __attribute__((swift_name("handleSdkBasketNotification(notification:)")));
- (void)doInitFirstSdkBasketSdkActiveBasket:(NSArray<MealzcoreBasketEntry *> *)sdkActiveBasket __attribute__((swift_name("doInitFirstSdkBasket(sdkActiveBasket:)")));
- (void)doInitFirstSupplierBasketSupplierBasket:(NSArray<MealzcoreSupplierProduct *> *)supplierBasket __attribute__((swift_name("doInitFirstSupplierBasket(supplierBasket:)")));
- (void)doInitIfPossible __attribute__((swift_name("doInitIfPossible()")));
- (void)processSupplierEventRetailerBasket:(NSArray<MealzcoreSupplierProduct *> *)retailerBasket __attribute__((swift_name("processSupplierEvent(retailerBasket:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)sendUpdateToSdkEntriesToRemove:(NSArray<MealzcoreAlterQuantityBasketEntry *> *)entriesToRemove __attribute__((swift_name("sendUpdateToSdk(entriesToRemove:)")));
- (void)sendUpdateToSupplierItemsToAdd:(NSArray<MealzcoreSupplierProduct *> *)itemsToAdd __attribute__((swift_name("sendUpdateToSupplier(itemsToAdd:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketComparisonItem")))
@interface MealzcoreBasketComparisonItem : MealzcoreBase
- (instancetype)initWithSupplierId:(NSString *)supplierId productName:(NSString * _Nullable)productName imageURL:(NSString * _Nullable)imageURL sdkBasketEntryIds:(NSDictionary<NSString *, MealzcoreInt *> *)sdkBasketEntryIds supplierProduct:(MealzcoreSupplierProduct *)supplierProduct __attribute__((swift_name("init(supplierId:productName:imageURL:sdkBasketEntryIds:supplierProduct:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketComparisonItem *)addMiamEntryBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("addMiamEntry(basketEntry:)")));
- (MealzcoreBasketComparisonItem *)doCopySupplierId:(NSString *)supplierId productName:(NSString * _Nullable)productName imageURL:(NSString * _Nullable)imageURL sdkBasketEntryIds:(NSDictionary<NSString *, MealzcoreInt *> *)sdkBasketEntryIds supplierProduct:(MealzcoreSupplierProduct *)supplierProduct __attribute__((swift_name("doCopy(supplierId:productName:imageURL:sdkBasketEntryIds:supplierProduct:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSArray<MealzcoreAlterQuantityBasketEntry *> *)miamProductRemoved __attribute__((swift_name("miamProductRemoved()")));
- (MealzcoreSupplierProduct * _Nullable)retailerProductAddedOrUpdatedFromMiamPreviousCompItem:(MealzcoreBasketComparisonItem * _Nullable)previousCompItem __attribute__((swift_name("retailerProductAddedOrUpdatedFromMiam(previousCompItem:)")));
- (MealzcoreSupplierProduct * _Nullable)retailerProductsRemovedFromMiamNewCompItem:(MealzcoreBasketComparisonItem * _Nullable)newCompItem __attribute__((swift_name("retailerProductsRemovedFromMiam(newCompItem:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *firstBasketEntryId __attribute__((swift_name("firstBasketEntryId")));
@property (readonly) NSString * _Nullable imageURL __attribute__((swift_name("imageURL")));
@property (readonly) int32_t miamQuantity __attribute__((swift_name("miamQuantity")));
@property (readonly) NSString * _Nullable productName __attribute__((swift_name("productName")));
@property (readonly) int32_t retailerQuantity __attribute__((swift_name("retailerQuantity")));
@property (readonly) NSDictionary<NSString *, MealzcoreInt *> *sdkBasketEntryIds __attribute__((swift_name("sdkBasketEntryIds")));
@property (readonly) NSString *supplierId __attribute__((swift_name("supplierId")));
@property (readonly) MealzcoreSupplierProduct *supplierProduct __attribute__((swift_name("supplierProduct")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerState")))
@interface MealzcoreMealPlannerState : MealzcoreBase <MealzcoreState>
- (instancetype)initWithRecipeIds:(NSArray<id> *)recipeIds totalPrice:(double)totalPrice __attribute__((swift_name("init(recipeIds:totalPrice:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMealPlannerState *)doCopyRecipeIds:(NSArray<id> *)recipeIds totalPrice:(double)totalPrice __attribute__((swift_name("doCopy(recipeIds:totalPrice:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<id> *recipeIds __attribute__((swift_name("recipeIds")));
@property (readonly) double totalPrice __attribute__((swift_name("totalPrice")));
@end

__attribute__((swift_name("MealPlannerStore")))
@protocol MealzcoreMealPlannerStore
@required
- (void)setRecipeIdsRecipesId:(NSArray<id> *)recipesId __attribute__((swift_name("setRecipeIds(recipesId:)")));
- (void)setTotalPricePrice:(double)price __attribute__((swift_name("setTotalPrice(price:)")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreStateFlow> state __attribute__((swift_name("state")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketSubscriptionBuilder")))
@interface MealzcoreBasketSubscriptionBuilder : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)registerPublisher:(id<MealzcoreBasketPublisher>)publisher __attribute__((swift_name("register(publisher:)")));
- (void)subscribeSubscriber:(id<MealzcoreBasketSubscriber>)subscriber __attribute__((swift_name("subscribe(subscriber:)")));
@end

__attribute__((swift_name("BasketPublisher")))
@protocol MealzcoreBasketPublisher
@required
- (void)onBasketUpdateSendUpdateToSDK:(void (^)(NSArray<MealzcoreSupplierProduct *> *))sendUpdateToSDK __attribute__((swift_name("onBasketUpdate(sendUpdateToSDK:)")));
@property NSArray<MealzcoreSupplierProduct *> *initialValue __attribute__((swift_name("initialValue")));
@end

__attribute__((swift_name("BasketSubscriber")))
@protocol MealzcoreBasketSubscriber
@required
- (void)receiveEvent:(NSArray<MealzcoreSupplierProduct *> *)event __attribute__((swift_name("receive(event:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoreConstants")))
@interface MealzcoreCoreConstants : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)coreConstants __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreCoreConstants *shared __attribute__((swift_name("shared")));
@property (readonly) int32_t MINIMUM_SEARCH_INPUT_LENGTH __attribute__((swift_name("MINIMUM_SEARCH_INPUT_LENGTH")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AbortBasketUseCase")))
@interface MealzcoreAbortBasketUseCase : MealzcoreBase <MealzcoreUseCase, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithBasketStore:(id<MealzcoreBasketStore>)basketStore userStore:(id<MealzcoreUserStore>)userStore basketRepository:(id<MealzcoreBasketRepository>)basketRepository __attribute__((swift_name("init(basketStore:userStore:basketRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id<MealzcoreKotlinx_coroutines_coreDeferred> _Nullable)invokeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke()"))) __attribute__((swift_error(nonnull_error)));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfirmBasketUseCase")))
@interface MealzcoreConfirmBasketUseCase : MealzcoreBase <MealzcoreParameterisedUseCase, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithBasketRepository:(id<MealzcoreBasketRepository>)basketRepository basketStore:(id<MealzcoreBasketStore>)basketStore supplierRepository:(id<MealzcoreSupplierRepository>)supplierRepository analytics:(id<MealzcoreAnalytics>)analytics __attribute__((swift_name("init(basketRepository:basketStore:supplierRepository:analytics:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id<MealzcoreKotlinx_coroutines_coreJob> _Nullable)invokeInput:(MealzcoreMutableDictionary<NSString *, id> *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetAffiliationOrNullUseCase")))
@interface MealzcoreGetAffiliationOrNullUseCase : MealzcoreBase <MealzcoreUseCase, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithBasketStore:(id<MealzcoreBasketStore>)basketStore __attribute__((swift_name("init(basketStore:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (NSString * _Nullable)invokeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke()"))) __attribute__((swift_error(nonnull_error)));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ParseUniversalLinkAndSaveLocallyTransferredBasketDataUseCase")))
@interface MealzcoreParseUniversalLinkAndSaveLocallyTransferredBasketDataUseCase : MealzcoreBase <MealzcoreParameterisedUseCase>
- (instancetype)initWithUserSharedPrefService:(id<MealzcoreUserPreferences>)userSharedPrefService availabilityStoreImp:(id<MealzcoreAvailabilityStore>)availabilityStoreImp transferAffiliateBasketToSupplierUseCase:(id<MealzcoreUseCase>)transferAffiliateBasketToSupplierUseCase __attribute__((swift_name("init(userSharedPrefService:availabilityStoreImp:transferAffiliateBasketToSupplierUseCase:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreKotlinUnit * _Nullable)invokeInput:(NSString *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StartTransferBasketUseCase")))
@interface MealzcoreStartTransferBasketUseCase : MealzcoreBase <MealzcoreUseCase, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithBasketRepositoryImp:(id<MealzcoreBasketRepository>)basketRepositoryImp userPreferences:(id<MealzcoreUserPreferences>)userPreferences reloadBasketUseCase:(id<MealzcoreParameterisedUseCase>)reloadBasketUseCase __attribute__((swift_name("init(basketRepositoryImp:userPreferences:reloadBasketUseCase:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id<MealzcoreKotlinx_coroutines_coreDeferred> _Nullable)invokeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke()"))) __attribute__((swift_error(nonnull_error)));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransferAffiliateBasketToSupplierUseCase")))
@interface MealzcoreTransferAffiliateBasketToSupplierUseCase : MealzcoreMainExecutor <MealzcoreUseCase>
- (instancetype)initWithUserSharedPrefService:(id<MealzcoreUserPreferences>)userSharedPrefService basketRepository:(id<MealzcoreBasketRepository>)basketRepository basketStore:(id<MealzcoreBasketStore>)basketStore pointOfSaleRepository:(id<MealzcorePointOfSaleRepository>)pointOfSaleRepository __attribute__((swift_name("init(userSharedPrefService:basketRepository:basketStore:pointOfSaleRepository:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) MealzcoreTransferAffiliateBasketToSupplierUseCaseCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreKotlinUnit * _Nullable)invokeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke()"))) __attribute__((swift_error(nonnull_error)));
- (void)onErrorException:(MealzcoreKotlinThrowable *)exception __attribute__((swift_name("onError(exception:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransferAffiliateBasketToSupplierUseCase.Companion")))
@interface MealzcoreTransferAffiliateBasketToSupplierUseCaseCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreTransferAffiliateBasketToSupplierUseCaseCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *TRANSFERRED_BASKET_TOKEN __attribute__((swift_name("TRANSFERRED_BASKET_TOKEN")));
@property (readonly) NSString *TRANSFERRED_POINT_OF_SALE_ID __attribute__((swift_name("TRANSFERRED_POINT_OF_SALE_ID")));
@property (readonly) NSString *TRANSFERRED_TOKEN_WITHOUT_POS_ID __attribute__((swift_name("TRANSFERRED_TOKEN_WITHOUT_POS_ID")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransferAuthlessBasketUseCase")))
@interface MealzcoreTransferAuthlessBasketUseCase : MealzcoreBase <MealzcoreParameterisedUseCase, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithBasketRepositoryImp:(id<MealzcoreBasketRepository>)basketRepositoryImp __attribute__((swift_name("init(basketRepositoryImp:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id<MealzcoreKotlinx_coroutines_coreDeferred> _Nullable)invokeInput:(NSString *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SearchOrderHistoryUseCase")))
@interface MealzcoreSearchOrderHistoryUseCase : MealzcoreMainExecutor <MealzcoreParameterisedUseCase>
- (instancetype)initWithBasketRepository:(id<MealzcoreBasketRepository>)basketRepository __attribute__((swift_name("init(basketRepository:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id<MealzcoreKotlinx_coroutines_coreDeferred> _Nullable)invokeInput:(NSString *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReloadBasketIfPreviousAuthlessUserStoredUseCase")))
@interface MealzcoreReloadBasketIfPreviousAuthlessUserStoredUseCase : MealzcoreBase <MealzcoreUseCase, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithUserStore:(id<MealzcoreUserStore>)userStore userPreferences:(id<MealzcoreUserPreferences>)userPreferences reloadBasketUseCase:(id<MealzcoreUseCase>)reloadBasketUseCase __attribute__((swift_name("init(userStore:userPreferences:reloadBasketUseCase:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id<MealzcoreKotlinx_coroutines_coreDeferred> _Nullable)invokeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke()"))) __attribute__((swift_error(nonnull_error)));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReloadBasketPassingInPosUseCase")))
@interface MealzcoreReloadBasketPassingInPosUseCase : MealzcoreMainExecutor <MealzcoreParameterisedUseCase>
- (instancetype)initWithBasketStore:(id<MealzcoreBasketStore>)basketStore userStore:(id<MealzcoreUserStore>)userStore basketRepository:(id<MealzcoreBasketRepository>)basketRepository __attribute__((swift_name("init(basketStore:userStore:basketRepository:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id<MealzcoreKotlinx_coroutines_coreDeferred> _Nullable)invokeInput:(NSString *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ReloadBasketWithStoredPosUseCase")))
@interface MealzcoreReloadBasketWithStoredPosUseCase : MealzcoreBase <MealzcoreUseCase, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithBasketStore:(id<MealzcoreBasketStore>)basketStore userStore:(id<MealzcoreUserStore>)userStore basketRepository:(id<MealzcoreBasketRepository>)basketRepository __attribute__((swift_name("init(basketStore:userStore:basketRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id<MealzcoreKotlinx_coroutines_coreDeferred> _Nullable)invokeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke()"))) __attribute__((swift_error(nonnull_error)));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetNumberOfProductsInCustomerBasketUseCase")))
@interface MealzcoreGetNumberOfProductsInCustomerBasketUseCase : MealzcoreBase <MealzcoreUseCase, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreInt * _Nullable)invokeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke()"))) __attribute__((swift_error(nonnull_error)));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddRecipesByIdsToMealPlannerUseCaseInput")))
@interface MealzcoreAddRecipesByIdsToMealPlannerUseCaseInput : MealzcoreBase
- (instancetype)initWithIndex:(int32_t)index newRecipeId:(NSString *)newRecipeId __attribute__((swift_name("init(index:newRecipeId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreAddRecipesByIdsToMealPlannerUseCaseInput *)doCopyIndex:(int32_t)index newRecipeId:(NSString *)newRecipeId __attribute__((swift_name("doCopy(index:newRecipeId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t index __attribute__((swift_name("index")));
@property (readonly, getter=doNewRecipeId) NSString *newRecipeId __attribute__((swift_name("newRecipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InitSupplierUseCaseInput")))
@interface MealzcoreInitSupplierUseCaseInput : MealzcoreBase
- (instancetype)initWithSupplierId:(NSString *)supplierId useDeviceLanguage:(BOOL)useDeviceLanguage __attribute__((swift_name("init(supplierId:useDeviceLanguage:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreInitSupplierUseCaseInput *)doCopySupplierId:(NSString *)supplierId useDeviceLanguage:(BOOL)useDeviceLanguage __attribute__((swift_name("doCopy(supplierId:useDeviceLanguage:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *supplierId __attribute__((swift_name("supplierId")));
@property (readonly) BOOL useDeviceLanguage __attribute__((swift_name("useDeviceLanguage")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SetAnalyticsTrackingUseCase")))
@interface MealzcoreSetAnalyticsTrackingUseCase : MealzcoreBase <MealzcoreParameterisedUseCase>
- (instancetype)initWithEnvironment:(MealzcoreEnvironment *)environment __attribute__((swift_name("init(environment:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreKotlinUnit * _Nullable)invokeInput:(MealzcoreBoolean *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SetProfilingAllowedUseCase")))
@interface MealzcoreSetProfilingAllowedUseCase : MealzcoreBase <MealzcoreParameterisedUseCase>
- (instancetype)initWithUserStore:(id<MealzcoreUserStore>)userStore __attribute__((swift_name("init(userStore:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreSetProfilingAllowedUseCaseCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreKotlinUnit * _Nullable)invokeInput:(MealzcoreBoolean *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SetProfilingAllowedUseCase.Companion")))
@interface MealzcoreSetProfilingAllowedUseCaseCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSetProfilingAllowedUseCaseCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreSetProfilingAllowedUseCase *create __attribute__((swift_name("create")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckForPreviousAuthLessUserOrCreateItUseCase")))
@interface MealzcoreCheckForPreviousAuthLessUserOrCreateItUseCase : MealzcoreMainExecutor <MealzcoreUseCase>
- (instancetype)initWithUserRepository:(id<MealzcoreUserRepository>)userRepository basketStore:(id<MealzcoreBasketStore>)basketStore __attribute__((swift_name("init(userRepository:basketStore:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreKotlinUnit * _Nullable)invokeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke()"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetIsAnonymousModeEnableUseCase")))
@interface MealzcoreGetIsAnonymousModeEnableUseCase : MealzcoreBase <MealzcoreUseCase>
- (instancetype)initWithUserStore:(id<MealzcoreUserStore>)userStore __attribute__((swift_name("init(userStore:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreBoolean * _Nullable)invokeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke()"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SetLanguageUseCase")))
@interface MealzcoreSetLanguageUseCase : MealzcoreBase <MealzcoreParameterisedUseCase>
- (instancetype)initWithEnvironment:(MealzcoreEnvironment *)environment __attribute__((swift_name("init(environment:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreKotlinUnit * _Nullable)invokeInput:(MealzcoreSupportedLanguage *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@property (readonly) MealzcoreEnvironment *environment __attribute__((swift_name("environment")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SupportedLanguage")))
@interface MealzcoreSupportedLanguage : MealzcoreKotlinEnum<MealzcoreSupportedLanguage *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) MealzcoreSupportedLanguageCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) MealzcoreSupportedLanguage *english __attribute__((swift_name("english")));
@property (class, readonly) MealzcoreSupportedLanguage *french __attribute__((swift_name("french")));
@property (class, readonly) MealzcoreSupportedLanguage *romanian __attribute__((swift_name("romanian")));
+ (MealzcoreKotlinArray<MealzcoreSupportedLanguage *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreSupportedLanguage *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SupportedLanguage.Companion")))
@interface MealzcoreSupportedLanguageCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSupportedLanguageCompanion *shared __attribute__((swift_name("shared")));
- (MealzcoreSupportedLanguage * _Nullable)fromValueValue:(NSString *)value __attribute__((swift_name("fromValue(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnableRecipeLikeUseCase")))
@interface MealzcoreEnableRecipeLikeUseCase : MealzcoreBase <MealzcoreParameterisedUseCase>
- (instancetype)initWithUserStore:(id<MealzcoreUserStore>)userStore __attribute__((swift_name("init(userStore:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) MealzcoreEnableRecipeLikeUseCaseCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreKotlinUnit * _Nullable)invokeInput:(MealzcoreBoolean *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EnableRecipeLikeUseCase.Companion")))
@interface MealzcoreEnableRecipeLikeUseCaseCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreEnableRecipeLikeUseCaseCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreEnableRecipeLikeUseCase *create __attribute__((swift_name("create")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetRecipePriceOrRedirectInput")))
@interface MealzcoreGetRecipePriceOrRedirectInput : MealzcoreBase
- (instancetype)initWithRecipeId:(NSString *)recipeId numberOfGuest:(int32_t)numberOfGuest __attribute__((swift_name("init(recipeId:numberOfGuest:)"))) __attribute__((objc_designated_initializer));
@property (readonly) int32_t numberOfGuest __attribute__((swift_name("numberOfGuest")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateUserAuthInfoUseCaseInput")))
@interface MealzcoreUpdateUserAuthInfoUseCaseInput : MealzcoreBase
- (instancetype)initWithUserId:(NSString * _Nullable)userId authorization:(MealzcoreAuthorization *)authorization __attribute__((swift_name("init(userId:authorization:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreUpdateUserAuthInfoUseCaseInput *)doCopyUserId:(NSString * _Nullable)userId authorization:(MealzcoreAuthorization *)authorization __attribute__((swift_name("doCopy(userId:authorization:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreAuthorization *authorization __attribute__((swift_name("authorization")));
@property (readonly) NSString * _Nullable userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PaymentEventProps")))
@interface MealzcorePaymentEventProps : MealzcoreBase
- (instancetype)initWithPointOfSaleName:(NSString *)pointOfSaleName pointOfSaleId:(NSString *)pointOfSaleId mealzAmount:(NSString *)mealzAmount totalAmount:(NSString *)totalAmount basketId:(NSString *)basketId recipeCount:(NSString *)recipeCount mealzProducts:(NSString *)mealzProducts totalProducts:(NSString * _Nullable)totalProducts clientOrderId:(NSString * _Nullable)clientOrderId __attribute__((swift_name("init(pointOfSaleName:pointOfSaleId:mealzAmount:totalAmount:basketId:recipeCount:mealzProducts:totalProducts:clientOrderId:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *basketId __attribute__((swift_name("basketId")));
@property (readonly) NSString * _Nullable clientOrderId __attribute__((swift_name("clientOrderId")));
@property (readonly) NSString *mealzAmount __attribute__((swift_name("mealzAmount")));
@property (readonly) NSString *mealzProducts __attribute__((swift_name("mealzProducts")));
@property (readonly) NSString *pointOfSaleId __attribute__((swift_name("pointOfSaleId")));
@property (readonly) NSString *pointOfSaleName __attribute__((swift_name("pointOfSaleName")));
@property (readonly) NSString *recipeCount __attribute__((swift_name("recipeCount")));
@property (readonly) NSString *totalAmount __attribute__((swift_name("totalAmount")));
@property (readonly) NSString * _Nullable totalProducts __attribute__((swift_name("totalProducts")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PaymentUseCaseInput")))
@interface MealzcorePaymentUseCaseInput : MealzcoreBase
- (instancetype)initWithTotalPrice:(double)totalPrice totalProductCount:(MealzcoreInt * _Nullable)totalProductCount clientOrderId:(NSString * _Nullable)clientOrderId __attribute__((swift_name("init(totalPrice:totalProductCount:clientOrderId:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString * _Nullable clientOrderId __attribute__((swift_name("clientOrderId")));
@property (readonly) double totalPrice __attribute__((swift_name("totalPrice")));
@property (readonly) MealzcoreInt * _Nullable totalProductCount __attribute__((swift_name("totalProductCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SetForceStoreCallBackUseCase")))
@interface MealzcoreSetForceStoreCallBackUseCase : MealzcoreBase <MealzcoreParameterisedUseCase>
- (instancetype)initWithPointOfSaleRepository:(id<MealzcorePointOfSaleRepository>)pointOfSaleRepository __attribute__((swift_name("init(pointOfSaleRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreKotlinUnit * _Nullable)invokeInput:(MealzcoreSetForceStoreCallBackUseCaseInput *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SetForceStoreCallBackUseCaseInput")))
@interface MealzcoreSetForceStoreCallBackUseCaseInput : MealzcoreBase
- (instancetype)initWithCallBack:(void (^)(NSString *))callBack __attribute__((swift_name("init(callBack:)"))) __attribute__((objc_designated_initializer));
@property (readonly) void (^callBack)(NSString *) __attribute__((swift_name("callBack")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeleteRecipeUseCase")))
@interface MealzcoreDeleteRecipeUseCase : MealzcoreMainExecutor <MealzcoreParameterisedUseCase>
- (instancetype)initWithBasketStore:(id<MealzcoreBasketStore>)basketStore __attribute__((swift_name("init(basketStore:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreKotlinUnit * _Nullable)invokeInput:(NSString *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DoesRecipeExistUseCase")))
@interface MealzcoreDoesRecipeExistUseCase : MealzcoreMainExecutor <MealzcoreParameterisedUseCase>
- (instancetype)initWithRecipeRepository:(id<MealzcoreRecipeRepository>)recipeRepository __attribute__((swift_name("init(recipeRepository:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id<MealzcoreKotlinx_coroutines_coreDeferred> _Nullable)invokeInput:(MealzcoreDoesRecipeExistUseCaseInput *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DoesRecipeExistUseCaseInput")))
@interface MealzcoreDoesRecipeExistUseCaseInput : MealzcoreBase
- (instancetype)initWithRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId __attribute__((swift_name("init(recipeId:isExtId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreDoesRecipeExistUseCaseInput *)doCopyRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId __attribute__((swift_name("doCopy(recipeId:isExtId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isExtId __attribute__((swift_name("isExtId")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FetchRecipeFromIdUseCaseInput")))
@interface MealzcoreFetchRecipeFromIdUseCaseInput : MealzcoreBase
- (instancetype)initWithRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId isFromCatalog:(BOOL)isFromCatalog __attribute__((swift_name("init(recipeId:isExtId:isFromCatalog:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreFetchRecipeFromIdUseCaseInput *)doCopyRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId isFromCatalog:(BOOL)isFromCatalog __attribute__((swift_name("doCopy(recipeId:isExtId:isFromCatalog:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isExtId __attribute__((swift_name("isExtId")));
@property (readonly) BOOL isFromCatalog __attribute__((swift_name("isFromCatalog")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetRecipeIdWithExtIdUseCase")))
@interface MealzcoreGetRecipeIdWithExtIdUseCase : MealzcoreBase <MealzcoreParameterisedUseCase, MealzcoreKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithRecipeRepository:(id<MealzcoreRecipeRepository>)recipeRepository __attribute__((swift_name("init(recipeRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (id<MealzcoreKotlinx_coroutines_coreDeferred> _Nullable)invokeInput:(NSString *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IsRecipeInBasketUseCase")))
@interface MealzcoreIsRecipeInBasketUseCase : MealzcoreBase <MealzcoreParameterisedUseCase>
- (instancetype)initWithBasketStore:(id<MealzcoreBasketStore>)basketStore __attribute__((swift_name("init(basketStore:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts all Kotlin exceptions to errors.
*/
- (MealzcoreBoolean * _Nullable)invokeInput:(MealzcoreIsRecipeInBasketUseCaseInput *)input error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("invoke(input:)"))) __attribute__((swift_error(nonnull_error)));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IsRecipeInBasketUseCaseInput")))
@interface MealzcoreIsRecipeInBasketUseCaseInput : MealzcoreBase
- (instancetype)initWithRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId __attribute__((swift_name("init(recipeId:isExtId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreIsRecipeInBasketUseCaseInput *)doCopyRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId __attribute__((swift_name("doCopy(recipeId:isExtId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isExtId __attribute__((swift_name("isExtId")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddRecipeUseCaseInput")))
@interface MealzcoreAddRecipeUseCaseInput : MealzcoreBase
- (instancetype)initWithBasket:(MealzcoreBasket *)basket recipeToAdd:(NSArray<MealzcoreRecipeInfos *> *)recipeToAdd withoutIngredients:(BOOL)withoutIngredients __attribute__((swift_name("init(basket:recipeToAdd:withoutIngredients:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreAddRecipeUseCaseInput *)doCopyBasket:(MealzcoreBasket *)basket recipeToAdd:(NSArray<MealzcoreRecipeInfos *> *)recipeToAdd withoutIngredients:(BOOL)withoutIngredients __attribute__((swift_name("doCopy(basket:recipeToAdd:withoutIngredients:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasket *basket __attribute__((swift_name("basket")));
@property (readonly) NSArray<MealzcoreRecipeInfos *> *recipeToAdd __attribute__((swift_name("recipeToAdd")));
@property (readonly) BOOL withoutIngredients __attribute__((swift_name("withoutIngredients")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CanOrderRecipeUseCase")))
@interface MealzcoreCanOrderRecipeUseCase : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithRecipeRepository:(id<MealzcoreRecipeRepository>)recipeRepository __attribute__((swift_name("init(recipeRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeInput:(MealzcoreCanOrderRecipeUseCaseInput *)input completionHandler:(void (^)(NSDictionary<NSString *, MealzcoreBoolean *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(input:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CanOrderRecipeUseCaseInput")))
@interface MealzcoreCanOrderRecipeUseCaseInput : MealzcoreBase
- (instancetype)initWithRecipeIdList:(NSArray<NSString *> *)recipeIdList isExtId:(BOOL)isExtId __attribute__((swift_name("init(recipeIdList:isExtId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreCanOrderRecipeUseCaseInput *)doCopyRecipeIdList:(NSArray<NSString *> *)recipeIdList isExtId:(BOOL)isExtId __attribute__((swift_name("doCopy(recipeIdList:isExtId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isExtId __attribute__((swift_name("isExtId")));
@property (readonly) NSArray<NSString *> *recipeIdList __attribute__((swift_name("recipeIdList")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateRecipesUseCaseInput")))
@interface MealzcoreUpdateRecipesUseCaseInput : MealzcoreBase
- (instancetype)initWithBasket:(MealzcoreBasket *)basket recipesToUpdate:(NSArray<MealzcoreRecipeInfos *> *)recipesToUpdate __attribute__((swift_name("init(basket:recipesToUpdate:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreUpdateRecipesUseCaseInput *)doCopyBasket:(MealzcoreBasket *)basket recipesToUpdate:(NSArray<MealzcoreRecipeInfos *> *)recipesToUpdate __attribute__((swift_name("doCopy(basket:recipesToUpdate:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasket *basket __attribute__((swift_name("basket")));
@property (readonly) NSArray<MealzcoreRecipeInfos *> *recipesToUpdate __attribute__((swift_name("recipesToUpdate")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RetailerInput")))
@interface MealzcoreRetailerInput : MealzcoreBase
- (instancetype)initWithRetailerId:(NSString *)retailerId retailerName:(NSString *)retailerName __attribute__((swift_name("init(retailerId:retailerName:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRetailerInput *)doCopyRetailerId:(NSString *)retailerId retailerName:(NSString *)retailerName __attribute__((swift_name("doCopy(retailerId:retailerName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *retailerId __attribute__((swift_name("retailerId")));
@property NSString *retailerName __attribute__((swift_name("retailerName")));
@end

__attribute__((swift_name("BasketEntryContract")))
@protocol MealzcoreBasketEntryContract
@required
@end

__attribute__((swift_name("BasketEntryContractEffect")))
@interface MealzcoreBasketEntryContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("BasketEntryContractEvent")))
@interface MealzcoreBasketEntryContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryContractEvent.AddBasketEntry")))
@interface MealzcoreBasketEntryContractEventAddBasketEntry : MealzcoreBasketEntryContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)addBasketEntry __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryContractEventAddBasketEntry *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryContractEvent.Init")))
@interface MealzcoreBasketEntryContractEventInit : MealzcoreBasketEntryContractEvent
- (instancetype)initWithBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("init(basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketEntryContractEventInit *)doCopyBasketEntry:(MealzcoreBasketEntry *)basketEntry __attribute__((swift_name("doCopy(basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry *basketEntry __attribute__((swift_name("basketEntry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryContractEvent.LockFromParent")))
@interface MealzcoreBasketEntryContractEventLockFromParent : MealzcoreBasketEntryContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)lockFromParent __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryContractEventLockFromParent *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryContractEvent.ReAddBasketEntry")))
@interface MealzcoreBasketEntryContractEventReAddBasketEntry : MealzcoreBasketEntryContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)reAddBasketEntry __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryContractEventReAddBasketEntry *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryContractEvent.RemoveBasketEntry")))
@interface MealzcoreBasketEntryContractEventRemoveBasketEntry : MealzcoreBasketEntryContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)removeBasketEntry __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryContractEventRemoveBasketEntry *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryContractEvent.ReplaceBasketEntry")))
@interface MealzcoreBasketEntryContractEventReplaceBasketEntry : MealzcoreBasketEntryContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)replaceBasketEntry __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryContractEventReplaceBasketEntry *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryContractEvent.UnLockFromParent")))
@interface MealzcoreBasketEntryContractEventUnLockFromParent : MealzcoreBasketEntryContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unLockFromParent __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreBasketEntryContractEventUnLockFromParent *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryContractEvent.UpdateBasketEntryQty")))
@interface MealzcoreBasketEntryContractEventUpdateBasketEntryQty : MealzcoreBasketEntryContractEvent
- (instancetype)initWithQuantity:(int32_t)quantity __attribute__((swift_name("init(quantity:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketEntryContractEventUpdateBasketEntryQty *)doCopyQuantity:(int32_t)quantity __attribute__((swift_name("doCopy(quantity:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t quantity __attribute__((swift_name("quantity")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryContractState")))
@interface MealzcoreBasketEntryContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithStatus:(MealzcoreComponentUiState *)status basketEntry:(MealzcoreBasketEntry * _Nullable)basketEntry __attribute__((swift_name("init(status:basketEntry:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketEntryContractState *)doCopyStatus:(MealzcoreComponentUiState *)status basketEntry:(MealzcoreBasketEntry * _Nullable)basketEntry __attribute__((swift_name("doCopy(status:basketEntry:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasketEntry * _Nullable basketEntry __attribute__((swift_name("basketEntry")));
@property (readonly) MealzcoreComponentUiState *status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("BasketEntryViewModel")))
@interface MealzcoreBasketEntryViewModel : MealzcoreBaseViewModel<MealzcoreBasketEntryContractEvent *, MealzcoreBasketEntryContractState *, MealzcoreBasketEntryContractEffect *>
- (instancetype)initWithBasketEntryNotifier:(MealzcoreBasketEntryNotifier *)basketEntryNotifier __attribute__((swift_name("init(basketEntryNotifier:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)addBasketEntryOrUpdateIsAReplacement:(BOOL)isAReplacement __attribute__((swift_name("addBasketEntryOrUpdate(isAReplacement:)")));
- (MealzcoreBasketEntryContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreBasketEntryContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (BOOL)isSponsored __attribute__((swift_name("isSponsored()")));
- (void)launchReplaceProduct __attribute__((swift_name("launchReplaceProduct()")));
- (id<MealzcoreKotlinx_coroutines_coreJob>)listenProductQtySubjectChanges __attribute__((swift_name("listenProductQtySubjectChanges()")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<MealzcoreAnalytics> analytics __attribute__((swift_name("analytics")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> productQtySubject __attribute__((swift_name("productQtySubject")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> status __attribute__((swift_name("status")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryInRecipeViewModel")))
@interface MealzcoreBasketEntryInRecipeViewModel : MealzcoreBasketEntryViewModel
- (instancetype)initWithBasketEntryNotifier:(MealzcoreBasketEntryNotifier *)basketEntryNotifier ingredient:(MealzcoreIngredient *)ingredient initialGuests:(int32_t)initialGuests parentRecipeIsLoading:(id<MealzcoreKotlinx_coroutines_coreMutableStateFlow>)parentRecipeIsLoading __attribute__((swift_name("init(basketEntryNotifier:ingredient:initialGuests:parentRecipeIsLoading:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithBasketEntryNotifier:(MealzcoreBasketEntryNotifier *)basketEntryNotifier __attribute__((swift_name("init(basketEntryNotifier:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)addBasketEntryOrUpdateIsAReplacement:(BOOL)isAReplacement __attribute__((swift_name("addBasketEntryOrUpdate(isAReplacement:)")));
- (void)ignoreBasketEntryInRecipe __attribute__((swift_name("ignoreBasketEntryInRecipe()")));
- (void)launchReplaceProduct __attribute__((swift_name("launchReplaceProduct()")));
- (void)sendEntryEventEventName:(NSString *)eventName __attribute__((swift_name("sendEntryEvent(eventName:)")));
@property int32_t guests __attribute__((swift_name("guests")));
@property (readonly) MealzcoreIngredient *ingredient __attribute__((swift_name("ingredient")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> parentRecipeIsLoading __attribute__((swift_name("parentRecipeIsLoading")));
@property MealzcoreRecipe *recipe __attribute__((swift_name("recipe")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryStandaloneViewModel")))
@interface MealzcoreBasketEntryStandaloneViewModel : MealzcoreBasketEntryViewModel
- (instancetype)initWithBasketEntryNotifier:(MealzcoreBasketEntryNotifier *)basketEntryNotifier __attribute__((swift_name("init(basketEntryNotifier:)"))) __attribute__((objc_designated_initializer));
- (void)addBasketEntryOrUpdateIsAReplacement:(BOOL)isAReplacement __attribute__((swift_name("addBasketEntryOrUpdate(isAReplacement:)")));
- (void)launchReplaceProduct __attribute__((swift_name("launchReplaceProduct()")));
@end

__attribute__((swift_name("BasketTagContract")))
@protocol MealzcoreBasketTagContract
@required
@end

__attribute__((swift_name("BasketTagContractEffect")))
@interface MealzcoreBasketTagContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("BasketTagContractEvent")))
@interface MealzcoreBasketTagContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketTagContractEvent.SetRetailerProductId")))
@interface MealzcoreBasketTagContractEventSetRetailerProductId : MealzcoreBasketTagContractEvent
- (instancetype)initWithProductId:(NSString *)productId __attribute__((swift_name("init(productId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketTagContractEventSetRetailerProductId *)doCopyProductId:(NSString *)productId __attribute__((swift_name("doCopy(productId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *productId __attribute__((swift_name("productId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketTagContractState")))
@interface MealzcoreBasketTagContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithRecipeList:(MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *)recipeList __attribute__((swift_name("init(recipeList:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreBasketTagContractState *)doCopyRecipeList:(MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *)recipeList __attribute__((swift_name("doCopy(recipeList:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *recipeList __attribute__((swift_name("recipeList")));
@end

__attribute__((swift_name("BasketTagViewModel")))
@interface MealzcoreBasketTagViewModel : MealzcoreBaseViewModel<MealzcoreBasketTagContractEvent *, MealzcoreBasketTagContractState *, MealzcoreBasketTagContractEffect *>
- (instancetype)initWithVmRouter:(MealzcoreRouterOutletViewModel *)vmRouter __attribute__((swift_name("init(vmRouter:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (MealzcoreBasketTagContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)goToDetailRecipe:(MealzcoreRecipe *)recipe __attribute__((swift_name("goToDetail(recipe:)")));
- (void)handleEventEvent:(MealzcoreBasketTagContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CatalogContent")))
@interface MealzcoreCatalogContent : MealzcoreKotlinEnum<MealzcoreCatalogContent *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreCatalogContent *wordSearch __attribute__((swift_name("wordSearch")));
@property (class, readonly) MealzcoreCatalogContent *filterSearch __attribute__((swift_name("filterSearch")));
@property (class, readonly) MealzcoreCatalogContent *categoriesList __attribute__((swift_name("categoriesList")));
@property (class, readonly) MealzcoreCatalogContent *category __attribute__((swift_name("category")));
@property (class, readonly) MealzcoreCatalogContent *favorite __attribute__((swift_name("favorite")));
+ (MealzcoreKotlinArray<MealzcoreCatalogContent *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreCatalogContent *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("CatalogContract")))
@protocol MealzcoreCatalogContract
@required
@end

__attribute__((swift_name("CatalogContractEffect")))
@interface MealzcoreCatalogContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("CatalogContractEvent")))
@interface MealzcoreCatalogContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CatalogContractEvent.GoBack")))
@interface MealzcoreCatalogContractEventGoBack : MealzcoreCatalogContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)goBack __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreCatalogContractEventGoBack *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CatalogContractEvent.GoToFavorite")))
@interface MealzcoreCatalogContractEventGoToFavorite : MealzcoreCatalogContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)goToFavorite __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreCatalogContractEventGoToFavorite *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CatalogContractState")))
@interface MealzcoreCatalogContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithCategories:(MealzcoreBasicUiState<NSArray<MealzcorePackage *> *> *)categories canLoadMore:(BOOL)canLoadMore isLoadingPage:(BOOL)isLoadingPage content:(MealzcoreCatalogContent *)content dialogIsOpen:(BOOL)dialogIsOpen dialogContent:(MealzcoreDialogContent *)dialogContent enableFilters:(BOOL)enableFilters enablePreferences:(BOOL)enablePreferences openedCategoryId:(NSString *)openedCategoryId title:(NSString *)title subtitle:(NSString * _Nullable)subtitle __attribute__((swift_name("init(categories:canLoadMore:isLoadingPage:content:dialogIsOpen:dialogContent:enableFilters:enablePreferences:openedCategoryId:title:subtitle:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreCatalogContractState *)doCopyCategories:(MealzcoreBasicUiState<NSArray<MealzcorePackage *> *> *)categories canLoadMore:(BOOL)canLoadMore isLoadingPage:(BOOL)isLoadingPage content:(MealzcoreCatalogContent *)content dialogIsOpen:(BOOL)dialogIsOpen dialogContent:(MealzcoreDialogContent *)dialogContent enableFilters:(BOOL)enableFilters enablePreferences:(BOOL)enablePreferences openedCategoryId:(NSString *)openedCategoryId title:(NSString *)title subtitle:(NSString * _Nullable)subtitle __attribute__((swift_name("doCopy(categories:canLoadMore:isLoadingPage:content:dialogIsOpen:dialogContent:enableFilters:enablePreferences:openedCategoryId:title:subtitle:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL canLoadMore __attribute__((swift_name("canLoadMore")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcorePackage *> *> *categories __attribute__((swift_name("categories")));
@property (readonly) MealzcoreCatalogContent *content __attribute__((swift_name("content")));
@property (readonly) MealzcoreDialogContent *dialogContent __attribute__((swift_name("dialogContent")));
@property (readonly) BOOL dialogIsOpen __attribute__((swift_name("dialogIsOpen")));
@property (readonly) BOOL enableFilters __attribute__((swift_name("enableFilters")));
@property (readonly) BOOL enablePreferences __attribute__((swift_name("enablePreferences")));
@property (readonly) BOOL isLoadingPage __attribute__((swift_name("isLoadingPage")));
@property (readonly) NSString *openedCategoryId __attribute__((swift_name("openedCategoryId")));
@property (readonly) NSString * _Nullable subtitle __attribute__((swift_name("subtitle")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((swift_name("FilterViewModel")))
@interface MealzcoreFilterViewModel : MealzcoreBaseViewModel<MealzcoreFilterContractEvent *, MealzcoreFilterContractState *, MealzcoreFilterContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreFilterViewModelCompanion *companion __attribute__((swift_name("companion")));
- (void)applyFilter __attribute__((swift_name("applyFilter()")));
- (void)clear __attribute__((swift_name("clear()")));
- (MealzcoreFilterContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (int32_t)getActiveFilterCount __attribute__((swift_name("getActiveFilterCount()")));
- (NSString * _Nullable)getCategoryId __attribute__((swift_name("getCategoryId()")));
- (void)getRecipeCount __attribute__((swift_name("getRecipeCount()")));
- (NSDictionary<NSString *, NSString *> *)getSelectedFilters __attribute__((swift_name("getSelectedFilters()")));
- (void)handleEventEvent:(MealzcoreFilterContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (id<MealzcoreKotlinx_coroutines_coreFlow>)observeSideEffect __attribute__((swift_name("observeSideEffect()")));
- (void)sendFilterPageViewEvent __attribute__((swift_name("sendFilterPageViewEvent()")));
- (void)sendSearchPageViewEvent __attribute__((swift_name("sendSearchPageViewEvent()")));
- (void)setCatCatId:(NSString *)catId __attribute__((swift_name("setCat(catId:)")));
- (void)setDiscount __attribute__((swift_name("setDiscount()")));
- (void)setFavorite __attribute__((swift_name("setFavorite()")));
- (void)setSearchStringSearchString:(NSString * _Nullable)searchString __attribute__((swift_name("setSearchString(searchString:)")));
- (void)setSearchStringAndApplySearchString:(NSString *)searchString __attribute__((swift_name("setSearchStringAndApply(searchString:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<MealzcoreAnalytics> analytics __attribute__((swift_name("analytics")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<MealzcoreKotlinx_coroutines_coreCoroutineExceptionHandler> coroutineHandler __attribute__((swift_name("coroutineHandler")));
@property (readonly) NSString * _Nullable currentSearchString __attribute__((swift_name("currentSearchString")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) MealzcoreRecipeRepositoryImp *recipeRepositoryImp __attribute__((swift_name("recipeRepositoryImp")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CatalogFilterViewModel")))
@interface MealzcoreCatalogFilterViewModel : MealzcoreFilterViewModel
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)getRecipeCount __attribute__((swift_name("getRecipeCount()")));
- (NSDictionary<NSString *, NSString *> *)getSelectedFilters __attribute__((swift_name("getSelectedFilters()")));
@end

__attribute__((swift_name("CatalogViewModel")))
@interface MealzcoreCatalogViewModel : MealzcoreBaseViewModel<MealzcoreCatalogContractEvent *, MealzcoreCatalogContractState *, MealzcoreCatalogContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreCatalogViewModelCompanion *companion __attribute__((swift_name("companion")));
- (void)close __attribute__((swift_name("close()")));
- (MealzcoreCatalogContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)enableFiltersEnable:(BOOL)enable __attribute__((swift_name("enableFilters(enable:)")));
- (void)enablePreferencesEnable:(BOOL)enable __attribute__((swift_name("enablePreferences(enable:)")));
- (void)goToCategoriesList __attribute__((swift_name("goToCategoriesList()")));
- (void)goToCategoryCategoryId:(NSString *)categoryId categoryTitle:(NSString *)categoryTitle subtitle:(NSString * _Nullable)subtitle __attribute__((swift_name("goToCategory(categoryId:categoryTitle:subtitle:)")));
- (void)goToFavorites __attribute__((swift_name("goToFavorites()"))) __attribute__((deprecated("No longer used, use sendOpenMySpaceEvent")));
- (void)handleEventEvent:(MealzcoreCatalogContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)loadMore __attribute__((swift_name("loadMore()")));
- (void)onSimpleSearchContent:(MealzcoreCatalogContent *)content __attribute__((swift_name("onSimpleSearch(content:)")));
- (void)openFilter __attribute__((swift_name("openFilter()")));
- (void)openPreferences __attribute__((swift_name("openPreferences()")));
- (void)openSearch __attribute__((swift_name("openSearch()")));
- (void)pushInitialRoute __attribute__((swift_name("pushInitialRoute()")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)sendBasketDisplayEvent __attribute__((swift_name("sendBasketDisplayEvent()")));
- (void)sendOpenMySpaceEvent __attribute__((swift_name("sendOpenMySpaceEvent()")));
- (void)sendOpenPreferencesEvent __attribute__((swift_name("sendOpenPreferencesEvent()")));
- (void)sendPageViewEvent __attribute__((swift_name("sendPageViewEvent()")));
- (void)sendShowCollectionEventCategoryId:(NSString *)categoryId __attribute__((swift_name("sendShowCollectionEvent(categoryId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CatalogViewModel.Companion")))
@interface MealzcoreCatalogViewModelCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreCatalogViewModelCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *CATEGORIES_LIST_TITLE __attribute__((swift_name("CATEGORIES_LIST_TITLE")));
@property (readonly) NSString *FAVORITE_LIST_TITLE __attribute__((swift_name("FAVORITE_LIST_TITLE")));
@property (readonly) NSString *FILTER_LIST_TITLE __attribute__((swift_name("FILTER_LIST_TITLE")));
@property (readonly) NSString *RECIPE_LIST_TITLE __attribute__((swift_name("RECIPE_LIST_TITLE")));
@property (readonly) NSString *SEARCH_LIST_TITLE __attribute__((swift_name("SEARCH_LIST_TITLE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DialogContent")))
@interface MealzcoreDialogContent : MealzcoreKotlinEnum<MealzcoreDialogContent *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreDialogContent *filter __attribute__((swift_name("filter")));
@property (class, readonly) MealzcoreDialogContent *preferences __attribute__((swift_name("preferences")));
@property (class, readonly) MealzcoreDialogContent *search __attribute__((swift_name("search")));
+ (MealzcoreKotlinArray<MealzcoreDialogContent *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreDialogContent *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("RecipesPageContract")))
@protocol MealzcoreRecipesPageContract
@required
@end

__attribute__((swift_name("RecipesPageContractEffect")))
@interface MealzcoreRecipesPageContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("RecipesPageContractEvent")))
@interface MealzcoreRecipesPageContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipesPageContractState")))
@interface MealzcoreRecipesPageContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithRecipes:(MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *)recipes isFetchingNewPage:(BOOL)isFetchingNewPage __attribute__((swift_name("init(recipes:isFetchingNewPage:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipesPageContractState *)doCopyRecipes:(MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *)recipes isFetchingNewPage:(BOOL)isFetchingNewPage __attribute__((swift_name("doCopy(recipes:isFetchingNewPage:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isFetchingNewPage __attribute__((swift_name("isFetchingNewPage")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *recipes __attribute__((swift_name("recipes")));
@end

__attribute__((swift_name("RecipesPageViewModel")))
@interface MealzcoreRecipesPageViewModel : MealzcoreBaseViewModel<MealzcoreRecipesPageContractEvent *, MealzcoreRecipesPageContractState *, MealzcoreRecipesPageContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));
- (MealzcoreRecipesPageContractState *)createInitialState __attribute__((swift_name("createInitialState()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)getRecipesDependingOnPosIdCurrentPage:(int32_t)currentPage recipeSort:(MealzcoreRecipeSort *)recipeSort completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesDependingOnPosId(currentPage:recipeSort:completionHandler:)")));
- (void)handleEventEvent:(MealzcoreRecipesPageContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)loadPage __attribute__((swift_name("loadPage()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)loadPageForce:(BOOL)force __attribute__((swift_name("loadPage(force:)")));
- (void)onInit __attribute__((swift_name("onInit()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSArray<MealzcoreRecipe *> *)postFilterRecipesList:(NSArray<MealzcoreRecipe *> *)recipesList __attribute__((swift_name("postFilter(recipesList:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
@property (readonly) MealzcoreFilterViewModel *filterInstance __attribute__((swift_name("filterInstance")));
@end

__attribute__((swift_name("DynamicRecipeDetailContract")))
@protocol MealzcoreDynamicRecipeDetailContract
@required
@end

__attribute__((swift_name("DynamicRecipeDetailContractEffect")))
@interface MealzcoreDynamicRecipeDetailContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("DynamicRecipeDetailContractEvent")))
@interface MealzcoreDynamicRecipeDetailContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailContractEvent.AddAllRemainingIngredients")))
@interface MealzcoreDynamicRecipeDetailContractEventAddAllRemainingIngredients : MealzcoreDynamicRecipeDetailContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)addAllRemainingIngredients __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreDynamicRecipeDetailContractEventAddAllRemainingIngredients *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailContractEvent.Reset")))
@interface MealzcoreDynamicRecipeDetailContractEventReset : MealzcoreDynamicRecipeDetailContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)reset __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreDynamicRecipeDetailContractEventReset *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailContractEvent.SetRecipeId")))
@interface MealzcoreDynamicRecipeDetailContractEventSetRecipeId : MealzcoreDynamicRecipeDetailContractEvent
- (instancetype)initWithRecipeId:(NSString *)recipeId isMealzId:(BOOL)isMealzId __attribute__((swift_name("init(recipeId:isMealzId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreDynamicRecipeDetailContractEventSetRecipeId *)doCopyRecipeId:(NSString *)recipeId isMealzId:(BOOL)isMealzId __attribute__((swift_name("doCopy(recipeId:isMealzId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isMealzId __attribute__((swift_name("isMealzId")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailContractEvent.UpdateGuests")))
@interface MealzcoreDynamicRecipeDetailContractEventUpdateGuests : MealzcoreDynamicRecipeDetailContractEvent
- (instancetype)initWithGuests:(int32_t)guests __attribute__((swift_name("init(guests:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreDynamicRecipeDetailContractEventUpdateGuests *)doCopyGuests:(int32_t)guests __attribute__((swift_name("doCopy(guests:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t guests __attribute__((swift_name("guests")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailContractState")))
@interface MealzcoreDynamicRecipeDetailContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithRecipe:(MealzcoreBasicUiState<MealzcoreRecipe *> *)recipe recipeId:(NSString *)recipeId externalRecipeId:(NSString * _Nullable)externalRecipeId likeIsEnable:(BOOL)likeIsEnable __attribute__((swift_name("init(recipe:recipeId:externalRecipeId:likeIsEnable:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreDynamicRecipeDetailContractState *)doCopyRecipe:(MealzcoreBasicUiState<MealzcoreRecipe *> *)recipe recipeId:(NSString *)recipeId externalRecipeId:(NSString * _Nullable)externalRecipeId likeIsEnable:(BOOL)likeIsEnable __attribute__((swift_name("doCopy(recipe:recipeId:externalRecipeId:likeIsEnable:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable externalRecipeId __attribute__((swift_name("externalRecipeId")));
@property (readonly) BOOL likeIsEnable __attribute__((swift_name("likeIsEnable")));
@property (readonly) MealzcoreBasicUiState<MealzcoreRecipe *> *recipe __attribute__((swift_name("recipe")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((swift_name("DynamicRecipeDetailViewModel")))
@interface MealzcoreDynamicRecipeDetailViewModel : MealzcoreBaseViewModel<MealzcoreDynamicRecipeDetailContractEvent *, MealzcoreDynamicRecipeDetailContractState *, MealzcoreDynamicRecipeDetailContractEffect *>
- (instancetype)initWithContinueShopping:(void (^)(void))continueShopping changeProduct:(void (^)(NSString *))changeProduct __attribute__((swift_name("init(continueShopping:changeProduct:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)addProductsFromPreviousOrder __attribute__((swift_name("addProductsFromPreviousOrder()")));
- (void)clearRecipeGuest __attribute__((swift_name("clearRecipeGuest()")));
- (MealzcoreDynamicRecipeDetailContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)handleEventEvent:(MealzcoreDynamicRecipeDetailContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)sendCloseEvent __attribute__((swift_name("sendCloseEvent()")));
- (void)sendOrderedCloseEventRecipeId:(NSString *)recipeId __attribute__((swift_name("sendOrderedCloseEvent(recipeId:)")));
- (void)sendOrderedDisplayEventRecipeId:(NSString *)recipeId __attribute__((swift_name("sendOrderedDisplayEvent(recipeId:)")));
- (void)sendOrderedPageViewEventRecipeId:(NSString *)recipeId __attribute__((swift_name("sendOrderedPageViewEvent(recipeId:)")));
- (void)sendPageViewEventRecipeId:(NSString *)recipeId tab:(MealzcoreRecipeDetailTab * _Nullable)tab __attribute__((swift_name("sendPageViewEvent(recipeId:tab:)")));
- (void)sendSponsorDisplayEvent __attribute__((swift_name("sendSponsorDisplayEvent()")));
- (void)sendTabDisplayEventRecipeId:(NSString *)recipeId __attribute__((swift_name("sendTabDisplayEvent(recipeId:)")));
- (void)viewDidAppear __attribute__((swift_name("viewDidAppear()")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> canBeAddedProduct __attribute__((swift_name("canBeAddedProduct")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> canBeShownProducts __attribute__((swift_name("canBeShownProducts")));
@property (readonly) void (^changeProduct)(NSString *) __attribute__((swift_name("changeProduct")));
@property (readonly) void (^continueShopping)(void) __attribute__((swift_name("continueShopping")));
@property (readonly) MealzcoreDynamicRecipeDetailFooterViewModel *dynamicRecipeDetailFooterViewModel __attribute__((swift_name("dynamicRecipeDetailFooterViewModel")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> guestIsUpdating __attribute__((swift_name("guestIsUpdating"))) __attribute__((deprecated("use recipeIsUpdating instead")));
@property (readonly) BOOL isInBasket __attribute__((swift_name("isInBasket")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> oftenDeletedProduct __attribute__((swift_name("oftenDeletedProduct")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> outOfStockOrUnavailableProducts __attribute__((swift_name("outOfStockOrUnavailableProducts")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> outOfStockProducts __attribute__((swift_name("outOfStockProducts")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property MealzcoreRecipe *recipe __attribute__((swift_name("recipe")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> recipeGuests __attribute__((swift_name("recipeGuests")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> recipeIsUpdating __attribute__((swift_name("recipeIsUpdating")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> unavailableProduct __attribute__((swift_name("unavailableProduct")));
@end

__attribute__((swift_name("DynamicRecipeDetailFooterContract")))
@protocol MealzcoreDynamicRecipeDetailFooterContract
@required
@end

__attribute__((swift_name("DynamicRecipeDetailFooterContractEffect")))
@interface MealzcoreDynamicRecipeDetailFooterContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("DynamicRecipeDetailFooterContractEvent")))
@interface MealzcoreDynamicRecipeDetailFooterContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailFooterContractEvent.LockFromParent")))
@interface MealzcoreDynamicRecipeDetailFooterContractEventLockFromParent : MealzcoreDynamicRecipeDetailFooterContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)lockFromParent __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreDynamicRecipeDetailFooterContractEventLockFromParent *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailFooterContractEvent.OnTapContinueShopping")))
@interface MealzcoreDynamicRecipeDetailFooterContractEventOnTapContinueShopping : MealzcoreDynamicRecipeDetailFooterContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)onTapContinueShopping __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreDynamicRecipeDetailFooterContractEventOnTapContinueShopping *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailFooterContractEvent.SetGuests")))
@interface MealzcoreDynamicRecipeDetailFooterContractEventSetGuests : MealzcoreDynamicRecipeDetailFooterContractEvent
- (instancetype)initWithGuests:(int32_t)guests __attribute__((swift_name("init(guests:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreDynamicRecipeDetailFooterContractEventSetGuests *)doCopyGuests:(int32_t)guests __attribute__((swift_name("doCopy(guests:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t guests __attribute__((swift_name("guests")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailFooterContractEvent.SetIngredientsStatus")))
@interface MealzcoreDynamicRecipeDetailFooterContractEventSetIngredientsStatus : MealzcoreDynamicRecipeDetailFooterContractEvent
- (instancetype)initWithProductsInBasket:(NSArray<MealzcoreBasketEntry *> *)productsInBasket remainingAddableProducts:(NSArray<MealzcoreBasketEntry *> *)remainingAddableProducts __attribute__((swift_name("init(productsInBasket:remainingAddableProducts:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreDynamicRecipeDetailFooterContractEventSetIngredientsStatus *)doCopyProductsInBasket:(NSArray<MealzcoreBasketEntry *> *)productsInBasket remainingAddableProducts:(NSArray<MealzcoreBasketEntry *> *)remainingAddableProducts __attribute__((swift_name("doCopy(productsInBasket:remainingAddableProducts:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<MealzcoreBasketEntry *> *productsInBasket __attribute__((swift_name("productsInBasket")));
@property (readonly) NSArray<MealzcoreBasketEntry *> *remainingAddableProducts __attribute__((swift_name("remainingAddableProducts")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailFooterContractEvent.SetRecipe")))
@interface MealzcoreDynamicRecipeDetailFooterContractEventSetRecipe : MealzcoreDynamicRecipeDetailFooterContractEvent
- (instancetype)initWithRecipe:(MealzcoreRecipe *)recipe __attribute__((swift_name("init(recipe:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreDynamicRecipeDetailFooterContractEventSetRecipe *)doCopyRecipe:(MealzcoreRecipe *)recipe __attribute__((swift_name("doCopy(recipe:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreRecipe *recipe __attribute__((swift_name("recipe")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailFooterContractEvent.UnLockFromParent")))
@interface MealzcoreDynamicRecipeDetailFooterContractEventUnLockFromParent : MealzcoreDynamicRecipeDetailFooterContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unLockFromParent __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreDynamicRecipeDetailFooterContractEventUnLockFromParent *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailFooterContractState")))
@interface MealzcoreDynamicRecipeDetailFooterContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithPriceStatus:(MealzcoreComponentUiState *)priceStatus recipe:(MealzcoreRecipe * _Nullable)recipe guests:(MealzcoreInt * _Nullable)guests ingredientsStatus:(MealzcoreIngredientStatus *)ingredientsStatus __attribute__((swift_name("init(priceStatus:recipe:guests:ingredientsStatus:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreDynamicRecipeDetailFooterContractState *)doCopyPriceStatus:(MealzcoreComponentUiState *)priceStatus recipe:(MealzcoreRecipe * _Nullable)recipe guests:(MealzcoreInt * _Nullable)guests ingredientsStatus:(MealzcoreIngredientStatus *)ingredientsStatus __attribute__((swift_name("doCopy(priceStatus:recipe:guests:ingredientsStatus:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreInt * _Nullable guests __attribute__((swift_name("guests")));
@property (readonly) MealzcoreIngredientStatus *ingredientsStatus __attribute__((swift_name("ingredientsStatus")));
@property (readonly) MealzcoreComponentUiState *priceStatus __attribute__((swift_name("priceStatus")));
@property (readonly) MealzcoreRecipe * _Nullable recipe __attribute__((swift_name("recipe")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicRecipeDetailFooterViewModel")))
@interface MealzcoreDynamicRecipeDetailFooterViewModel : MealzcoreBaseViewModel<MealzcoreDynamicRecipeDetailFooterContractEvent *, MealzcoreDynamicRecipeDetailFooterContractState *, MealzcoreDynamicRecipeDetailFooterContractEffect *>
- (instancetype)initWithAddAllRemainingIngredients:(void (^)(void))addAllRemainingIngredients continueShopping:(void (^)(void))continueShopping __attribute__((swift_name("init(addAllRemainingIngredients:continueShopping:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (MealzcoreDynamicRecipeDetailFooterContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreDynamicRecipeDetailFooterContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> isAddingRemainingIngredients __attribute__((swift_name("isAddingRemainingIngredients"))) __attribute__((deprecated("use recipeIsUpdating inside DynamicRecipeDetailViewModel instead")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> priceOfProductsInBasket __attribute__((swift_name("priceOfProductsInBasket")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> priceOfRemainingProducts __attribute__((swift_name("priceOfRemainingProducts")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> priceProductsInBasketPerGuest __attribute__((swift_name("priceProductsInBasketPerGuest")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IngredientStatus")))
@interface MealzcoreIngredientStatus : MealzcoreBase
- (instancetype)initWithType:(MealzcoreIngredientStatusTypes *)type count:(int32_t)count __attribute__((swift_name("init(type:count:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreIngredientStatus *)doCopyType:(MealzcoreIngredientStatusTypes *)type count:(int32_t)count __attribute__((swift_name("doCopy(type:count:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t count __attribute__((swift_name("count")));
@property (readonly) MealzcoreIngredientStatusTypes *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IngredientStatusTypes")))
@interface MealzcoreIngredientStatusTypes : MealzcoreKotlinEnum<MealzcoreIngredientStatusTypes *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreIngredientStatusTypes *initialState __attribute__((swift_name("initialState")));
@property (class, readonly) MealzcoreIngredientStatusTypes *noMoreToAdd __attribute__((swift_name("noMoreToAdd")));
@property (class, readonly) MealzcoreIngredientStatusTypes *remainingIngredientsToBeAdded __attribute__((swift_name("remainingIngredientsToBeAdded")));
+ (MealzcoreKotlinArray<MealzcoreIngredientStatusTypes *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreIngredientStatusTypes *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("FactoryViewModel")))
@interface MealzcoreFactoryViewModel<T> : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)abolishInstanceKey:(NSString *)key __attribute__((swift_name("abolishInstance(key:)")));
- (T _Nullable)instantiateKey:(NSString *)key __attribute__((swift_name("instantiate(key:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FactoryViewModelViewModelContainer")))
@interface MealzcoreFactoryViewModelViewModelContainer<T> : MealzcoreBase
- (instancetype)initWithInstantiation:(int32_t)instantiation viewModel:(T _Nullable)viewModel __attribute__((swift_name("init(instantiation:viewModel:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreFactoryViewModelViewModelContainer<T> *)doCopyInstantiation:(int32_t)instantiation viewModel:(T _Nullable)viewModel __attribute__((swift_name("doCopy(instantiation:viewModel:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int32_t instantiation __attribute__((swift_name("instantiation")));
@property (readonly) T _Nullable viewModel __attribute__((swift_name("viewModel")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FavoriteFilterViewModel")))
@interface MealzcoreFavoriteFilterViewModel : MealzcoreFilterViewModel
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)getRecipeCount __attribute__((swift_name("getRecipeCount()")));
- (NSDictionary<NSString *, NSString *> *)getSelectedFilters __attribute__((swift_name("getSelectedFilters()")));
@end

__attribute__((swift_name("FavoritePageContract")))
@protocol MealzcoreFavoritePageContract
@required
@end

__attribute__((swift_name("FavoritePageContractEffect")))
@interface MealzcoreFavoritePageContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("FavoritePageContractEvent")))
@interface MealzcoreFavoritePageContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FavoritePageContractEvent.LoadPage")))
@interface MealzcoreFavoritePageContractEventLoadPage : MealzcoreFavoritePageContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loadPage __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreFavoritePageContractEventLoadPage *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FavoritePageContractState")))
@interface MealzcoreFavoritePageContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithFavoritesRecipes:(MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *)favoritesRecipes currentPage:(int32_t)currentPage isFetchingNewPage:(BOOL)isFetchingNewPage noMoreData:(BOOL)noMoreData __attribute__((swift_name("init(favoritesRecipes:currentPage:isFetchingNewPage:noMoreData:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreFavoritePageContractState *)doCopyFavoritesRecipes:(MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *)favoritesRecipes currentPage:(int32_t)currentPage isFetchingNewPage:(BOOL)isFetchingNewPage noMoreData:(BOOL)noMoreData __attribute__((swift_name("doCopy(favoritesRecipes:currentPage:isFetchingNewPage:noMoreData:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t currentPage __attribute__((swift_name("currentPage")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *favoritesRecipes __attribute__((swift_name("favoritesRecipes")));
@property (readonly) BOOL isFetchingNewPage __attribute__((swift_name("isFetchingNewPage")));
@property (readonly) BOOL noMoreData __attribute__((swift_name("noMoreData")));
@end

__attribute__((swift_name("FavoritePageViewModel")))
@interface MealzcoreFavoritePageViewModel : MealzcoreBaseViewModel<MealzcoreFavoritePageContractEvent *, MealzcoreFavoritePageContractState *, MealzcoreFavoritePageContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreFavoritePageViewModelCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreFavoritePageContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)handleEventEvent:(MealzcoreFavoritePageContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)searchSearchString:(NSString *)searchString __attribute__((swift_name("search(searchString:)")));
- (void)sendBackEvent __attribute__((swift_name("sendBackEvent()")));
- (void)sendBasketDisplayEvent __attribute__((swift_name("sendBasketDisplayEvent()")));
- (void)sendDisplayEventPath:(NSString *)path __attribute__((swift_name("sendDisplayEvent(path:)")));
- (void)sendExploreOurCatalogEvent __attribute__((swift_name("sendExploreOurCatalogEvent()")));
- (void)sendPageViewEvent __attribute__((swift_name("sendPageViewEvent()")));
- (void)viewDidAppear __attribute__((swift_name("viewDidAppear()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FavoritePageViewModel.Companion")))
@interface MealzcoreFavoritePageViewModelCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreFavoritePageViewModelCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSDictionary<NSString *, NSString *> *FILTERS __attribute__((swift_name("FILTERS")));
@end

__attribute__((swift_name("FilterContract")))
@protocol MealzcoreFilterContract
@required
@end

__attribute__((swift_name("FilterContractEffect")))
@interface MealzcoreFilterContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FilterContractEffect.OnUpdate")))
@interface MealzcoreFilterContractEffectOnUpdate : MealzcoreFilterContractEffect
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)onUpdate __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreFilterContractEffectOnUpdate *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("FilterContractEvent")))
@interface MealzcoreFilterContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FilterContractEvent.OnCostFilterChanged")))
@interface MealzcoreFilterContractEventOnCostFilterChanged : MealzcoreFilterContractEvent
- (instancetype)initWithCostFilter:(MealzcoreCatalogFilterOptions *)costFilter __attribute__((swift_name("init(costFilter:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreFilterContractEventOnCostFilterChanged *)doCopyCostFilter:(MealzcoreCatalogFilterOptions *)costFilter __attribute__((swift_name("doCopy(costFilter:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreCatalogFilterOptions *costFilter __attribute__((swift_name("costFilter")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FilterContractEvent.OnDifficultyChanged")))
@interface MealzcoreFilterContractEventOnDifficultyChanged : MealzcoreFilterContractEvent
- (instancetype)initWithDifficulty:(MealzcoreCatalogFilterOptions *)difficulty __attribute__((swift_name("init(difficulty:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreFilterContractEventOnDifficultyChanged *)doCopyDifficulty:(MealzcoreCatalogFilterOptions *)difficulty __attribute__((swift_name("doCopy(difficulty:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreCatalogFilterOptions *difficulty __attribute__((swift_name("difficulty")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FilterContractEvent.OnTimeFilterChanged")))
@interface MealzcoreFilterContractEventOnTimeFilterChanged : MealzcoreFilterContractEvent
- (instancetype)initWithTimeFilter:(MealzcoreCatalogFilterOptions *)timeFilter __attribute__((swift_name("init(timeFilter:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreFilterContractEventOnTimeFilterChanged *)doCopyTimeFilter:(MealzcoreCatalogFilterOptions *)timeFilter __attribute__((swift_name("doCopy(timeFilter:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreCatalogFilterOptions *timeFilter __attribute__((swift_name("timeFilter")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FilterContractState")))
@interface MealzcoreFilterContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithNumberOfResult:(int32_t)numberOfResult difficulty:(NSArray<MealzcoreCatalogFilterOptions *> *)difficulty cost:(NSArray<MealzcoreCatalogFilterOptions *> *)cost time:(NSArray<MealzcoreCatalogFilterOptions *> *)time searchString:(NSString * _Nullable)searchString isFavorite:(BOOL)isFavorite isDiscount:(BOOL)isDiscount category:(NSString * _Nullable)category __attribute__((swift_name("init(numberOfResult:difficulty:cost:time:searchString:isFavorite:isDiscount:category:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreFilterContractState *)doCopyNumberOfResult:(int32_t)numberOfResult difficulty:(NSArray<MealzcoreCatalogFilterOptions *> *)difficulty cost:(NSArray<MealzcoreCatalogFilterOptions *> *)cost time:(NSArray<MealzcoreCatalogFilterOptions *> *)time searchString:(NSString * _Nullable)searchString isFavorite:(BOOL)isFavorite isDiscount:(BOOL)isDiscount category:(NSString * _Nullable)category __attribute__((swift_name("doCopy(numberOfResult:difficulty:cost:time:searchString:isFavorite:isDiscount:category:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable category __attribute__((swift_name("category")));
@property (readonly) NSArray<MealzcoreCatalogFilterOptions *> *cost __attribute__((swift_name("cost")));
@property (readonly) NSArray<MealzcoreCatalogFilterOptions *> *difficulty __attribute__((swift_name("difficulty")));
@property (readonly) BOOL isDiscount __attribute__((swift_name("isDiscount")));
@property (readonly) BOOL isFavorite __attribute__((swift_name("isFavorite")));
@property (readonly) int32_t numberOfResult __attribute__((swift_name("numberOfResult")));
@property (readonly) NSString * _Nullable searchString __attribute__((swift_name("searchString")));
@property (readonly) NSArray<MealzcoreCatalogFilterOptions *> *time __attribute__((swift_name("time")));
@end

__attribute__((swift_name("FilterEffect")))
@interface MealzcoreFilterEffect : MealzcoreBase <MealzcoreEffect>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FilterEffect.OnUpdate")))
@interface MealzcoreFilterEffectOnUpdate : MealzcoreFilterEffect
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)onUpdate __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreFilterEffectOnUpdate *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FilterInstance")))
@interface MealzcoreFilterInstance : MealzcoreKotlinEnum<MealzcoreFilterInstance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreFilterInstance *catalog __attribute__((swift_name("catalog")));
@property (class, readonly) MealzcoreFilterInstance *mealPlanner __attribute__((swift_name("mealPlanner")));
@property (class, readonly) MealzcoreFilterInstance *favorites __attribute__((swift_name("favorites")));
+ (MealzcoreKotlinArray<MealzcoreFilterInstance *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreFilterInstance *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *displayName __attribute__((swift_name("displayName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FilterViewModel.Companion")))
@interface MealzcoreFilterViewModelCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreFilterViewModelCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreFilterContractState *filterState __attribute__((swift_name("filterState")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FilterViewModelFactory")))
@interface MealzcoreFilterViewModelFactory : MealzcoreFactoryViewModel<MealzcoreFilterViewModel *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreFilterViewModelFactoryCompanion *companion __attribute__((swift_name("companion")));
- (void)abolishInstanceKey:(NSString *)key __attribute__((swift_name("abolishInstance(key:)")));
- (MealzcoreFilterViewModel *)instantiateKey:(NSString *)key __attribute__((swift_name("instantiate(key:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FilterViewModelFactory.Companion")))
@interface MealzcoreFilterViewModelFactoryCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreFilterViewModelFactoryCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("ItemSelectorContract")))
@protocol MealzcoreItemSelectorContract
@required
@end

__attribute__((swift_name("ItemSelectorContractEffect")))
@interface MealzcoreItemSelectorContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("ItemSelectorContractEvent")))
@interface MealzcoreItemSelectorContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorContractEvent.InitStandalone")))
@interface MealzcoreItemSelectorContractEventInitStandalone : MealzcoreItemSelectorContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)getInitStandalone __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemSelectorContractEventInitStandalone *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorContractEvent.InitWithBasketEntry")))
@interface MealzcoreItemSelectorContractEventInitWithBasketEntry : MealzcoreItemSelectorContractEvent
- (instancetype)initWithBasketEntryId:(NSString *)basketEntryId __attribute__((swift_name("init(basketEntryId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreItemSelectorContractEventInitWithBasketEntry *)doCopyBasketEntryId:(NSString *)basketEntryId __attribute__((swift_name("doCopy(basketEntryId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *basketEntryId __attribute__((swift_name("basketEntryId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorContractEvent.InitWithIngredientId")))
@interface MealzcoreItemSelectorContractEventInitWithIngredientId : MealzcoreItemSelectorContractEvent
- (instancetype)initWithIngredientId:(NSString *)ingredientId __attribute__((swift_name("init(ingredientId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreItemSelectorContractEventInitWithIngredientId *)doCopyIngredientId:(NSString *)ingredientId __attribute__((swift_name("doCopy(ingredientId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *ingredientId __attribute__((swift_name("ingredientId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorContractEvent.ReturnToDetail")))
@interface MealzcoreItemSelectorContractEventReturnToDetail : MealzcoreItemSelectorContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)returnToDetail __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreItemSelectorContractEventReturnToDetail *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorContractEvent.Search")))
@interface MealzcoreItemSelectorContractEventSearch : MealzcoreItemSelectorContractEvent
- (instancetype)initWithSearchString:(NSString *)searchString __attribute__((swift_name("init(searchString:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreItemSelectorContractEventSearch *)doCopySearchString:(NSString *)searchString __attribute__((swift_name("doCopy(searchString:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *searchString __attribute__((swift_name("searchString")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorContractEvent.SelectItem")))
@interface MealzcoreItemSelectorContractEventSelectItem : MealzcoreItemSelectorContractEvent
- (instancetype)initWithItem:(MealzcoreItem *)item __attribute__((swift_name("init(item:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreItemSelectorContractEventSelectItem *)doCopyItem:(MealzcoreItem *)item __attribute__((swift_name("doCopy(item:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreItem *item __attribute__((swift_name("item")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorContractState")))
@interface MealzcoreItemSelectorContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithItems:(MealzcoreBasicUiState<NSArray<MealzcoreItem *> *> *)items selectedItem:(MealzcoreItem * _Nullable)selectedItem basketEntryId:(NSString * _Nullable)basketEntryId ingredientId:(NSString *)ingredientId ingredientName:(NSString *)ingredientName ingredientQuantity:(float)ingredientQuantity ingredientUnit:(NSString *)ingredientUnit combinedCapacity:(NSString * _Nullable)combinedCapacity guestCount:(int32_t)guestCount defaultRecipeGuest:(int32_t)defaultRecipeGuest isASubstitution:(BOOL)isASubstitution title:(NSString *)title searchPlaceholder:(NSString *)searchPlaceholder onItemSelected:(void (^)(MealzcoreItem *))onItemSelected __attribute__((swift_name("init(items:selectedItem:basketEntryId:ingredientId:ingredientName:ingredientQuantity:ingredientUnit:combinedCapacity:guestCount:defaultRecipeGuest:isASubstitution:title:searchPlaceholder:onItemSelected:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreItemSelectorContractState *)doCopyItems:(MealzcoreBasicUiState<NSArray<MealzcoreItem *> *> *)items selectedItem:(MealzcoreItem * _Nullable)selectedItem basketEntryId:(NSString * _Nullable)basketEntryId ingredientId:(NSString *)ingredientId ingredientName:(NSString *)ingredientName ingredientQuantity:(float)ingredientQuantity ingredientUnit:(NSString *)ingredientUnit combinedCapacity:(NSString * _Nullable)combinedCapacity guestCount:(int32_t)guestCount defaultRecipeGuest:(int32_t)defaultRecipeGuest isASubstitution:(BOOL)isASubstitution title:(NSString *)title searchPlaceholder:(NSString *)searchPlaceholder onItemSelected:(void (^)(MealzcoreItem *))onItemSelected __attribute__((swift_name("doCopy(items:selectedItem:basketEntryId:ingredientId:ingredientName:ingredientQuantity:ingredientUnit:combinedCapacity:guestCount:defaultRecipeGuest:isASubstitution:title:searchPlaceholder:onItemSelected:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable basketEntryId __attribute__((swift_name("basketEntryId")));
@property (readonly) NSString * _Nullable combinedCapacity __attribute__((swift_name("combinedCapacity")));
@property (readonly) int32_t defaultRecipeGuest __attribute__((swift_name("defaultRecipeGuest")));
@property (readonly) int32_t guestCount __attribute__((swift_name("guestCount")));
@property (readonly) NSString *ingredientId __attribute__((swift_name("ingredientId")));
@property (readonly) NSString *ingredientName __attribute__((swift_name("ingredientName")));
@property (readonly) float ingredientQuantity __attribute__((swift_name("ingredientQuantity")));
@property (readonly) NSString *ingredientUnit __attribute__((swift_name("ingredientUnit")));
@property (readonly) BOOL isASubstitution __attribute__((swift_name("isASubstitution")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreItem *> *> *items __attribute__((swift_name("items")));
@property (readonly) void (^onItemSelected)(MealzcoreItem *) __attribute__((swift_name("onItemSelected")));
@property (readonly) NSString *searchPlaceholder __attribute__((swift_name("searchPlaceholder")));
@property (readonly) MealzcoreItem * _Nullable selectedItem __attribute__((swift_name("selectedItem")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ItemSelectorEmptyStates")))
@interface MealzcoreItemSelectorEmptyStates : MealzcoreKotlinEnum<MealzcoreItemSelectorEmptyStates *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreItemSelectorEmptyStates *noResultsAfterSearch __attribute__((swift_name("noResultsAfterSearch")));
@property (class, readonly) MealzcoreItemSelectorEmptyStates *noSubstituteProducts __attribute__((swift_name("noSubstituteProducts")));
@property (class, readonly) MealzcoreItemSelectorEmptyStates *searchingForNewProduct __attribute__((swift_name("searchingForNewProduct")));
+ (MealzcoreKotlinArray<MealzcoreItemSelectorEmptyStates *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreItemSelectorEmptyStates *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("ItemSelectorViewModel")))
@interface MealzcoreItemSelectorViewModel : MealzcoreBaseViewModel<MealzcoreItemSelectorContractEvent *, MealzcoreItemSelectorContractState *, MealzcoreItemSelectorContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreItemSelectorContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreItemSelectorContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
@property (readonly) MealzcoreItemSelectorEmptyStates *emptyState __attribute__((swift_name("emptyState")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerFilterViewModel")))
@interface MealzcoreMealPlannerFilterViewModel : MealzcoreFilterViewModel
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)getRecipeCount __attribute__((swift_name("getRecipeCount()")));
- (NSDictionary<NSString *, NSString *> *)getSelectedFilters __attribute__((swift_name("getSelectedFilters()")));
@end

__attribute__((swift_name("MealPlannerBasketPreviewContract")))
@protocol MealzcoreMealPlannerBasketPreviewContract
@required
@end

__attribute__((swift_name("MealPlannerBasketPreviewContractEffect")))
@interface MealzcoreMealPlannerBasketPreviewContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("MealPlannerBasketPreviewContractEvent")))
@interface MealzcoreMealPlannerBasketPreviewContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerBasketPreviewContractState")))
@interface MealzcoreMealPlannerBasketPreviewContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithStatus:(MealzcoreComponentUiState *)status __attribute__((swift_name("init(status:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMealPlannerBasketPreviewContractState *)doCopyStatus:(MealzcoreComponentUiState *)status __attribute__((swift_name("doCopy(status:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreComponentUiState *status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("MealPlannerBasketPreviewViewModel")))
@interface MealzcoreMealPlannerBasketPreviewViewModel : MealzcoreBaseViewModel<MealzcoreMealPlannerBasketPreviewContractEvent *, MealzcoreMealPlannerBasketPreviewContractState *, MealzcoreMealPlannerBasketPreviewContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreMealPlannerBasketPreviewContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreMealPlannerBasketPreviewContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)onClickFinalize __attribute__((swift_name("onClickFinalize()")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
@property (readonly) int32_t budget __attribute__((swift_name("budget")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> isProcessing __attribute__((swift_name("isProcessing")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> productCount __attribute__((swift_name("productCount")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> recipesDetailsVM __attribute__((swift_name("recipesDetailsVM")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> totalPrice __attribute__((swift_name("totalPrice")));
@property BOOL vMInit __attribute__((swift_name("vMInit")));
@end

__attribute__((swift_name("MealPlannerBasketPreviewRecipeRowViewModel")))
@interface MealzcoreMealPlannerBasketPreviewRecipeRowViewModel : MealzcoreDynamicRecipeDetailViewModel
- (instancetype)initWithMealPlannerRowChangeNotifier:(id<MealzcoreNotifier>)mealPlannerRowChangeNotifier changeProduct:(void (^)(NSString *))changeProduct __attribute__((swift_name("init(mealPlannerRowChangeNotifier:changeProduct:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContinueShopping:(void (^)(void))continueShopping changeProduct:(void (^)(NSString *))changeProduct __attribute__((swift_name("init(continueShopping:changeProduct:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)deleteRecipe __attribute__((swift_name("deleteRecipe()")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
@property (readonly) void (^changeProduct)(NSString *) __attribute__((swift_name("changeProduct")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> deletedProduct __attribute__((swift_name("deletedProduct")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> foundProduct __attribute__((swift_name("foundProduct")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> productsInBasket __attribute__((swift_name("productsInBasket")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> recipeRowState __attribute__((swift_name("recipeRowState")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeRowState")))
@interface MealzcoreRecipeRowState : MealzcoreBase
- (instancetype)initWithAllFoundProductCount:(int32_t)allFoundProductCount recipePrice:(double)recipePrice childrenLoading:(BOOL)childrenLoading recipeDeleting:(BOOL)recipeDeleting recipePriceRefreshing:(BOOL)recipePriceRefreshing __attribute__((swift_name("init(allFoundProductCount:recipePrice:childrenLoading:recipeDeleting:recipePriceRefreshing:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipeRowState *)doCopyAllFoundProductCount:(int32_t)allFoundProductCount recipePrice:(double)recipePrice childrenLoading:(BOOL)childrenLoading recipeDeleting:(BOOL)recipeDeleting recipePriceRefreshing:(BOOL)recipePriceRefreshing __attribute__((swift_name("doCopy(allFoundProductCount:recipePrice:childrenLoading:recipeDeleting:recipePriceRefreshing:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t allFoundProductCount __attribute__((swift_name("allFoundProductCount")));
@property (readonly) BOOL childrenLoading __attribute__((swift_name("childrenLoading")));
@property (readonly) BOOL recipeDeleting __attribute__((swift_name("recipeDeleting")));
@property (readonly) double recipePrice __attribute__((swift_name("recipePrice")));
@property (readonly) BOOL recipePriceRefreshing __attribute__((swift_name("recipePriceRefreshing")));
@end

__attribute__((swift_name("MealPlannerFormContract")))
@protocol MealzcoreMealPlannerFormContract
@required
@end

__attribute__((swift_name("MealPlannerFormContractEffect")))
@interface MealzcoreMealPlannerFormContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("MealPlannerFormContractEvent")))
@interface MealzcoreMealPlannerFormContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerFormContractState")))
@interface MealzcoreMealPlannerFormContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithBudget:(int32_t)budget numberOfGuests:(int32_t)numberOfGuests numberOfMeals:(int32_t)numberOfMeals recipeMaxCount:(int32_t)recipeMaxCount uiState:(MealzcoreComponentUiState *)uiState __attribute__((swift_name("init(budget:numberOfGuests:numberOfMeals:recipeMaxCount:uiState:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMealPlannerFormContractState *)doCopyBudget:(int32_t)budget numberOfGuests:(int32_t)numberOfGuests numberOfMeals:(int32_t)numberOfMeals recipeMaxCount:(int32_t)recipeMaxCount uiState:(MealzcoreComponentUiState *)uiState __attribute__((swift_name("doCopy(budget:numberOfGuests:numberOfMeals:recipeMaxCount:uiState:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t budget __attribute__((swift_name("budget")));
@property (readonly) int32_t numberOfGuests __attribute__((swift_name("numberOfGuests")));
@property (readonly) int32_t numberOfMeals __attribute__((swift_name("numberOfMeals")));
@property (readonly) int32_t recipeMaxCount __attribute__((swift_name("recipeMaxCount")));
@property (readonly) MealzcoreComponentUiState *uiState __attribute__((swift_name("uiState")));
@end

__attribute__((swift_name("MealPlannerFormViewModel")))
@interface MealzcoreMealPlannerFormViewModel : MealzcoreBaseViewModel<MealzcoreMealPlannerFormContractEvent *, MealzcoreMealPlannerFormContractState *, MealzcoreMealPlannerFormContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreMealPlannerFormContractState *)createInitialState __attribute__((swift_name("createInitialState()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getRecipesForBudgetConstraintBudget:(int32_t)budget mealCount:(int32_t)mealCount guestCount:(int32_t)guestCount completionHandler:(void (^)(NSArray<NSString *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesForBudgetConstraint(budget:mealCount:guestCount:completionHandler:)")));
- (void)getRecipesMaxCountForBudgetConstraintBudget:(int32_t)budget guestCount:(int32_t)guestCount __attribute__((swift_name("getRecipesMaxCountForBudgetConstraint(budget:guestCount:)")));
- (void)handleEventEvent:(MealzcoreMealPlannerFormContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)onInitComponent __attribute__((swift_name("onInitComponent()")));
- (void)setBudgetAmount:(int32_t)amount __attribute__((swift_name("setBudget(amount:)")));
- (void)setNumberOfGuestsAmount:(int32_t)amount __attribute__((swift_name("setNumberOfGuests(amount:)")));
- (void)setNumberOfMealsMealCount:(int32_t)mealCount __attribute__((swift_name("setNumberOfMeals(mealCount:)")));
@property (readonly) id<MealzcoreMealPlannerStore> mealPlannerStore __attribute__((swift_name("mealPlannerStore")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreFlow> recipeCountFlow __attribute__((swift_name("recipeCountFlow")));
@end

__attribute__((swift_name("MealPlannerMealsContract")))
@protocol MealzcoreMealPlannerMealsContract
@required
@end

__attribute__((swift_name("MealPlannerMealsContractEffect")))
@interface MealzcoreMealPlannerMealsContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("MealPlannerMealsContractEvent")))
@interface MealzcoreMealPlannerMealsContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerMealsContractState")))
@interface MealzcoreMealPlannerMealsContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithMeals:(MealzcoreBasicUiState<NSArray<id> *> *)meals totalPrice:(double)totalPrice numberOfMeal:(int32_t)numberOfMeal availablePosition:(NSArray<MealzcoreInt *> *)availablePosition __attribute__((swift_name("init(meals:totalPrice:numberOfMeal:availablePosition:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMealPlannerMealsContractState *)doCopyMeals:(MealzcoreBasicUiState<NSArray<id> *> *)meals totalPrice:(double)totalPrice numberOfMeal:(int32_t)numberOfMeal availablePosition:(NSArray<MealzcoreInt *> *)availablePosition __attribute__((swift_name("doCopy(meals:totalPrice:numberOfMeal:availablePosition:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<MealzcoreInt *> *availablePosition __attribute__((swift_name("availablePosition")));
@property (readonly) MealzcoreBasicUiState<NSArray<id> *> *meals __attribute__((swift_name("meals")));
@property (readonly) int32_t numberOfMeal __attribute__((swift_name("numberOfMeal")));
@property (readonly) double totalPrice __attribute__((swift_name("totalPrice")));
@end

__attribute__((swift_name("MealPlannerMealsViewModel")))
@interface MealzcoreMealPlannerMealsViewModel : MealzcoreBaseViewModel<MealzcoreMealPlannerMealsContractEvent *, MealzcoreMealPlannerMealsContractState *, MealzcoreMealPlannerMealsContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)addRecipesToGroceriesList __attribute__((swift_name("addRecipesToGroceriesList()")));
- (void)calculAvailableBudgetOnNavigateToReplaceRecipeTotalPrice:(double)totalPrice recipeToReplacePrice:(MealzcoreDouble * _Nullable)recipeToReplacePrice __attribute__((swift_name("calculAvailableBudgetOnNavigateToReplaceRecipe(totalPrice:recipeToReplacePrice:)")));
- (MealzcoreMealPlannerMealsContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreMealPlannerMealsContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)onPullToRefreshWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("onPullToRefresh(completionHandler:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)removeRecipeRecipeIndex:(int32_t)recipeIndex __attribute__((swift_name("removeRecipe(recipeIndex:)")));
@end

__attribute__((swift_name("MealPlannerRecapContract")))
@protocol MealzcoreMealPlannerRecapContract
@required
@end

__attribute__((swift_name("MealPlannerRecapContractEffect")))
@interface MealzcoreMealPlannerRecapContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("MealPlannerRecapContractEvent")))
@interface MealzcoreMealPlannerRecapContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MealPlannerRecapContractState")))
@interface MealzcoreMealPlannerRecapContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithTotalPrice:(double)totalPrice numberOfMeals:(int32_t)numberOfMeals __attribute__((swift_name("init(totalPrice:numberOfMeals:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMealPlannerRecapContractState *)doCopyTotalPrice:(double)totalPrice numberOfMeals:(int32_t)numberOfMeals __attribute__((swift_name("doCopy(totalPrice:numberOfMeals:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t numberOfMeals __attribute__((swift_name("numberOfMeals")));
@property (readonly) double totalPrice __attribute__((swift_name("totalPrice")));
@end

__attribute__((swift_name("MealPlannerRecapViewModel")))
@interface MealzcoreMealPlannerRecapViewModel : MealzcoreBaseViewModel<MealzcoreMealPlannerRecapContractEvent *, MealzcoreMealPlannerRecapContractState *, MealzcoreMealPlannerRecapContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreMealPlannerRecapContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreMealPlannerRecapContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
@end

__attribute__((swift_name("MealPlannerReplaceRecipePageViewModel")))
@interface MealzcoreMealPlannerReplaceRecipePageViewModel : MealzcoreRecipesPageViewModel
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)addRecipeToMealPlannerRecipeId:(NSString *)recipeId index:(int32_t)index __attribute__((swift_name("addRecipeToMealPlanner(recipeId:index:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)getRecipesDependingOnPosIdCurrentPage:(int32_t)currentPage recipeSort:(MealzcoreRecipeSort *)recipeSort completionHandler:(void (^)(NSArray<MealzcoreRecipe *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getRecipesDependingOnPosId(currentPage:recipeSort:completionHandler:)")));
- (void)doInitPage __attribute__((swift_name("doInitPage()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSArray<MealzcoreRecipe *> *)postFilterRecipesList:(NSArray<MealzcoreRecipe *> *)recipesList __attribute__((swift_name("postFilter(recipesList:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)searchInput:(NSString *)input __attribute__((swift_name("search(input:)")));
@property (readonly) MealzcoreFilterViewModel *filterInstance __attribute__((swift_name("filterInstance")));
@end

__attribute__((swift_name("MyBasketContract")))
@protocol MealzcoreMyBasketContract
@required
@end

__attribute__((swift_name("MyBasketContractEffect")))
@interface MealzcoreMyBasketContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("MyBasketContractEvent")))
@interface MealzcoreMyBasketContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MyBasketContractState")))
@interface MealzcoreMyBasketContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithBasketStatus:(MealzcoreComponentUiState *)basketStatus totalPrice:(double)totalPrice productCount:(int32_t)productCount recipeCount:(int32_t)recipeCount __attribute__((swift_name("init(basketStatus:totalPrice:productCount:recipeCount:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMyBasketContractState *)doCopyBasketStatus:(MealzcoreComponentUiState *)basketStatus totalPrice:(double)totalPrice productCount:(int32_t)productCount recipeCount:(int32_t)recipeCount __attribute__((swift_name("doCopy(basketStatus:totalPrice:productCount:recipeCount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreComponentUiState *basketStatus __attribute__((swift_name("basketStatus")));
@property (readonly) int32_t productCount __attribute__((swift_name("productCount")));
@property (readonly) int32_t recipeCount __attribute__((swift_name("recipeCount")));
@property (readonly) double totalPrice __attribute__((swift_name("totalPrice")));
@end

__attribute__((swift_name("MyBasketViewModel")))
@interface MealzcoreMyBasketViewModel : MealzcoreBaseViewModel<MealzcoreMyBasketContractEvent *, MealzcoreMyBasketContractState *, MealzcoreMyBasketContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)abortTransferringBasketCompletion:(void (^)(MealzcoreBasket * _Nullable))completion __attribute__((swift_name("abortTransferringBasket(completion:)")));
- (void)changeTabSelectedtab:(MealzcoreMyBasketTab * _Nullable)selectedtab __attribute__((swift_name("changeTab(selectedtab:)")));
- (MealzcoreMyBasketContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreMyBasketContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)refreshBasketCompletion:(void (^)(MealzcoreBasket * _Nullable))completion __attribute__((swift_name("refreshBasket(completion:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)sendChooseProductTabEvent __attribute__((swift_name("sendChooseProductTabEvent()")));
- (void)sendChooseRecipesTabEvent __attribute__((swift_name("sendChooseRecipesTabEvent()")));
- (void)transferBasketIfPossibleNavigationFunction:(void (^)(NSString *))navigationFunction __attribute__((swift_name("transferBasketIfPossible(navigationFunction:)")));
@property id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> currentTab __attribute__((swift_name("currentTab")));
@end

__attribute__((swift_name("MyMealContract")))
@protocol MealzcoreMyMealContract
@required
@end

__attribute__((swift_name("MyMealContractEffect")))
@interface MealzcoreMyMealContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("MyMealContractEvent")))
@interface MealzcoreMyMealContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MyMealContractState")))
@interface MealzcoreMyMealContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithRecipes:(MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *)recipes totalPrice:(double)totalPrice productCount:(int32_t)productCount __attribute__((swift_name("init(recipes:totalPrice:productCount:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMyMealContractState *)doCopyRecipes:(MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *)recipes totalPrice:(double)totalPrice productCount:(int32_t)productCount __attribute__((swift_name("doCopy(recipes:totalPrice:productCount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t productCount __attribute__((swift_name("productCount")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *recipes __attribute__((swift_name("recipes")));
@property (readonly) double totalPrice __attribute__((swift_name("totalPrice")));
@end

__attribute__((swift_name("MyMealViewModel")))
@interface MealzcoreMyMealViewModel : MealzcoreBaseViewModel<MealzcoreMyMealContractEvent *, MealzcoreMyMealContractState *, MealzcoreMyMealContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreMyMealContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreMyMealContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)openItemSelectorForAddAProduct __attribute__((swift_name("openItemSelectorForAddAProduct()")));
- (void)redirectToStoreLocatorIfRequiredOrExecuteCallbackCallback:(id<MealzcoreRedirectOnStoreIfRequiredCallback>)callback __attribute__((swift_name("redirectToStoreLocatorIfRequiredOrExecuteCallback(callback:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)sendCloseMyMealsEvent __attribute__((swift_name("sendCloseMyMealsEvent()")));
- (void)sendMyMealShowEvent __attribute__((swift_name("sendMyMealShowEvent()")));
- (void)sendPageViewEvent __attribute__((swift_name("sendPageViewEvent()")));
@end

__attribute__((swift_name("RedirectOnStoreIfRequiredCallback")))
@protocol MealzcoreRedirectOnStoreIfRequiredCallback
@required
- (void)onStoreSelected __attribute__((swift_name("onStoreSelected()")));
@end

__attribute__((swift_name("MyMealRecipeContract")))
@protocol MealzcoreMyMealRecipeContract
@required
@end

__attribute__((swift_name("MyMealRecipeContractEffect")))
@interface MealzcoreMyMealRecipeContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("MyMealRecipeContractEvent")))
@interface MealzcoreMyMealRecipeContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MyMealRecipeContractState")))
@interface MealzcoreMyMealRecipeContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithRecipe:(MealzcoreBasicUiState<MealzcoreRecipe *> *)recipe __attribute__((swift_name("init(recipe:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMyMealRecipeContractState *)doCopyRecipe:(MealzcoreBasicUiState<MealzcoreRecipe *> *)recipe __attribute__((swift_name("doCopy(recipe:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasicUiState<MealzcoreRecipe *> *recipe __attribute__((swift_name("recipe")));
@end

__attribute__((swift_name("MyMealRecipeViewModel")))
@interface MealzcoreMyMealRecipeViewModel : MealzcoreBaseViewModel<MealzcoreMyMealRecipeContractEvent *, MealzcoreMyMealRecipeContractState *, MealzcoreMyMealRecipeContractEffect *>
- (instancetype)initWithRecipeId:(NSString *)recipeId __attribute__((swift_name("init(recipeId:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (MealzcoreMyMealRecipeContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)deleteRecipe __attribute__((swift_name("deleteRecipe()")));
- (void)handleEventEvent:(MealzcoreMyMealRecipeContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)onErrorException:(MealzcoreKotlinThrowable *)exception __attribute__((swift_name("onError(exception:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)sendRecipeDisplayEvent __attribute__((swift_name("sendRecipeDisplayEvent()")));
- (void)sendRecipeShowEvent __attribute__((swift_name("sendRecipeShowEvent()")));
- (void)viewDidAppear __attribute__((swift_name("viewDidAppear()")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> isDeletingRecipe __attribute__((swift_name("isDeletingRecipe")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> priceOfRecipe __attribute__((swift_name("priceOfRecipe")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> productsInBasket __attribute__((swift_name("productsInBasket")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> recipeGuests __attribute__((swift_name("recipeGuests")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((swift_name("MyMealButtonContract")))
@protocol MealzcoreMyMealButtonContract
@required
@end

__attribute__((swift_name("MyMealButtonContractEffect")))
@interface MealzcoreMyMealButtonContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("MyMealButtonContractEvent")))
@interface MealzcoreMyMealButtonContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MyMealButtonContractState")))
@interface MealzcoreMyMealButtonContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithRecipeCount:(MealzcoreBasicUiState<MealzcoreInt *> *)recipeCount __attribute__((swift_name("init(recipeCount:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMyMealButtonContractState *)doCopyRecipeCount:(MealzcoreBasicUiState<MealzcoreInt *> *)recipeCount __attribute__((swift_name("doCopy(recipeCount:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasicUiState<MealzcoreInt *> *recipeCount __attribute__((swift_name("recipeCount")));
@end

__attribute__((swift_name("MyMealButtonViewModel")))
@interface MealzcoreMyMealButtonViewModel : MealzcoreBaseViewModel<MealzcoreMyMealButtonContractEvent *, MealzcoreMyMealButtonContractState *, MealzcoreMyMealButtonContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreMyMealButtonContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreMyMealButtonContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
@end

__attribute__((swift_name("MyProductsContract")))
@protocol MealzcoreMyProductsContract
@required
@end

__attribute__((swift_name("MyProductsContractEffect")))
@interface MealzcoreMyProductsContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("MyProductsContractEvent")))
@interface MealzcoreMyProductsContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MyProductsContractState")))
@interface MealzcoreMyProductsContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithEntries:(MealzcoreBasicUiState<NSArray<MealzcoreBasketEntryViewModel *> *> *)entries __attribute__((swift_name("init(entries:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreMyProductsContractState *)doCopyEntries:(MealzcoreBasicUiState<NSArray<MealzcoreBasketEntryViewModel *> *> *)entries __attribute__((swift_name("doCopy(entries:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreBasketEntryViewModel *> *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("MyProductsViewModel")))
@interface MealzcoreMyProductsViewModel : MealzcoreBaseViewModel<MealzcoreMyProductsContractEvent *, MealzcoreMyProductsContractState *, MealzcoreMyProductsContractEffect *>
- (instancetype)initWithOpenItemSelector:(void (^)(NSString * _Nullable))openItemSelector __attribute__((swift_name("init(openItemSelector:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (MealzcoreMyProductsContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreMyProductsContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)openItemSelectorForAddAProduct __attribute__((swift_name("openItemSelectorForAddAProduct()")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)sendPageViewEvent __attribute__((swift_name("sendPageViewEvent()")));
- (void)viewDidAppear __attribute__((swift_name("viewDidAppear()")));
@property (readonly) void (^openItemSelector)(NSString * _Nullable) __attribute__((swift_name("openItemSelector")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MySpacePage")))
@interface MealzcoreMySpacePage : MealzcoreKotlinEnum<MealzcoreMySpacePage *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreMySpacePage *favorite __attribute__((swift_name("favorite")));
@property (class, readonly) MealzcoreMySpacePage *history __attribute__((swift_name("history")));
+ (MealzcoreKotlinArray<MealzcoreMySpacePage *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreMySpacePage *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *tabName __attribute__((swift_name("tabName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MySpaceViewModel")))
@interface MealzcoreMySpaceViewModel : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)setPageToNewPage:(MealzcoreMySpacePage *)newPage __attribute__((swift_name("setPageTo(newPage:)")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> page __attribute__((swift_name("page")));
@end

__attribute__((swift_name("OrderHistoryContract")))
@protocol MealzcoreOrderHistoryContract
@required
@end

__attribute__((swift_name("OrderHistoryContractEffect")))
@interface MealzcoreOrderHistoryContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("OrderHistoryContractEvent")))
@interface MealzcoreOrderHistoryContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OrderHistoryContractEvent.LoadPage")))
@interface MealzcoreOrderHistoryContractEventLoadPage : MealzcoreOrderHistoryContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)loadPage __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreOrderHistoryContractEventLoadPage *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OrderHistoryContractEvent.Search")))
@interface MealzcoreOrderHistoryContractEventSearch : MealzcoreOrderHistoryContractEvent
- (instancetype)initWithSearchString:(NSString *)searchString __attribute__((swift_name("init(searchString:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreOrderHistoryContractEventSearch *)doCopySearchString:(NSString *)searchString __attribute__((swift_name("doCopy(searchString:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *searchString __attribute__((swift_name("searchString")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OrderHistoryContractState")))
@interface MealzcoreOrderHistoryContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithBaskets:(MealzcoreBasicUiState<NSArray<MealzcoreBasket *> *> *)baskets currentPage:(int32_t)currentPage isFetchingNewPage:(BOOL)isFetchingNewPage noMoreData:(BOOL)noMoreData __attribute__((swift_name("init(baskets:currentPage:isFetchingNewPage:noMoreData:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreOrderHistoryContractState *)doCopyBaskets:(MealzcoreBasicUiState<NSArray<MealzcoreBasket *> *> *)baskets currentPage:(int32_t)currentPage isFetchingNewPage:(BOOL)isFetchingNewPage noMoreData:(BOOL)noMoreData __attribute__((swift_name("doCopy(baskets:currentPage:isFetchingNewPage:noMoreData:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreBasket *> *> *baskets __attribute__((swift_name("baskets")));
@property (readonly) int32_t currentPage __attribute__((swift_name("currentPage")));
@property (readonly) BOOL isFetchingNewPage __attribute__((swift_name("isFetchingNewPage")));
@property (readonly) BOOL noMoreData __attribute__((swift_name("noMoreData")));
@end

__attribute__((swift_name("OrderHistoryViewModel")))
@interface MealzcoreOrderHistoryViewModel : MealzcoreBaseViewModel<MealzcoreOrderHistoryContractEvent *, MealzcoreOrderHistoryContractState *, MealzcoreOrderHistoryContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clearRecipeSelection __attribute__((swift_name("clearRecipeSelection()")));
- (MealzcoreOrderHistoryContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (int32_t)getGuestForRecipeRecipe:(MealzcoreRecipe *)recipe basket:(MealzcoreBasket *)basket __attribute__((swift_name("getGuestForRecipe(recipe:basket:)")));
- (void)handleEventEvent:(MealzcoreOrderHistoryContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)loadPageIsForced:(BOOL)isForced __attribute__((swift_name("loadPage(isForced:)")));
- (void)orderSelectedRecipes __attribute__((swift_name("orderSelectedRecipes()")));
- (BOOL)recipeIsInCartRecipeId:(NSString *)recipeId __attribute__((swift_name("recipeIsInCart(recipeId:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)resetSearch __attribute__((swift_name("resetSearch()")));
- (void)sendBackEvent __attribute__((swift_name("sendBackEvent()")));
- (void)sendBasketDisplayEvent __attribute__((swift_name("sendBasketDisplayEvent()")));
- (void)sendDisplayEventPath:(NSString *)path __attribute__((swift_name("sendDisplayEvent(path:)")));
- (void)sendOrderBackEventBasketId:(NSString *)basketId __attribute__((swift_name("sendOrderBackEvent(basketId:)")));
- (void)sendOrderDisplayEventBasketId:(NSString *)basketId __attribute__((swift_name("sendOrderDisplayEvent(basketId:)")));
- (void)sendOrderPageViewEventBasketId:(NSString *)basketId __attribute__((swift_name("sendOrderPageViewEvent(basketId:)")));
- (void)sendPageViewEvent __attribute__((swift_name("sendPageViewEvent()")));
- (void)toggleSelectionOnRecipeRecipe:(MealzcoreRecipe *)recipe __attribute__((swift_name("toggleSelectionOnRecipe(recipe:)")));
- (void)viewDidAppear __attribute__((swift_name("viewDidAppear()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PreferencesContent")))
@interface MealzcorePreferencesContent : MealzcoreKotlinEnum<MealzcorePreferencesContent *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcorePreferencesContent *allPrefrences __attribute__((swift_name("allPrefrences")));
@property (class, readonly) MealzcorePreferencesContent *searchPrefrerences __attribute__((swift_name("searchPrefrerences")));
+ (MealzcoreKotlinArray<MealzcorePreferencesContent *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcorePreferencesContent *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("PreferencesContract")))
@protocol MealzcorePreferencesContract
@required
@end

__attribute__((swift_name("PreferencesContractEffect")))
@interface MealzcorePreferencesContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("PreferencesContractEvent")))
@interface MealzcorePreferencesContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PreferencesContractState")))
@interface MealzcorePreferencesContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithBasicState:(MealzcoreBasicUiState<MealzcorePreferencesContent *> *)basicState diets:(NSArray<MealzcoreCheckableTag *> *)diets ingredients:(NSArray<MealzcoreCheckableTag *> *)ingredients equipments:(NSArray<MealzcoreCheckableTag *> *)equipments recipesFound:(int32_t)recipesFound guests:(MealzcoreInt * _Nullable)guests __attribute__((swift_name("init(basicState:diets:ingredients:equipments:recipesFound:guests:)"))) __attribute__((objc_designated_initializer));
- (MealzcorePreferencesContractState *)doCopyBasicState:(MealzcoreBasicUiState<MealzcorePreferencesContent *> *)basicState diets:(NSArray<MealzcoreCheckableTag *> *)diets ingredients:(NSArray<MealzcoreCheckableTag *> *)ingredients equipments:(NSArray<MealzcoreCheckableTag *> *)equipments recipesFound:(int32_t)recipesFound guests:(MealzcoreInt * _Nullable)guests __attribute__((swift_name("doCopy(basicState:diets:ingredients:equipments:recipesFound:guests:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasicUiState<MealzcorePreferencesContent *> *basicState __attribute__((swift_name("basicState")));
@property (readonly) NSArray<MealzcoreCheckableTag *> *diets __attribute__((swift_name("diets")));
@property (readonly) NSArray<MealzcoreCheckableTag *> *equipments __attribute__((swift_name("equipments")));
@property (readonly) MealzcoreInt * _Nullable guests __attribute__((swift_name("guests")));
@property (readonly) NSArray<MealzcoreCheckableTag *> *ingredients __attribute__((swift_name("ingredients")));
@property (readonly) int32_t recipesFound __attribute__((swift_name("recipesFound")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PreferencesViewModelInstance")))
@interface MealzcorePreferencesViewModelInstance : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)preferencesViewModelInstance __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcorePreferencesViewModelInstance *shared __attribute__((swift_name("shared")));
@property (readonly) MealzcoreSingletonPreferencesViewModel *instance __attribute__((swift_name("instance")));
@end

__attribute__((swift_name("SingletonPreferencesViewModel")))
@interface MealzcoreSingletonPreferencesViewModel : MealzcoreBaseViewModel<MealzcorePreferencesContractEvent *, MealzcorePreferencesContractState *, MealzcorePreferencesContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreSingletonPreferencesViewModelCompanion *companion __attribute__((swift_name("companion")));
- (void)addIngredientPreferenceTag:(MealzcoreTag *)tag __attribute__((swift_name("addIngredientPreference(tag:)")));
- (void)applyPreferencesReset:(BOOL)reset __attribute__((swift_name("applyPreferences(reset:)")));
- (void)back __attribute__((swift_name("back()")));
- (void)changeGlobalGuestNumberOfGuest:(int32_t)numberOfGuest __attribute__((swift_name("changeGlobalGuest(numberOfGuest:)")));
- (void)clearPreferences __attribute__((swift_name("clearPreferences()")));
- (MealzcorePreferencesContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (int32_t)getActivePreferenceCount __attribute__((swift_name("getActivePreferenceCount()")));
- (NSDictionary<NSString *, NSString *> *)getPreferences __attribute__((swift_name("getPreferences()")));
- (MealzcoreInt * _Nullable)globalGuestCountOrNull __attribute__((swift_name("globalGuestCountOrNull()")));
- (void)goToAllPref __attribute__((swift_name("goToAllPref()")));
- (void)goToSearchPrefAndPushRoute __attribute__((swift_name("goToSearchPrefAndPushRoute()")));
- (MealzcoreInt * _Nullable)guestOrNullFromLocal __attribute__((swift_name("guestOrNullFromLocal()")));
- (void)handleEventEvent:(MealzcorePreferencesContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)resetPreferences __attribute__((swift_name("resetPreferences()")));
- (void)sendCloseEvent __attribute__((swift_name("sendCloseEvent()")));
- (void)sendPageViewEvent __attribute__((swift_name("sendPageViewEvent()")));
- (void)togglePreferenceTagIdToToggle:(NSString *)tagIdToToggle __attribute__((swift_name("togglePreference(tagIdToToggle:)")));
@property (readonly) NSArray<MealzcoreCheckableTag *> *allTags __attribute__((swift_name("allTags")));
@property (readonly) BOOL isInit __attribute__((swift_name("isInit")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SingletonPreferencesViewModel.Companion")))
@interface MealzcoreSingletonPreferencesViewModelCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreSingletonPreferencesViewModelCompanion *shared __attribute__((swift_name("shared")));
- (MealzcorePreferencesContractState *)getInitialPref __attribute__((swift_name("getInitialPref()")));
@property (readonly) NSString *LOCAL_DIET_KEY __attribute__((swift_name("LOCAL_DIET_KEY")));
@property (readonly) NSString *LOCAL_EQUIPMENT_KEY __attribute__((swift_name("LOCAL_EQUIPMENT_KEY")));
@property (readonly) NSString *LOCAL_GUEST_KEY __attribute__((swift_name("LOCAL_GUEST_KEY")));
@property (readonly) NSString *LOCAL_INGREDIENT_KEY __attribute__((swift_name("LOCAL_INGREDIENT_KEY")));
@property (readonly) NSArray<NSString *> *defaultIngredientTagIds __attribute__((swift_name("defaultIngredientTagIds")));
@end

__attribute__((swift_name("PreferencesSearchContract")))
@protocol MealzcorePreferencesSearchContract
@required
@end

__attribute__((swift_name("PreferencesSearchContractEffect")))
@interface MealzcorePreferencesSearchContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("PreferencesSearchContractEvent")))
@interface MealzcorePreferencesSearchContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PreferencesSearchContractState")))
@interface MealzcorePreferencesSearchContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithSearchProposal:(MealzcoreBasicUiState<NSArray<MealzcoreTag *> *> *)searchProposal __attribute__((swift_name("init(searchProposal:)"))) __attribute__((objc_designated_initializer));
- (MealzcorePreferencesSearchContractState *)doCopySearchProposal:(MealzcoreBasicUiState<NSArray<MealzcoreTag *> *> *)searchProposal __attribute__((swift_name("doCopy(searchProposal:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreTag *> *> *searchProposal __attribute__((swift_name("searchProposal")));
@end

__attribute__((swift_name("PreferencesSearchViewModel")))
@interface MealzcorePreferencesSearchViewModel : MealzcoreBaseViewModel<MealzcorePreferencesSearchContractEvent *, MealzcorePreferencesSearchContractState *, MealzcorePreferencesSearchContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcorePreferencesSearchContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcorePreferencesSearchContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)resetState __attribute__((swift_name("resetState()")));
- (void)searchSearch:(NSString *)search __attribute__((swift_name("search(search:)")));
@end

__attribute__((swift_name("PricingContract")))
@protocol MealzcorePricingContract
@required
@end

__attribute__((swift_name("PricingContractEffect")))
@interface MealzcorePricingContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("PricingContractEvent")))
@interface MealzcorePricingContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PricingContractState")))
@interface MealzcorePricingContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithPrice:(MealzcoreBasicUiState<MealzcoreRecipePricing *> *)price recipeId:(NSString * _Nullable)recipeId guestNumber:(MealzcoreInt * _Nullable)guestNumber __attribute__((swift_name("init(price:recipeId:guestNumber:)"))) __attribute__((objc_designated_initializer));
- (MealzcorePricingContractState *)doCopyPrice:(MealzcoreBasicUiState<MealzcoreRecipePricing *> *)price recipeId:(NSString * _Nullable)recipeId guestNumber:(MealzcoreInt * _Nullable)guestNumber __attribute__((swift_name("doCopy(price:recipeId:guestNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreInt * _Nullable guestNumber __attribute__((swift_name("guestNumber")));
@property (readonly) MealzcoreBasicUiState<MealzcoreRecipePricing *> *price __attribute__((swift_name("price")));
@property (readonly) NSString * _Nullable recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((swift_name("RecipePricingViewModel")))
@interface MealzcoreRecipePricingViewModel : MealzcoreBaseViewModel<MealzcorePricingContractEvent *, MealzcorePricingContractState *, MealzcorePricingContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcorePricingContractState *)createInitialState __attribute__((swift_name("createInitialState()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)doesRecipeExistRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId completionHandler:(void (^)(MealzcoreBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("doesRecipeExist(recipeId:isExtId:completionHandler:)")));
- (void)fetchPrice __attribute__((swift_name("fetchPrice()")));
- (void)handleEventEvent:(MealzcorePricingContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (id<MealzcoreKotlinx_coroutines_coreJob>)listenBasketChanges __attribute__((swift_name("listenBasketChanges()")));
- (void)onErrorException:(MealzcoreKotlinThrowable *)exception __attribute__((swift_name("onError(exception:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)setRecipeRecipeId:(NSString *)recipeId guestNumber:(int32_t)guestNumber isExtId:(BOOL)isExtId __attribute__((swift_name("setRecipe(recipeId:guestNumber:isExtId:)")));
- (void)setRecipeForMealPlannerRecipeId:(NSString *)recipeId __attribute__((swift_name("setRecipeForMealPlanner(recipeId:)")));
- (void)viewDidAppear __attribute__((swift_name("viewDidAppear()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("QuantityFormatter")))
@interface MealzcoreQuantityFormatter : MealzcoreBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreQuantityFormatterDefault *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("QuantityFormatter.default")))
@interface MealzcoreQuantityFormatterDefault : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreQuantityFormatterDefault *shared __attribute__((swift_name("shared")));
- (NSString *)fracValue:(float)value maxdenominator:(int32_t)maxdenominator __attribute__((swift_name("frac(value:maxdenominator:)")));
- (NSString *)pluralizeUnit:(NSString *)unit __attribute__((swift_name("pluralize(unit:)")));
- (NSString *)readableFloatNumberValue:(float)value unit:(NSString * _Nullable)unit __attribute__((swift_name("readableFloatNumber(value:unit:)")));
- (float)realQuantitiesQuantity:(NSString *)quantity currentGuest:(int32_t)currentGuest recipeGuest:(int32_t)recipeGuest __attribute__((swift_name("realQuantities(quantity:currentGuest:recipeGuest:)")));
- (NSString *)render_fracOriginal_value:(float)original_value num:(float)num denom:(float)denom __attribute__((swift_name("render_frac(original_value:num:denom:)")));
- (NSString *)singularizeUnit:(NSString *)unit __attribute__((swift_name("singularize(unit:)")));
@end

__attribute__((swift_name("RecipeContract")))
@protocol MealzcoreRecipeContract
@required
@end

__attribute__((swift_name("RecipeContractEffect")))
@interface MealzcoreRecipeContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeContractEffect.Disliked")))
@interface MealzcoreRecipeContractEffectDisliked : MealzcoreRecipeContractEffect
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)disliked __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeContractEffectDisliked *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeContractEffect.HideCard")))
@interface MealzcoreRecipeContractEffectHideCard : MealzcoreRecipeContractEffect
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)hideCard __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeContractEffectHideCard *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("RecipeContractEvent")))
@interface MealzcoreRecipeContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeContractEvent.Error")))
@interface MealzcoreRecipeContractEventError : MealzcoreRecipeContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)error __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeContractEventError *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeContractEvent.FetchRecipeFromCriteria")))
@interface MealzcoreRecipeContractEventFetchRecipeFromCriteria : MealzcoreRecipeContractEvent
- (instancetype)initWithCriteria:(MealzcoreSuggestionsCriteria *)criteria __attribute__((swift_name("init(criteria:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipeContractEventFetchRecipeFromCriteria *)doCopyCriteria:(MealzcoreSuggestionsCriteria *)criteria __attribute__((swift_name("doCopy(criteria:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreSuggestionsCriteria *criteria __attribute__((swift_name("criteria")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeContractEvent.FetchRecipeFromId")))
@interface MealzcoreRecipeContractEventFetchRecipeFromId : MealzcoreRecipeContractEvent
- (instancetype)initWithRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId __attribute__((swift_name("init(recipeId:isExtId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipeContractEventFetchRecipeFromId *)doCopyRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId __attribute__((swift_name("doCopy(recipeId:isExtId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isExtId __attribute__((swift_name("isExtId")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeContractEvent.GoToDetail")))
@interface MealzcoreRecipeContractEventGoToDetail : MealzcoreRecipeContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)goToDetail __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRecipeContractEventGoToDetail *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeContractEvent.GoToDetailWithPath")))
@interface MealzcoreRecipeContractEventGoToDetailWithPath : MealzcoreRecipeContractEvent
- (instancetype)initWithCurrentPage:(MealzcoreMealzPage *)currentPage categoryId:(NSString * _Nullable)categoryId __attribute__((swift_name("init(currentPage:categoryId:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipeContractEventGoToDetailWithPath *)doCopyCurrentPage:(MealzcoreMealzPage *)currentPage categoryId:(NSString * _Nullable)categoryId __attribute__((swift_name("doCopy(currentPage:categoryId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable categoryId __attribute__((swift_name("categoryId")));
@property (readonly) MealzcoreMealzPage *currentPage __attribute__((swift_name("currentPage")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeContractState")))
@interface MealzcoreRecipeContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithRecipeState:(MealzcoreBasicUiState<MealzcoreRecipe *> *)recipeState recipe:(MealzcoreRecipe * _Nullable)recipe headerText:(NSString *)headerText isInCart:(BOOL)isInCart likeIsEnable:(BOOL)likeIsEnable showPrice:(BOOL)showPrice __attribute__((swift_name("init(recipeState:recipe:headerText:isInCart:likeIsEnable:showPrice:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipeContractState *)doCopyRecipeState:(MealzcoreBasicUiState<MealzcoreRecipe *> *)recipeState recipe:(MealzcoreRecipe * _Nullable)recipe headerText:(NSString *)headerText isInCart:(BOOL)isInCart likeIsEnable:(BOOL)likeIsEnable showPrice:(BOOL)showPrice __attribute__((swift_name("doCopy(recipeState:recipe:headerText:isInCart:likeIsEnable:showPrice:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (MealzcoreRecipeContractState *)refreshFromGlBasketStore:(id<MealzcoreBasketStore>)basketStore __attribute__((swift_name("refreshFromGl(basketStore:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *headerText __attribute__((swift_name("headerText")));
@property (readonly) BOOL isInCart __attribute__((swift_name("isInCart")));
@property (readonly) BOOL likeIsEnable __attribute__((swift_name("likeIsEnable")));
@property (readonly) MealzcoreRecipe * _Nullable recipe __attribute__((swift_name("recipe")));
@property (readonly) MealzcoreBasicUiState<MealzcoreRecipe *> *recipeState __attribute__((swift_name("recipeState")));
@property (readonly) BOOL showPrice __attribute__((swift_name("showPrice")));
@end

__attribute__((swift_name("RecipeViewModel")))
@interface MealzcoreRecipeViewModel : MealzcoreBaseViewModel<MealzcoreRecipeContractEvent *, MealzcoreRecipeContractState *, MealzcoreRecipeContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreRecipeContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreRecipeContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)sendAnalyticsImpressionPath:(MealzcoreMealzPage *)path categoryId:(NSString * _Nullable)categoryId __attribute__((swift_name("sendAnalyticsImpression(path:categoryId:)")));
@property void (^goToDetail)(NSString *) __attribute__((swift_name("goToDetail")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreMutableStateFlow> guestsInBasket __attribute__((swift_name("guestsInBasket")));
@end

__attribute__((swift_name("RecipeCarouselContract")))
@protocol MealzcoreRecipeCarouselContract
@required
@end

__attribute__((swift_name("RecipeCarouselContractEffect")))
@interface MealzcoreRecipeCarouselContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("RecipeCarouselContractEvent")))
@interface MealzcoreRecipeCarouselContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeCarouselContractEvent.GetRecipeSuggestionsFromCriteria")))
@interface MealzcoreRecipeCarouselContractEventGetRecipeSuggestionsFromCriteria : MealzcoreRecipeCarouselContractEvent
- (instancetype)initWithCriteria:(MealzcoreSuggestionsCriteria *)criteria numberOfResult:(int32_t)numberOfResult __attribute__((swift_name("init(criteria:numberOfResult:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipeCarouselContractEventGetRecipeSuggestionsFromCriteria *)doCopyCriteria:(MealzcoreSuggestionsCriteria *)criteria numberOfResult:(int32_t)numberOfResult __attribute__((swift_name("doCopy(criteria:numberOfResult:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreSuggestionsCriteria *criteria __attribute__((swift_name("criteria")));
@property (readonly) int32_t numberOfResult __attribute__((swift_name("numberOfResult")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeCarouselContractEvent.GetRecipeSuggestionsFromId")))
@interface MealzcoreRecipeCarouselContractEventGetRecipeSuggestionsFromId : MealzcoreRecipeCarouselContractEvent
- (instancetype)initWithProductId:(NSString *)productId numberOfResult:(int32_t)numberOfResult __attribute__((swift_name("init(productId:numberOfResult:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipeCarouselContractEventGetRecipeSuggestionsFromId *)doCopyProductId:(NSString *)productId numberOfResult:(int32_t)numberOfResult __attribute__((swift_name("doCopy(productId:numberOfResult:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t numberOfResult __attribute__((swift_name("numberOfResult")));
@property (readonly) NSString *productId __attribute__((swift_name("productId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeCarouselContractState")))
@interface MealzcoreRecipeCarouselContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithSuggestions:(MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *)suggestions __attribute__((swift_name("init(suggestions:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipeCarouselContractState *)doCopySuggestions:(MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *)suggestions __attribute__((swift_name("doCopy(suggestions:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreRecipe *> *> *suggestions __attribute__((swift_name("suggestions")));
@end

__attribute__((swift_name("RecipeCarouselViewModel")))
@interface MealzcoreRecipeCarouselViewModel : MealzcoreBaseViewModel<MealzcoreRecipeCarouselContractEvent *, MealzcoreRecipeCarouselContractState *, MealzcoreRecipeCarouselContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreRecipeCarouselContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreRecipeCarouselContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
@end

__attribute__((swift_name("RecipeDetailButtonContract")))
@protocol MealzcoreRecipeDetailButtonContract
@required
@end

__attribute__((swift_name("RecipeDetailButtonContractEffect")))
@interface MealzcoreRecipeDetailButtonContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("RecipeDetailButtonContractEvent")))
@interface MealzcoreRecipeDetailButtonContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeDetailButtonContractState")))
@interface MealzcoreRecipeDetailButtonContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithDoesRecipeExistState:(MealzcoreBasicUiState<MealzcoreBoolean *> *)doesRecipeExistState recipeId:(NSString *)recipeId isExtId:(BOOL)isExtId isRecipeInBasket:(BOOL)isRecipeInBasket __attribute__((swift_name("init(doesRecipeExistState:recipeId:isExtId:isRecipeInBasket:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipeDetailButtonContractState *)doCopyDoesRecipeExistState:(MealzcoreBasicUiState<MealzcoreBoolean *> *)doesRecipeExistState recipeId:(NSString *)recipeId isExtId:(BOOL)isExtId isRecipeInBasket:(BOOL)isRecipeInBasket __attribute__((swift_name("doCopy(doesRecipeExistState:recipeId:isExtId:isRecipeInBasket:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasicUiState<MealzcoreBoolean *> *doesRecipeExistState __attribute__((swift_name("doesRecipeExistState")));
@property (readonly) BOOL isExtId __attribute__((swift_name("isExtId")));
@property (readonly) BOOL isRecipeInBasket __attribute__((swift_name("isRecipeInBasket")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((swift_name("RecipeDetailButtonViewModel")))
@interface MealzcoreRecipeDetailButtonViewModel : MealzcoreBaseViewModel<MealzcoreRecipeDetailButtonContractEvent *, MealzcoreRecipeDetailButtonContractState *, MealzcoreRecipeDetailButtonContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)ShouldItStopProcessAndRedirectOrContinueToDetailCallBack:(void (^)(void))callBack __attribute__((swift_name("ShouldItStopProcessAndRedirectOrContinueToDetail(callBack:)")));
- (void)checkIfRecipeExistsRecipeId:(NSString *)recipeId isExtId:(BOOL)isExtId __attribute__((swift_name("checkIfRecipeExists(recipeId:isExtId:)")));
- (MealzcoreRecipeDetailButtonContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreRecipeDetailButtonContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)onErrorException:(MealzcoreKotlinThrowable *)exception __attribute__((swift_name("onError(exception:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)viewDidAppear __attribute__((swift_name("viewDidAppear()")));
@end

__attribute__((swift_name("LikeButtonViewModel")))
@interface MealzcoreLikeButtonViewModel : MealzcoreBaseViewModel<MealzcoreRecipeLikeContractEvent *, MealzcoreRecipeLikeContractState *, MealzcoreRecipeLikeContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreRecipeLikeContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)handleEventEvent:(MealzcoreRecipeLikeContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
- (void)setRecipeRecipeId:(NSString *)recipeId __attribute__((swift_name("setRecipe(recipeId:)")));
- (void)toggleLikePath:(NSString *)path __attribute__((swift_name("toggleLike(path:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LikeButtonViewModelFactory")))
@interface MealzcoreLikeButtonViewModelFactory : MealzcoreFactoryViewModel<MealzcoreLikeButtonViewModel *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreLikeButtonViewModelFactoryCompanion *companion __attribute__((swift_name("companion")));
- (void)abolishInstanceKey:(NSString *)key __attribute__((swift_name("abolishInstance(key:)")));
- (MealzcoreLikeButtonViewModel *)instantiateKey:(NSString *)key __attribute__((swift_name("instantiate(key:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LikeButtonViewModelFactory.Companion")))
@interface MealzcoreLikeButtonViewModelFactoryCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreLikeButtonViewModelFactoryCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("RecipeLikeContract")))
@protocol MealzcoreRecipeLikeContract
@required
@end

__attribute__((swift_name("RecipeLikeContractEffect")))
@interface MealzcoreRecipeLikeContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("RecipeLikeContractEvent")))
@interface MealzcoreRecipeLikeContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecipeLikeContractState")))
@interface MealzcoreRecipeLikeContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithRecipeId:(NSString * _Nullable)recipeId isLiked:(MealzcoreBasicUiState<MealzcoreBoolean *> *)isLiked __attribute__((swift_name("init(recipeId:isLiked:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRecipeLikeContractState *)doCopyRecipeId:(NSString * _Nullable)recipeId isLiked:(MealzcoreBasicUiState<MealzcoreBoolean *> *)isLiked __attribute__((swift_name("doCopy(recipeId:isLiked:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreBasicUiState<MealzcoreBoolean *> *isLiked __attribute__((swift_name("isLiked")));
@property (readonly) NSString * _Nullable recipeId __attribute__((swift_name("recipeId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouterContent")))
@interface MealzcoreRouterContent : MealzcoreKotlinEnum<MealzcoreRouterContent *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) MealzcoreRouterContent *recipeDetail __attribute__((swift_name("recipeDetail")));
@property (class, readonly) MealzcoreRouterContent *recipeHelper __attribute__((swift_name("recipeHelper")));
@property (class, readonly) MealzcoreRouterContent *recipeSponsor __attribute__((swift_name("recipeSponsor")));
@property (class, readonly) MealzcoreRouterContent *basketPreview __attribute__((swift_name("basketPreview")));
@property (class, readonly) MealzcoreRouterContent *itemsSelector __attribute__((swift_name("itemsSelector")));
@property (class, readonly) MealzcoreRouterContent *empty __attribute__((swift_name("empty")));
+ (MealzcoreKotlinArray<MealzcoreRouterContent *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<MealzcoreRouterContent *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("RouterOutletContract")))
@protocol MealzcoreRouterOutletContract
@required
@end

__attribute__((swift_name("RouterOutletContractEffect")))
@interface MealzcoreRouterOutletContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("RouterOutletContractEvent")))
@interface MealzcoreRouterOutletContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouterOutletContractEvent.GoToDetail")))
@interface MealzcoreRouterOutletContractEventGoToDetail : MealzcoreRouterOutletContractEvent
- (instancetype)initWithVm:(MealzcoreRecipeViewModel *)vm withFooter:(BOOL)withFooter showGuestCounter:(BOOL)showGuestCounter __attribute__((swift_name("init(vm:withFooter:showGuestCounter:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRouterOutletContractEventGoToDetail *)doCopyVm:(MealzcoreRecipeViewModel *)vm withFooter:(BOOL)withFooter showGuestCounter:(BOOL)showGuestCounter __attribute__((swift_name("doCopy(vm:withFooter:showGuestCounter:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL showGuestCounter __attribute__((swift_name("showGuestCounter")));
@property (readonly) MealzcoreRecipeViewModel *vm __attribute__((swift_name("vm")));
@property (readonly) BOOL withFooter __attribute__((swift_name("withFooter")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouterOutletContractEvent.GoToHelper")))
@interface MealzcoreRouterOutletContractEventGoToHelper : MealzcoreRouterOutletContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)goToHelper __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRouterOutletContractEventGoToHelper *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouterOutletContractEvent.GoToItemSelector")))
@interface MealzcoreRouterOutletContractEventGoToItemSelector : MealzcoreRouterOutletContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)goToItemSelector __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRouterOutletContractEventGoToItemSelector *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouterOutletContractEvent.GoToPreview")))
@interface MealzcoreRouterOutletContractEventGoToPreview : MealzcoreRouterOutletContractEvent
- (instancetype)initWithRecipeId:(NSString *)recipeId vm:(MealzcoreRecipeViewModel *)vm __attribute__((swift_name("init(recipeId:vm:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRouterOutletContractEventGoToPreview *)doCopyRecipeId:(NSString *)recipeId vm:(MealzcoreRecipeViewModel *)vm __attribute__((swift_name("doCopy(recipeId:vm:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *recipeId __attribute__((swift_name("recipeId")));
@property (readonly) MealzcoreRecipeViewModel *vm __attribute__((swift_name("vm")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouterOutletContractEvent.GoToSponsor")))
@interface MealzcoreRouterOutletContractEventGoToSponsor : MealzcoreRouterOutletContractEvent
- (instancetype)initWithSponsor:(MealzcoreSponsor *)sponsor __attribute__((swift_name("init(sponsor:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRouterOutletContractEventGoToSponsor *)doCopySponsor:(MealzcoreSponsor *)sponsor __attribute__((swift_name("doCopy(sponsor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreSponsor *sponsor __attribute__((swift_name("sponsor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouterOutletContractEvent.OpenDialog")))
@interface MealzcoreRouterOutletContractEventOpenDialog : MealzcoreRouterOutletContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)openDialog __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRouterOutletContractEventOpenDialog *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouterOutletContractEvent.Previous")))
@interface MealzcoreRouterOutletContractEventPrevious : MealzcoreRouterOutletContractEvent
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)previous __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreRouterOutletContractEventPrevious *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RouterOutletContractState")))
@interface MealzcoreRouterOutletContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithContent:(MealzcoreRouterContent *)content rvm:(MealzcoreRecipeViewModel * _Nullable)rvm recipeId:(NSString * _Nullable)recipeId sponsor:(MealzcoreSponsor * _Nullable)sponsor isOpen:(BOOL)isOpen showFooter:(BOOL)showFooter showGuestCounter:(BOOL)showGuestCounter __attribute__((swift_name("init(content:rvm:recipeId:sponsor:isOpen:showFooter:showGuestCounter:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreRouterOutletContractState *)doCopyContent:(MealzcoreRouterContent *)content rvm:(MealzcoreRecipeViewModel * _Nullable)rvm recipeId:(NSString * _Nullable)recipeId sponsor:(MealzcoreSponsor * _Nullable)sponsor isOpen:(BOOL)isOpen showFooter:(BOOL)showFooter showGuestCounter:(BOOL)showGuestCounter __attribute__((swift_name("doCopy(content:rvm:recipeId:sponsor:isOpen:showFooter:showGuestCounter:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreRouterContent *content __attribute__((swift_name("content")));
@property (readonly) BOOL isOpen __attribute__((swift_name("isOpen")));
@property (readonly) NSString * _Nullable recipeId __attribute__((swift_name("recipeId")));
@property (readonly) MealzcoreRecipeViewModel * _Nullable rvm __attribute__((swift_name("rvm")));
@property (readonly) BOOL showFooter __attribute__((swift_name("showFooter")));
@property (readonly) BOOL showGuestCounter __attribute__((swift_name("showGuestCounter")));
@property (readonly) MealzcoreSponsor * _Nullable sponsor __attribute__((swift_name("sponsor")));
@end

__attribute__((swift_name("RouterOutletViewModel")))
@interface MealzcoreRouterOutletViewModel : MealzcoreBaseViewModel<MealzcoreRouterOutletContractEvent *, MealzcoreRouterOutletContractState *, MealzcoreRouterOutletContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreRouterOutletContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)goToDetailVmRecipe:(MealzcoreRecipeViewModel *)vmRecipe showDetailsFooter:(BOOL)showDetailsFooter showGuestCounter:(BOOL)showGuestCounter __attribute__((swift_name("goToDetail(vmRecipe:showDetailsFooter:showGuestCounter:)")));
- (void)goToPreviewVmRecipe:(MealzcoreRecipeViewModel *)vmRecipe recipeId:(NSString *)recipeId __attribute__((swift_name("goToPreview(vmRecipe:recipeId:)")));
- (void)handleEventEvent:(MealzcoreRouterOutletContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
@end

__attribute__((swift_name("SponsorDetailsContract")))
@protocol MealzcoreSponsorDetailsContract
@required
@end

__attribute__((swift_name("SponsorDetailsContractEffect")))
@interface MealzcoreSponsorDetailsContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("SponsorDetailsContractEvent")))
@interface MealzcoreSponsorDetailsContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorDetailsContractState")))
@interface MealzcoreSponsorDetailsContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithSponsorBlocks:(MealzcoreBasicUiState<NSArray<MealzcoreSponsorBlock *> *> *)sponsorBlocks sponsor:(MealzcoreSponsor * _Nullable)sponsor __attribute__((swift_name("init(sponsorBlocks:sponsor:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreSponsorDetailsContractState *)doCopySponsorBlocks:(MealzcoreBasicUiState<NSArray<MealzcoreSponsorBlock *> *> *)sponsorBlocks sponsor:(MealzcoreSponsor * _Nullable)sponsor __attribute__((swift_name("doCopy(sponsorBlocks:sponsor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreSponsor * _Nullable sponsor __attribute__((swift_name("sponsor")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreSponsorBlock *> *> *sponsorBlocks __attribute__((swift_name("sponsorBlocks")));
@end

__attribute__((swift_name("SponsorDetailsViewModel")))
@interface MealzcoreSponsorDetailsViewModel : MealzcoreBaseViewModel<MealzcoreSponsorDetailsContractEvent *, MealzcoreSponsorDetailsContractState *, MealzcoreSponsorDetailsContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (MealzcoreSponsorDetailsContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)fetchSponsorBlockByIdsSponsor:(MealzcoreSponsor *)sponsor __attribute__((swift_name("fetchSponsorBlockByIds(sponsor:)")));
- (void)handleEventEvent:(MealzcoreSponsorDetailsContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorDetailState")))
@interface MealzcoreSponsorDetailState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithSponsorBlocks:(MealzcoreBasicUiState<NSArray<MealzcoreSponsorBlock *> *> *)sponsorBlocks sponsor:(MealzcoreSponsor * _Nullable)sponsor __attribute__((swift_name("init(sponsorBlocks:sponsor:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreSponsorDetailState *)doCopySponsorBlocks:(MealzcoreBasicUiState<NSArray<MealzcoreSponsorBlock *> *> *)sponsorBlocks sponsor:(MealzcoreSponsor * _Nullable)sponsor __attribute__((swift_name("doCopy(sponsorBlocks:sponsor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) MealzcoreSponsor * _Nullable sponsor __attribute__((swift_name("sponsor")));
@property (readonly) MealzcoreBasicUiState<NSArray<MealzcoreSponsorBlock *> *> *sponsorBlocks __attribute__((swift_name("sponsorBlocks")));
@end

__attribute__((swift_name("SponsorDetailViewModel")))
@protocol MealzcoreSponsorDetailViewModel
@required
- (void)fetchSponsorBlockByIdsSponsor:(MealzcoreSponsor *)sponsor __attribute__((swift_name("fetchSponsorBlockByIds(sponsor:)")));
- (void)fetchSponsorBlockByIdsSponsorId:(NSString *)sponsorId __attribute__((swift_name("fetchSponsorBlockByIds(sponsorId:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SponsorDetailViewModelImpl")))
@interface MealzcoreSponsorDetailViewModelImpl : MealzcoreBase <MealzcoreKotlinx_coroutines_coreCoroutineScope, MealzcoreSponsorDetailViewModel>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)fetchSponsorBlockByIdsSponsor:(MealzcoreSponsor *)sponsor __attribute__((swift_name("fetchSponsorBlockByIds(sponsor:)")));
- (void)fetchSponsorBlockByIdsSponsorId:(NSString *)sponsorId __attribute__((swift_name("fetchSponsorBlockByIds(sponsorId:)")));
@property (readonly) id<MealzcoreKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreStateFlow> state __attribute__((swift_name("state")));
@end

__attribute__((swift_name("StoreLocatorButtonContract")))
@protocol MealzcoreStoreLocatorButtonContract
@required
@end

__attribute__((swift_name("StoreLocatorButtonContractEffect")))
@interface MealzcoreStoreLocatorButtonContractEffect : MealzcoreBase <MealzcoreUiEffect>
@end

__attribute__((swift_name("StoreLocatorButtonContractEvent")))
@interface MealzcoreStoreLocatorButtonContractEvent : MealzcoreBase <MealzcoreUiEvent>
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoreLocatorButtonContractState")))
@interface MealzcoreStoreLocatorButtonContractState : MealzcoreBase <MealzcoreUiState>
- (instancetype)initWithPosName:(NSString * _Nullable)posName supplierName:(NSString * _Nullable)supplierName address:(NSString * _Nullable)address logoUrl:(NSString * _Nullable)logoUrl state:(MealzcoreComponentUiState *)state __attribute__((swift_name("init(posName:supplierName:address:logoUrl:state:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreStoreLocatorButtonContractState *)doCopyPosName:(NSString * _Nullable)posName supplierName:(NSString * _Nullable)supplierName address:(NSString * _Nullable)address logoUrl:(NSString * _Nullable)logoUrl state:(MealzcoreComponentUiState *)state __attribute__((swift_name("doCopy(posName:supplierName:address:logoUrl:state:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable address __attribute__((swift_name("address")));
@property (readonly) NSString * _Nullable logoUrl __attribute__((swift_name("logoUrl")));
@property (readonly) NSString * _Nullable posName __attribute__((swift_name("posName")));
@property (readonly) MealzcoreComponentUiState *state __attribute__((swift_name("state")));
@property (readonly) NSString * _Nullable supplierName __attribute__((swift_name("supplierName")));
@end

__attribute__((swift_name("StoreLocatorButtonViewModel")))
@interface MealzcoreStoreLocatorButtonViewModel : MealzcoreBaseViewModel<MealzcoreStoreLocatorButtonContractEvent *, MealzcoreStoreLocatorButtonContractState *, MealzcoreStoreLocatorButtonContractEffect *>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) MealzcoreStoreLocatorButtonViewModelCompanion *companion __attribute__((swift_name("companion")));
- (MealzcoreStoreLocatorButtonContractState *)createInitialState __attribute__((swift_name("createInitialState()")));
- (void)goToStoreLocator __attribute__((swift_name("goToStoreLocator()")));
- (void)handleEventEvent:(MealzcoreStoreLocatorButtonContractEvent *)event __attribute__((swift_name("handleEvent(event:)")));
- (void)registerListeners __attribute__((swift_name("registerListeners()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoreLocatorButtonViewModel.Companion")))
@interface MealzcoreStoreLocatorButtonViewModelCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreStoreLocatorButtonViewModelCompanion *shared __attribute__((swift_name("shared")));
- (void)sendDisplayListEvent __attribute__((swift_name("sendDisplayListEvent()")));
- (void)sendDisplayMapEvent __attribute__((swift_name("sendDisplayMapEvent()")));
- (void)sendLocatorBackEvent __attribute__((swift_name("sendLocatorBackEvent()")));
- (void)sendLocatorCloseEvent __attribute__((swift_name("sendLocatorCloseEvent()")));
- (void)sendLocatorDisplayView __attribute__((swift_name("sendLocatorDisplayView()")));
- (void)sendLocatorFilterEventSupplierName:(NSString *)supplierName __attribute__((swift_name("sendLocatorFilterEvent(supplierName:)")));
- (void)sendLocatorSearchEventSearchTerm:(NSString *)searchTerm numStoreFound:(int32_t)numStoreFound __attribute__((swift_name("sendLocatorSearchEvent(searchTerm:numStoreFound:)")));
- (void)sendLocatorSelectEventPosId:(NSString *)posId posName:(NSString *)posName supplierName:(NSString *)supplierName __attribute__((swift_name("sendLocatorSelectEvent(posId:posName:supplierName:)")));
- (void)sendPageView __attribute__((swift_name("sendPageView()")));
@property (readonly) NSString *STORE_LOCATOR_BUTTON_LISTENER __attribute__((swift_name("STORE_LOCATOR_BUTTON_LISTENER")));
@end

@interface MealzcoreKMMContext (Extensions)
- (NSArray<NSString *> * _Nullable)getArrayOrNullKey:(NSString *)key __attribute__((swift_name("getArrayOrNull(key:)")));
- (MealzcoreDouble * _Nullable)getDoubleOrNullKey_:(NSString *)key __attribute__((swift_name("getDoubleOrNull(key_:)")));
- (MealzcoreInt * _Nullable)getIntOrNullKey_:(NSString *)key __attribute__((swift_name("getIntOrNull(key_:)")));
- (NSString * _Nullable)getStringOrNullKey_:(NSString *)key __attribute__((swift_name("getStringOrNull(key_:)")));
- (void)putArrayKey:(NSString *)key value:(NSArray<NSString *> *)value __attribute__((swift_name("putArray(key:value:)")));
- (void)putDoubleKey:(NSString *)key value_:(double)value __attribute__((swift_name("putDouble(key:value_:)")));
- (void)putIntKey:(NSString *)key value_:(int32_t)value __attribute__((swift_name("putInt(key:value_:)")));
- (void)putStringKey:(NSString *)key value_:(NSString *)value __attribute__((swift_name("putString(key:value_:)")));
- (void)removeKeyKey_:(NSString *)key __attribute__((swift_name("removeKey(key_:)")));
@end

@interface MealzcoreSdkBuilder (Extensions)
- (void)optionInit:(void (^)(MealzcoreOptionalConfigurationBuilder *))init __attribute__((swift_name("option(init:)")));
- (void)sdkRequirementInit:(void (^)(MealzcoreSdkRequirementBuilder *))init __attribute__((swift_name("sdkRequirement(init:)")));
- (void)subscriptionsInit:(void (^)(MealzcoreSubscriptionConfigBuilder *))init __attribute__((swift_name("subscriptions(init:)")));
@end

@interface MealzcoreSubscriptionConfigBuilder (Extensions)
- (void)basketInit:(void (^)(MealzcoreBasketSubscriptionBuilder *))init __attribute__((swift_name("basket(init:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BasketEntryListExtentionKt")))
@interface MealzcoreBasketEntryListExtentionKt : MealzcoreBase
+ (double)absolutePricesSummed:(NSArray<MealzcoreBasketEntry *> *)receiver __attribute__((swift_name("absolutePricesSummed(_:)")));
+ (NSArray<MealzcoreBasketEntry *> *)active:(NSArray<MealzcoreBasketEntry *> *)receiver __attribute__((swift_name("active(_:)")));
+ (NSArray<MealzcoreBasketEntry *> *)activeOrDeleted:(NSArray<MealzcoreBasketEntry *> *)receiver __attribute__((swift_name("activeOrDeleted(_:)")));
+ (NSArray<MealzcoreBasketEntry *> *)available:(NSArray<MealzcoreBasketEntry *> *)receiver __attribute__((swift_name("available(_:)")));
+ (NSArray<MealzcoreBasketEntry *> *)deleted:(NSArray<MealzcoreBasketEntry *> *)receiver __attribute__((swift_name("deleted(_:)")));
+ (NSArray<MealzcoreBasketEntry *> *)forRecipe:(NSArray<MealzcoreBasketEntry *> *)receiver recipeId:(NSString *)recipeId __attribute__((swift_name("forRecipe(_:recipeId:)")));
+ (NSArray<MealzcoreBasketEntry *> *)forRecipes:(NSArray<MealzcoreBasketEntry *> *)receiver recipes:(NSArray<MealzcoreRecipe *> *)recipes __attribute__((swift_name("forRecipes(_:recipes:)")));
+ (NSArray<MealzcoreBasketEntry *> *)forRecipesId:(NSArray<MealzcoreBasketEntry *> *)receiver recipesId:(NSArray<NSString *> *)recipesId __attribute__((swift_name("forRecipesId(_:recipesId:)")));
+ (NSArray<MealzcoreBasketEntry *> *)oftenDeleted:(NSArray<MealzcoreBasketEntry *> *)receiver __attribute__((swift_name("oftenDeleted(_:)")));
+ (int32_t)productInBasketCount:(NSArray<MealzcoreBasketEntry *> *)receiver __attribute__((swift_name("productInBasketCount(_:)")));
+ (NSArray<MealzcoreBasketEntry *> *)unavailable:(NSArray<MealzcoreBasketEntry *> *)receiver __attribute__((swift_name("unavailable(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DoubleExtensionKt")))
@interface MealzcoreDoubleExtensionKt : MealzcoreBase
+ (NSString *)formatDecimal:(double)receiver maxFractionDigits:(int32_t)maxFractionDigits __attribute__((swift_name("formatDecimal(_:maxFractionDigits:)")));
+ (NSString *)formatPrice:(double)receiver __attribute__((swift_name("formatPrice(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18nResourceExtKt")))
@interface MealzcoreI18nResourceExtKt : MealzcoreBase
+ (MealzcoreI18n *)i18n:(id<MealzcoreI18nResource>)receiver __attribute__((swift_name("i18n(_:)")));
+ (id<MealzcoreResourcesStringDesc>)asStringDesc:(id<MealzcoreI18nResource>)receiver __attribute__((swift_name("asStringDesc(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformKt")))
@interface MealzcorePlatformKt : MealzcoreBase
+ (MealzcoreOperatingSystem *)getOperatingSystem __attribute__((swift_name("getOperatingSystem()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RecordKt")))
@interface MealzcoreRecordKt : MealzcoreBase
+ (int32_t)getIntValueOrThrow:(NSDictionary<NSString *, MealzcoreKotlinx_serialization_jsonJsonElement *> *)receiver attribute:(NSString *)attribute __attribute__((swift_name("getIntValueOrThrow(_:attribute:)")));
+ (NSString * _Nullable)getStringValueOrNull:(NSDictionary<NSString *, MealzcoreKotlinx_serialization_jsonJsonElement *> *)receiver attribute:(NSString *)attribute __attribute__((swift_name("getStringValueOrNull(_:attribute:)")));
+ (NSString *)getStringValueOrThrow:(NSDictionary<NSString *, MealzcoreKotlinx_serialization_jsonJsonElement *> *)receiver attribute:(NSString *)attribute __attribute__((swift_name("getStringValueOrThrow(_:attribute:)")));
@property (class, readonly) MealzcoreKotlinx_serialization_jsonJson *jsonFormat __attribute__((swift_name("jsonFormat")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StringExtention_iosKt")))
@interface MealzcoreStringExtention_iosKt : MealzcoreBase
+ (NSString *)isoDateStringToLocalDateString:(NSString *)receiver format:(NSString *)format __attribute__((swift_name("isoDateStringToLocalDateString(_:format:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StringExtentionKt")))
@interface MealzcoreStringExtentionKt : MealzcoreBase
+ (NSString *)prettyDoubleFormat:(NSString *)receiver __attribute__((swift_name("prettyDoubleFormat(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WrappingKt")))
@interface MealzcoreWrappingKt : MealzcoreBase
+ (id _Nullable)dualLetP1:(id _Nullable)p1 p2:(id _Nullable)p2 block:(id _Nullable (^)(id, id))block __attribute__((swift_name("dualLet(p1:p2:block:)")));
+ (id _Nullable)letElseP:(id _Nullable)p block:(id _Nullable (^)(id _Nullable))block elseBlock:(id _Nullable (^)(void))elseBlock __attribute__((swift_name("letElse(p:block:elseBlock:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DeviceLanguageKt")))
@interface MealzcoreDeviceLanguageKt : MealzcoreBase
@property (class, readonly) NSString * _Nullable userCountryCode __attribute__((swift_name("userCountryCode")));
@property (class, readonly) NSString * _Nullable userLanguageCode __attribute__((swift_name("userLanguageCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IosGetCustomResourcesKt")))
@interface MealzcoreIosGetCustomResourcesKt : MealzcoreBase
+ (MealzcoreResourcesPluralsResource * _Nullable)customized:(id<MealzcoreI18nResource>)receiver __attribute__((swift_name("customized(_:)")));
@end

__attribute__((swift_name("KotlinException")))
@interface MealzcoreKotlinException : MealzcoreKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface MealzcoreKotlinRuntimeException : MealzcoreKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface MealzcoreKotlinIllegalStateException : MealzcoreKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface MealzcoreKotlinCancellationException : MealzcoreKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(MealzcoreKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol MealzcoreKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol MealzcoreKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<MealzcoreKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<MealzcoreKotlinCoroutineContextElement> _Nullable)getKey:(id<MealzcoreKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<MealzcoreKotlinCoroutineContext>)minusKeyKey:(id<MealzcoreKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<MealzcoreKotlinCoroutineContext>)plusContext:(id<MealzcoreKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol MealzcoreKotlinCoroutineContextElement <MealzcoreKotlinCoroutineContext>
@required
@property (readonly) id<MealzcoreKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol MealzcoreKotlinx_coroutines_coreJob <MealzcoreKotlinCoroutineContextElement>
@required
- (id<MealzcoreKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<MealzcoreKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause:(MealzcoreKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));
- (MealzcoreKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<MealzcoreKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(MealzcoreKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));
- (id<MealzcoreKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(MealzcoreKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<MealzcoreKotlinx_coroutines_coreJob>)plusOther:(id<MealzcoreKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<MealzcoreKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
@property (readonly) id<MealzcoreKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreDeferred")))
@protocol MealzcoreKotlinx_coroutines_coreDeferred <MealzcoreKotlinx_coroutines_coreJob>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("await(completionHandler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (id _Nullable)getCompleted __attribute__((swift_name("getCompleted()")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (MealzcoreKotlinThrowable * _Nullable)getCompletionExceptionOrNull __attribute__((swift_name("getCompletionExceptionOrNull()")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreSelectClause1> onAwait __attribute__((swift_name("onAwait")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface MealzcoreKotlinEnumCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface MealzcoreKotlinArray<T> : MealzcoreBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(MealzcoreInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<MealzcoreKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSharedFlow")))
@protocol MealzcoreKotlinx_coroutines_coreSharedFlow <MealzcoreKotlinx_coroutines_coreFlow>
@required
@property (readonly) NSArray<id> *replayCache __attribute__((swift_name("replayCache")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreStateFlow")))
@protocol MealzcoreKotlinx_coroutines_coreStateFlow <MealzcoreKotlinx_coroutines_coreSharedFlow>
@required
@property (readonly) id _Nullable value_ __attribute__((swift_name("value_")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface MealzcoreKotlinNothing : MealzcoreBase
@end

__attribute__((swift_name("KotlinFunction")))
@protocol MealzcoreKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol MealzcoreKotlinSuspendFunction0 <MealzcoreKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResourcesPluralsResource")))
@interface MealzcoreResourcesPluralsResource : MealzcoreBase
- (instancetype)initWithResourceId:(NSString *)resourceId bundle:(NSBundle *)bundle __attribute__((swift_name("init(resourceId:bundle:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSBundle *bundle __attribute__((swift_name("bundle")));
@property (readonly) NSString *resourceId __attribute__((swift_name("resourceId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResourcesStringResource")))
@interface MealzcoreResourcesStringResource : MealzcoreBase
- (instancetype)initWithResourceId:(NSString *)resourceId bundle:(NSBundle *)bundle __attribute__((swift_name("init(resourceId:bundle:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreResourcesStringResource *)doCopyResourceId:(NSString *)resourceId bundle:(NSBundle *)bundle __attribute__((swift_name("doCopy(resourceId:bundle:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSBundle *bundle __attribute__((swift_name("bundle")));
@property (readonly) NSString *resourceId __attribute__((swift_name("resourceId")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol MealzcoreKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol MealzcoreKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol MealzcoreKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol MealzcoreKotlinKClass <MealzcoreKotlinKDeclarationContainer, MealzcoreKotlinKAnnotatedElement, MealzcoreKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/serialization/json/JsonElementSerializer))
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface MealzcoreKotlinx_serialization_jsonJsonElement : MealzcoreBase
@property (class, readonly, getter=companion) MealzcoreKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol MealzcoreKotlinx_serialization_coreEncoder
@required
- (id<MealzcoreKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<MealzcoreKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<MealzcoreKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<MealzcoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<MealzcoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) MealzcoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol MealzcoreKotlinx_serialization_coreSerialDescriptor
@required

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSArray<id<MealzcoreKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSArray<id<MealzcoreKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) MealzcoreKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol MealzcoreKotlinx_serialization_coreDecoder
@required
- (id<MealzcoreKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<MealzcoreKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (MealzcoreKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<MealzcoreKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<MealzcoreKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) MealzcoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreMutableSharedFlow")))
@protocol MealzcoreKotlinx_coroutines_coreMutableSharedFlow <MealzcoreKotlinx_coroutines_coreSharedFlow, MealzcoreKotlinx_coroutines_coreFlowCollector>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (void)resetReplayCache __attribute__((swift_name("resetReplayCache()")));
- (BOOL)tryEmitValue:(id _Nullable)value __attribute__((swift_name("tryEmit(value:)")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreStateFlow> subscriptionCount __attribute__((swift_name("subscriptionCount")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineExceptionHandler")))
@protocol MealzcoreKotlinx_coroutines_coreCoroutineExceptionHandler <MealzcoreKotlinCoroutineContextElement>
@required
- (void)handleExceptionContext:(id<MealzcoreKotlinCoroutineContext>)context exception:(MealzcoreKotlinThrowable *)exception __attribute__((swift_name("handleException(context:exception:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResourcesImageResource")))
@interface MealzcoreResourcesImageResource : MealzcoreBase
- (instancetype)initWithAssetImageName:(NSString *)assetImageName bundle:(NSBundle *)bundle __attribute__((swift_name("init(assetImageName:bundle:)"))) __attribute__((objc_designated_initializer));
- (MealzcoreResourcesImageResource *)doCopyAssetImageName:(NSString *)assetImageName bundle:(NSBundle *)bundle __attribute__((swift_name("doCopy(assetImageName:bundle:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (UIImage * _Nullable)toUIImage __attribute__((swift_name("toUIImage()")));
@property (readonly) NSString *assetImageName __attribute__((swift_name("assetImageName")));
@property (readonly) NSBundle *bundle __attribute__((swift_name("bundle")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreMutableStateFlow")))
@protocol MealzcoreKotlinx_coroutines_coreMutableStateFlow <MealzcoreKotlinx_coroutines_coreStateFlow, MealzcoreKotlinx_coroutines_coreMutableSharedFlow>
@required
- (void)setValue:(id _Nullable)value __attribute__((swift_name("setValue(_:)")));
- (BOOL)compareAndSetExpect:(id _Nullable)expect update:(id _Nullable)update __attribute__((swift_name("compareAndSet(expect:update:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface MealzcoreKotlinUnit : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("ResourcesStringDesc")))
@protocol MealzcoreResourcesStringDesc
@required
- (NSString *)localized __attribute__((swift_name("localized()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialFormat")))
@protocol MealzcoreKotlinx_serialization_coreSerialFormat
@required
@property (readonly) MealzcoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreStringFormat")))
@protocol MealzcoreKotlinx_serialization_coreStringFormat <MealzcoreKotlinx_serialization_coreSerialFormat>
@required
- (id _Nullable)decodeFromStringDeserializer:(id<MealzcoreKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (NSString *)encodeToStringSerializer:(id<MealzcoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_jsonJson")))
@interface MealzcoreKotlinx_serialization_jsonJson : MealzcoreBase <MealzcoreKotlinx_serialization_coreStringFormat>
@property (class, readonly, getter=companion) MealzcoreKotlinx_serialization_jsonJsonDefault *companion __attribute__((swift_name("companion")));
- (id _Nullable)decodeFromJsonElementDeserializer:(id<MealzcoreKotlinx_serialization_coreDeserializationStrategy>)deserializer element:(MealzcoreKotlinx_serialization_jsonJsonElement *)element __attribute__((swift_name("decodeFromJsonElement(deserializer:element:)")));
- (id _Nullable)decodeFromStringString:(NSString *)string __attribute__((swift_name("decodeFromString(string:)")));
- (id _Nullable)decodeFromStringDeserializer:(id<MealzcoreKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (MealzcoreKotlinx_serialization_jsonJsonElement *)encodeToJsonElementSerializer:(id<MealzcoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToJsonElement(serializer:value:)")));
- (NSString *)encodeToStringSerializer:(id<MealzcoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
- (MealzcoreKotlinx_serialization_jsonJsonElement *)parseToJsonElementString:(NSString *)string __attribute__((swift_name("parseToJsonElement(string:)")));
@property (readonly) MealzcoreKotlinx_serialization_jsonJsonConfiguration *configuration __attribute__((swift_name("configuration")));
@property (readonly) MealzcoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol MealzcoreKotlinCoroutineContextKey
@required
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause")))
@protocol MealzcoreKotlinx_coroutines_coreSelectClause
@required
@property (readonly) id clauseObject __attribute__((swift_name("clauseObject")));
@property (readonly) MealzcoreKotlinUnit *(^(^ _Nullable onCancellationConstructor)(id<MealzcoreKotlinx_coroutines_coreSelectInstance>, id _Nullable, id _Nullable))(MealzcoreKotlinThrowable *) __attribute__((swift_name("onCancellationConstructor")));
@property (readonly) id _Nullable (^processResFunc)(id, id _Nullable, id _Nullable) __attribute__((swift_name("processResFunc")));
@property (readonly) void (^regFunc)(id, id<MealzcoreKotlinx_coroutines_coreSelectInstance>, id _Nullable) __attribute__((swift_name("regFunc")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause1")))
@protocol MealzcoreKotlinx_coroutines_coreSelectClause1 <MealzcoreKotlinx_coroutines_coreSelectClause>
@required
@end

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol MealzcoreKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol MealzcoreKotlinx_coroutines_coreChildHandle <MealzcoreKotlinx_coroutines_coreDisposableHandle>
@required
- (BOOL)childCancelledCause:(MealzcoreKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));
@property (readonly) id<MealzcoreKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol MealzcoreKotlinx_coroutines_coreChildJob <MealzcoreKotlinx_coroutines_coreJob>
@required
- (void)parentCancelledParentJob:(id<MealzcoreKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end

__attribute__((swift_name("KotlinSequence")))
@protocol MealzcoreKotlinSequence
@required
- (id<MealzcoreKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol MealzcoreKotlinx_coroutines_coreSelectClause0 <MealzcoreKotlinx_coroutines_coreSelectClause>
@required
@end

__attribute__((swift_name("KotlinIterator")))
@protocol MealzcoreKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface MealzcoreKotlinx_serialization_jsonJsonElementCompanion : MealzcoreBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol MealzcoreKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<MealzcoreKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<MealzcoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<MealzcoreKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) MealzcoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface MealzcoreKotlinx_serialization_coreSerializersModule : MealzcoreBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<MealzcoreKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MealzcoreKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<MealzcoreKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MealzcoreKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<MealzcoreKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<MealzcoreKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<MealzcoreKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol MealzcoreKotlinAnnotation
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface MealzcoreKotlinx_serialization_coreSerialKind : MealzcoreBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol MealzcoreKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<MealzcoreKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<MealzcoreKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<MealzcoreKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) MealzcoreKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJson.Default")))
@interface MealzcoreKotlinx_serialization_jsonJsonDefault : MealzcoreKotlinx_serialization_jsonJson
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) MealzcoreKotlinx_serialization_jsonJsonDefault *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonConfiguration")))
@interface MealzcoreKotlinx_serialization_jsonJsonConfiguration : MealzcoreBase
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowSpecialFloatingPointValues __attribute__((swift_name("allowSpecialFloatingPointValues")));
@property (readonly) BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));
@property (readonly) NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));
@property (readonly) BOOL coerceInputValues __attribute__((swift_name("coerceInputValues")));
@property (readonly) BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL explicitNulls __attribute__((swift_name("explicitNulls")));
@property (readonly) BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property (readonly) BOOL isLenient __attribute__((swift_name("isLenient")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) id<MealzcoreKotlinx_serialization_jsonJsonNamingStrategy> _Nullable namingStrategy __attribute__((swift_name("namingStrategy")));
@property (readonly) BOOL prettyPrint __attribute__((swift_name("prettyPrint")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *prettyPrintIndent __attribute__((swift_name("prettyPrintIndent")));
@property (readonly) BOOL useAlternativeNames __attribute__((swift_name("useAlternativeNames")));
@property (readonly) BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol MealzcoreKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnCompletionDisposableHandle:(id<MealzcoreKotlinx_coroutines_coreDisposableHandle>)disposableHandle __attribute__((swift_name("disposeOnCompletion(disposableHandle:)")));
- (void)selectInRegistrationPhaseInternalResult:(id _Nullable)internalResult __attribute__((swift_name("selectInRegistrationPhase(internalResult:)")));
- (BOOL)trySelectClauseObject:(id)clauseObject result:(id _Nullable)result __attribute__((swift_name("trySelect(clauseObject:result:)")));
@property (readonly) id<MealzcoreKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol MealzcoreKotlinx_coroutines_coreParentJob <MealzcoreKotlinx_coroutines_coreJob>
@required
- (MealzcoreKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol MealzcoreKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<MealzcoreKotlinKClass>)kClass provider:(id<MealzcoreKotlinx_serialization_coreKSerializer> (^)(NSArray<id<MealzcoreKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<MealzcoreKotlinKClass>)kClass serializer:(id<MealzcoreKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<MealzcoreKotlinKClass>)baseClass actualClass:(id<MealzcoreKotlinKClass>)actualClass actualSerializer:(id<MealzcoreKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<MealzcoreKotlinKClass>)baseClass defaultDeserializerProvider:(id<MealzcoreKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<MealzcoreKotlinKClass>)baseClass defaultDeserializerProvider:(id<MealzcoreKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<MealzcoreKotlinKClass>)baseClass defaultSerializerProvider:(id<MealzcoreKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonNamingStrategy")))
@protocol MealzcoreKotlinx_serialization_jsonJsonNamingStrategy
@required
- (NSString *)serialNameForJsonDescriptor:(id<MealzcoreKotlinx_serialization_coreSerialDescriptor>)descriptor elementIndex:(int32_t)elementIndex serialName:(NSString *)serialName __attribute__((swift_name("serialNameForJson(descriptor:elementIndex:serialName:)")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
